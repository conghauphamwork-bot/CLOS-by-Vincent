#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  echo "Lần đầu: đang tạo môi trường và cài thư viện..."
  python3 -m venv .venv
  .venv/bin/python -m pip install --upgrade pip
  .venv/bin/python -m pip install -r requirements.txt
fi
echo "Đang chạy CLOS cho cả mạng nội bộ (Ctrl+C để tắt)"
.venv/bin/python run.py --lan
