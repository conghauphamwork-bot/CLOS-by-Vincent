#!/usr/bin/env bash
# Triển khai / cập nhật CLOS trên máy chủ đã có Caddy chạy trong Docker (dùng chung Caddy đó).
#   cd clos/deploy && CADDYFILE=/duong/dan/Caddyfile bash deploy.sh
# Chạy lại lệnh này mỗi lần cập nhật code: dữ liệu trong deploy/data được giữ nguyên.
set -euo pipefail
cd "$(dirname "$0")"
DEPLOY_DIR="$(pwd)"
CADDYFILE="${CADDYFILE:-$HOME/caddy/Caddyfile}"

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
die()  { printf '\n\033[1;31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

# ---------------------------------------------------------------- 1. kiểm tra
say "Kiểm tra Docker và Caddy đang chạy"
command -v docker >/dev/null || die "Chưa có docker trên máy chủ."
docker compose version >/dev/null 2>&1 || die "Chưa có 'docker compose'."
[ -f "$CADDYFILE" ] || die "Không thấy $CADDYFILE. Chạy lại với: CADDYFILE=/duong/dan/Caddyfile bash deploy.sh"
CADDY=$(docker ps --format '{{.Names}} {{.Image}}' | awk '$2 ~ /caddy/ {print $1; exit}')
[ -n "$CADDY" ] || die "Không thấy container Caddy nào đang chạy."
echo "Caddy container: $CADDY"

# đường dẫn Caddyfile bên trong container Caddy
REAL=$(readlink -f "$CADDYFILE")
DEST=$(docker inspect -f '{{range .Mounts}}{{if eq .Source "'"$REAL"'"}}{{.Destination}}{{end}}{{end}}' "$CADDY")
if [ -z "$DEST" ]; then
  DIRSRC=$(dirname "$REAL")
  DDIR=$(docker inspect -f '{{range .Mounts}}{{if eq .Source "'"$DIRSRC"'"}}{{.Destination}}{{end}}{{end}}' "$CADDY")
  [ -n "$DDIR" ] && DEST="$DDIR/$(basename "$REAL")"
fi
[ -n "$DEST" ] || die "Không xác định được Caddyfile được gắn vào container $CADDY ở đâu."
echo "Caddyfile: $CADDYFILE  (trong container: $DEST)"

# mạng docker để Caddy gọi được CLOS: ưu tiên docker_default, không có thì lấy mạng đầu tiên của Caddy
NETS=$(docker inspect -f '{{range $k,$v := .NetworkSettings.Networks}}{{$k}} {{end}}' "$CADDY")
NET=""
for n in $NETS; do [ "$n" = "docker_default" ] && NET=$n; done
[ -n "$NET" ] || NET=$(echo "$NETS" | awk '{print $1}')
echo "Mạng dùng chung với Caddy: $NET"

# tên miền: CLOS_HOST nếu có; không thì dùng lại đuôi sslip.io có sẵn trong Caddyfile, hoặc clos.<IP>.sslip.io
if [ -z "${CLOS_HOST:-}" ]; then
  EXIST=$(grep -oE '[A-Za-z0-9.-]+\.sslip\.io' "$CADDYFILE" | head -1 || true)
  if [ -n "$EXIST" ]; then
    BASE=${EXIST#*.}
    CLOS_HOST="clos.$BASE"
  else
    IP=$(curl -s4 --max-time 5 https://api.ipify.org || hostname -I | awk '{print $1}')
    CLOS_HOST="clos.$IP.sslip.io"
  fi
fi
echo "Địa chỉ CLOS: https://$CLOS_HOST"

# ---------------------------------------------------------------- 2. build + chạy
say "Build và chạy container CLOS (lần đầu ~2–3 phút)"
mkdir -p data
CLOS_NETWORK="$NET" docker compose up -d --build
for i in $(seq 1 30); do
  st=$(docker inspect -f '{{.State.Health.Status}}' clos-app 2>/dev/null || echo starting)
  [ "$st" = "healthy" ] && break
  sleep 2
done
[ "$st" = "healthy" ] || { docker logs --tail 50 clos-app; die "CLOS chưa chạy được (xem log ở trên)."; }
echo "CLOS đang chạy."

# ---------------------------------------------------------------- 3. Caddy + mật khẩu
if grep -q '# >>> CLOS' "$CADDYFILE"; then
  say "Caddy đã có cấu hình CLOS — bỏ qua (muốn đổi mật khẩu: xem deploy/README.md)"
else
  say "Tạo tài khoản đăng nhập cho CLOS"
  read -rp "Tên đăng nhập [admin]: " U; U=${U:-admin}
  while true; do
    read -rsp "Mật khẩu (ít nhất 10 ký tự): " P1; echo
    read -rsp "Nhập lại mật khẩu: " P2; echo
    [ "$P1" = "$P2" ] && [ ${#P1} -ge 10 ] && break
    echo "Không khớp hoặc quá ngắn, nhập lại."
  done
  HASH=$(docker exec "$CADDY" caddy hash-password --plaintext "$P1" | tail -1 | tr -d '[:space:]')
  unset P1 P2
  [[ "$HASH" == \$2* ]] || die "Không tạo được mã băm mật khẩu bằng Caddy — chưa sửa gì Caddyfile."
  MINOR=$(docker exec "$CADDY" caddy version | sed -E 's/^v2\.([0-9]+).*/\1/')
  AUTH=basic_auth; [ "${MINOR:-99}" -lt 8 ] 2>/dev/null && AUTH=basicauth

  BAK="$CADDYFILE.bak-clos-$(date +%Y%m%d-%H%M%S)"
  cp "$CADDYFILE" "$BAK"
  {
    printf '\n# >>> CLOS (thêm bởi deploy.sh %s)\n' "$(date +%F)"
    printf '%s {\n' "$CLOS_HOST"
    printf '\tencode gzip\n'
    printf '\t%s {\n\t\t%s %s\n\t}\n' "$AUTH" "$U" "$HASH"
    printf '\treverse_proxy clos:8000 {\n\t\ttransport http {\n\t\t\tread_timeout 300s\n\t\t}\n\t}\n'
    printf '}\n# <<< CLOS\n'
  } >> "$CADDYFILE"

  say "Kiểm tra cấu hình Caddy trước khi áp dụng"
  if ! docker exec "$CADDY" caddy validate --config "$DEST" --adapter caddyfile; then
    cat "$BAK" > "$CADDYFILE"   # ghi đè nội dung (giữ nguyên file đang gắn vào container)
    die "Cấu hình lỗi → đã trả Caddyfile về bản cũ. Các site khác không bị ảnh hưởng."
  fi
  docker exec "$CADDY" caddy reload --config "$DEST" --adapter caddyfile
  echo "Đã thêm CLOS vào Caddy. Bản Caddyfile cũ: $BAK"
fi

# ---------------------------------------------------------------- 4. sao lưu hằng ngày
say "Cài sao lưu dữ liệu tự động 2:15 sáng mỗi ngày (giữ 14 ngày)"
cat > "$DEPLOY_DIR/backup.sh" <<EOF
#!/usr/bin/env bash
# Sao lưu an toàn SQLite khi app đang chạy (dùng backup API, không copy file thô)
docker exec clos-app python -c "
import sqlite3, datetime, os
src = '/app/data/clos_web.db'
if os.path.exists(src):
    os.makedirs('/app/data/backups', exist_ok=True)
    d = sqlite3.connect('/app/data/backups/clos_web-' + datetime.datetime.now().strftime('%Y%m%d-%H%M') + '.db')
    sqlite3.connect(src).backup(d); d.close()
" && find "$DEPLOY_DIR/data/backups" -name 'clos_web-*.db' -mtime +14 -delete 2>/dev/null
EOF
chmod +x "$DEPLOY_DIR/backup.sh"
mkdir -p "$DEPLOY_DIR/data/backups"
if command -v crontab >/dev/null; then
  { { crontab -l 2>/dev/null || true; } | { grep -v '# CLOS backup' || true; }
    echo "15 2 * * * $DEPLOY_DIR/backup.sh >/dev/null 2>&1 # CLOS backup"; } | crontab -
else
  echo "⚠ Máy chủ chưa có cron (apt install -y cron) — chưa cài được lịch sao lưu tự động."
fi
"$DEPLOY_DIR/backup.sh" || true

say "XONG"
echo "Mở: https://$CLOS_HOST   (lần đầu Caddy lấy chứng chỉ HTTPS mất ~30 giây)"
echo "Dữ liệu: $DEPLOY_DIR/data/clos_web.db · Bản sao lưu: $DEPLOY_DIR/data/backups/"
