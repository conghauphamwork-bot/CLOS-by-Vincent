# Chạy CLOS trên máy chủ (Docker + Caddy)

Kết quả: mở `https://clos.<tên miền>`, nhập tên đăng nhập và mật khẩu, rồi vào CLOS.
CLOS chạy trong Docker sau Caddy, không mở thêm cổng nào ra Internet.

## Yêu cầu

- Máy chủ Linux đã cài Docker và `docker compose`.
- **Caddy đang chạy trong Docker**, cấu hình bằng một Caddyfile được gắn (mount) từ máy chủ vào container.
  - Chưa có Caddy: dùng `docker-compose.yml` ở thư mục gốc để chạy nội bộ, hoặc dựng Caddy trước.
- Một tên miền trỏ về máy chủ. Nếu chưa có tên miền, script dùng `clos.<IP>.sslip.io`.

## Lần đầu

```bash
git clone <địa chỉ repo> clos
cd clos/deploy
CADDYFILE=/duong/dan/toi/Caddyfile CLOS_HOST=clos.tenmien.com bash deploy.sh
```

Script sẽ làm các việc sau:

1. Tìm container Caddy đang chạy và mạng docker mà Caddy dùng.
2. Build và chạy container `clos-app` (lần đầu mất 2–3 phút).
3. Hỏi **tên đăng nhập và mật khẩu** (mật khẩu tối thiểu 10 ký tự), rồi thêm một khối cấu hình vào cuối Caddyfile.
   - Script **kiểm tra cấu hình trước khi áp dụng**. Nếu lỗi, Caddyfile được trả về bản cũ.
4. Cài sao lưu tự động lúc 2:15 sáng mỗi ngày, giữ bản sao lưu 14 ngày.

## Cập nhật code mới

```bash
cd clos && git pull && cd deploy && bash deploy.sh
```

Dữ liệu nằm ở `deploy/data/`, không thuộc Git nên không bị ghi đè khi cập nhật.

## Việc thường dùng

| Việc | Lệnh |
|---|---|
| Xem log | `docker logs --tail 100 clos-app` |
| Khởi động lại | `docker restart clos-app` |
| Sao lưu ngay | `deploy/backup.sh` |
| Đổi mật khẩu | Xoá khối `# >>> CLOS … # <<< CLOS` trong Caddyfile (ghi đè nội dung file, **không** dùng `sed -i`), rồi chạy lại `bash deploy.sh` |
| Gỡ CLOS | `cd deploy && docker compose down`, rồi xoá khối CLOS trong Caddyfile |

**Khôi phục từ bản sao lưu:**

```bash
cd deploy && docker stop clos-app
cp data/clos_web.db data/clos_web.db.truoc-khoi-phuc
cp data/backups/clos_web-YYYYMMDD-HHMM.db data/clos_web.db && rm -f data/clos_web.db-wal data/clos_web.db-shm
docker start clos-app
```

Lưu ý: không sửa Caddyfile bằng `sed -i`. Caddy gắn file theo inode, nên sau `sed -i` container vẫn đọc file cũ.
