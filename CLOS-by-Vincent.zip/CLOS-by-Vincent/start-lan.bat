@echo off
chcp 65001 >nul
cd /d "%~dp0"
REM Chay CLOS cho ca mang van phong dung chung. Muon bat mat khau: bo chu REM o dong duoi va doi mat khau.
REM set CLOS_PASSWORD=doi-mat-khau-o-day
if not exist .venv (
  echo Lan dau: dang tao moi truong va cai thu vien...
  python -m venv .venv || (echo Khong tim thay Python. Cai Python 3.11+ va tick "Add python.exe to PATH". & pause & exit /b 1)
  .venv\Scripts\python -m pip install --upgrade pip
  .venv\Scripts\python -m pip install -r requirements.txt || (pause & exit /b 1)
)
.venv\Scripts\python run.py --lan
pause
