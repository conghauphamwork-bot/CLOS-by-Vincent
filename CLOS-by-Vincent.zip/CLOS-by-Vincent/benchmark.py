"""Benchmark trên cùng 1 bộ dữ liệu: CargoWiz (kết quả có sẵn trong file) vs FFD vs constructor vs Hybrid.

Chạy:  python benchmark.py "duong_dan_file.xlsm" [so_seed] [giay_moi_lan]
Kết quả in ra màn hình và lưu benchmark_result.json
"""
from __future__ import annotations

import json
import statistics
import sys
import time
from dataclasses import replace

from clos.engine.improve import improve
from clos.engine.models import ContainerType, Rules
from clos.engine.packer import DEFAULT_VARIANTS, FFD_BASELINE, lower_bound_containers, pack
from clos.engine.validator import validate
from clos.io.importer import import_excel


def check(sol, items, ct, rules):
    rep = validate(sol.placements(), items, ct, rules, {i.idx: i.quantity for i in items})
    loaded = {}
    for p in sol.placements():
        loaded[p.item] = loaded.get(p.item, 0) + 1
    exact = sum(1 for i in items if loaded.get(i.idx, 0) == i.quantity)
    vol = sum(i.volume * i.quantity for i in items)
    return {"containers": sol.n_containers, "errors": len(rep.errors), "exact_skus": exact,
            "unplaced": sum(sol.unplaced.values()), "util": round(vol / (sol.n_containers * ct.volume), 4) if sol.n_containers else 0}


def main():
    path = sys.argv[1]
    seeds = int(sys.argv[2]) if len(sys.argv) > 2 else 5
    tl = float(sys.argv[3]) if len(sys.argv) > 3 else 30
    imp = import_excel(path)
    items = imp.items
    out = {"file": path, "n_skus": len(items), "n_units": sum(i.quantity for i in items), "scenarios": []}
    cw = imp.cargowiz_result
    if cw:
        exact = 0
        for it in items:
            got = sum(cw["loaded_by_sku"].get(it.customer_sku, {}).values())
            exact += got == it.quantity
        out["cargowiz"] = {"containers": cw["n_containers"], "exact_skus": exact,
                           "note": "Lấy từ phần kết quả CargoWiz trong file; không chạy lại Validator vì không có toạ độ"}
        print(f"CargoWiz: {cw['n_containers']} cont, {exact}/{len(items)} mã khớp đúng số")

    scenarios = [
        ("40HC tuỳ chỉnh · 1199×234×269 · α=0.75", ContainerType("C40", "", 11990, 2340, 2690), Rules(min_support_ratio=0.75)),
        ("40HC tuỳ chỉnh · α=1.0 (đỡ đáy 100%)", ContainerType("C40", "", 11990, 2340, 2690), Rules(min_support_ratio=1.0)),
        ("Ngang 232 cm · α=0.75", ContainerType("C40-232", "", 11990, 2320, 2690), Rules(min_support_ratio=0.75)),
    ]
    for name, ct, rules in scenarios:
        sc = {"name": name, "lower_bound": lower_bound_containers(items, ct), "runs": {}}
        t = time.perf_counter()
        ffd = pack(items, ct, rules, FFD_BASELINE)
        sc["runs"]["FFD baseline"] = {**check(ffd, items, ct, rules), "seconds": round(time.perf_counter() - t, 2)}
        best = None
        for v in DEFAULT_VARIANTS:
            t = time.perf_counter()
            s = pack(items, ct, rules, v)
            r = {**check(s, items, ct, rules), "seconds": round(time.perf_counter() - t, 2)}
            sc["runs"][v.name] = r
            if best is None or s.objective() < best.objective():
                best = s
        hy = []
        for seed in range(1, seeds + 1):
            t = time.perf_counter()
            s, log = improve(best, items, ct, rules, time_limit=tl, seed=seed, max_stall=10**9)
            r = {**check(s, items, ct, rules), "seconds": round(time.perf_counter() - t, 2), "seed": seed}
            hy.append(r)
            print(f"  [{name}] hybrid seed {seed}: {r}")
        cs = [r["containers"] for r in hy]
        sc["hybrid"] = {"time_limit": tl, "trials": hy, "best": min(cs), "worst": max(cs),
                        "mean": round(statistics.mean(cs), 2),
                        "all_valid": all(r["errors"] == 0 and r["unplaced"] == 0 for r in hy)}
        out["scenarios"].append(sc)
        print(f"{name}: LB {sc['lower_bound']} · FFD {sc['runs']['FFD baseline']['containers']} · "
              f"constructor tốt nhất {best.n_containers} · hybrid tốt/TB/tệ {min(cs)}/{sc['hybrid']['mean']}/{max(cs)}")
    with open("benchmark_result.json", "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
