"""Test cho lớp API của giao diện React: lưu có bản cũ, chặn sai số lượng, engine qua cầu nối."""
import json
import os
import tempfile

os.environ["CLOS_WEB_DB"] = os.path.join(tempfile.mkdtemp(), "t.db")

from fastapi.testclient import TestClient  # noqa: E402

from clos.api import app  # noqa: E402

c = TestClient(app)
SPEC = {"id": "th1", "code": "TH1", "name": "40HC tuỳ chỉnh", "internalLengthMm": 11990, "internalWidthMm": 2340,
        "internalHeightMm": 2690, "maxPayloadKg": 26000, "tareWeightKg": 0, "doorWidthMm": 2340, "doorHeightMm": 2690}
CFG = {"algorithm": "extreme_points", "anchorMode": "left", "minSupportRatio": 0.75, "maxCogOffsetPct": 15,
       "respectStacking": True, "respectRotation": True, "respectPayload": False, "prioritizeHeavyBottom": True,
       "autoAddContainers": True, "alnsIterations": 6}


def sku(i, q, L=1000, W=600, H=500, rot="all"):
    return {"id": f"s{i}", "factorySku": f"F{i}", "customerSku": f"C{i}", "description": "", "lengthMm": L,
            "widthMm": W, "heightMm": H, "weightKg": 10, "requiredQty": q, "stackable": True, "maxStackLayers": 6,
            "maxStackWeightKg": 200, "rotationPolicy": rot, "fragile": False, "palletized": False, "color": "#123"}


def proj(pid="p1", skus=None, containers=None):
    return {"id": pid, "code": pid.upper(), "name": "T", "customerName": "X", "destinationPort": "", "status": "draft",
            "createdAt": "", "updatedAt": "", "skus": skus or [sku(1, 40), sku(2, 25, 800, 500, 400)],
            "containers": containers or [], "defaultContainerSpecId": "th1", "optimizationConfig": CFG, "auditTrail": []}


def test_save_and_conflict():
    r = c.put("/api/web/projects/p1", json={"project": proj(), "baseRev": None, "note": "tạo", "specs": [SPEC]})
    assert r.status_code == 200 and r.json()["rev"] == 1
    r = c.put("/api/web/projects/p1", json={"project": proj(), "baseRev": 5})
    assert r.status_code == 409 and r.json()["rev"] == 1
    st = c.get("/api/web/state").json()
    assert st["revs"]["p1"] == 1 and st["projects"][0]["id"] == "p1"


def test_optimize_then_save_and_quantity_rules():
    p = proj("p2")
    c.put("/api/web/projects/p2", json={"project": p, "baseRev": None})
    r = c.post("/api/web/optimize", json={"project": p, "specs": [SPEC], "mode": "locked"}).json()
    assert r["validation"]["errors"] == 0
    loaded = sum(len(x["placements"]) for x in r["proposedContainers"])
    assert loaded == 65 and r["proposedMetrics"]["feasible"]
    p["containers"] = r["proposedContainers"]
    r = c.put("/api/web/projects/p2", json={"project": p, "baseRev": 1, "note": "áp dụng", "specs": [SPEC]})
    assert r.status_code == 200 and r.json()["validation"]["errors"] == 0
    # re-import đổi id SKU -> thùng mồ côi -> phải bị chặn, máy chủ trả lại bản cũ
    bad = json.loads(json.dumps(p)); bad["skus"][0]["id"] = "s1-new"
    r = c.put("/api/web/projects/p2", json={"project": bad, "baseRev": 2})
    assert r.status_code == 409 and "không còn trong danh sách" in r.json()["detail"]
    assert r.json()["current"]["skus"][0]["id"] == "s1"
    # xếp THÊM thùng vượt yêu cầu -> chặn
    bad = json.loads(json.dumps(p)); extra = dict(bad["containers"][0]["placements"][0]); extra["instanceId"] = "dup-x"
    bad["containers"][0]["placements"].append(extra)
    r = c.put("/api/web/projects/p2", json={"project": bad, "baseRev": 2})
    assert r.status_code == 409 and "tăng số yêu cầu" in r.json()["detail"]
    # GIẢM số yêu cầu dưới số đã xếp -> cho lưu (để bấm Recalculate), nhưng validator báo lỗi V9
    red = json.loads(json.dumps(p)); red["skus"][0]["requiredQty"] = 10
    r = c.put("/api/web/projects/p2", json={"project": red, "baseRev": 2, "specs": [SPEC]})
    assert r.status_code == 200
    assert any(i["code"] == "V9" and i["severity"] == "error" for i in r.json()["validation"]["issues"])
    # đang vượt mà còn thêm thùng -> vẫn chặn
    more = json.loads(json.dumps(red)); more["containers"][0]["placements"].append(extra)
    r = c.put("/api/web/projects/p2", json={"project": more, "baseRev": 3})
    assert r.status_code == 409
    # sổ số lượng có ghi
    led = c.get("/api/web/projects/p2/ledger").json()
    assert any(x["loaded_after"] == 40 for x in led)


def test_incremental_after_qty_reduction_has_no_floating_cartons():
    p = proj("p3")
    r = c.post("/api/web/optimize", json={"project": p, "specs": [SPEC], "mode": "locked"}).json()
    p["containers"] = r["proposedContainers"]
    p["skus"][0]["requiredQty"] = 30
    r = c.post("/api/web/optimize", json={"project": p, "specs": [SPEC], "mode": "incremental"}).json()
    assert r["validation"]["errors"] == 0
    n1 = sum(1 for x in r["proposedContainers"] for q in x["placements"] if q["skuId"] == "s1")
    assert n1 == 30 and len(r["invalidatedCartons"]) >= 10


def test_locked_container_is_kept_unchanged():
    p = proj("p4")
    r = c.post("/api/web/optimize", json={"project": p, "specs": [SPEC], "mode": "locked"}).json()
    first = dict(r["proposedContainers"][0]); first["locked"] = True
    p["containers"] = [first]
    r2 = c.post("/api/web/optimize", json={"project": p, "specs": [SPEC], "mode": "locked"}).json()
    assert r2["proposedContainers"][0]["placements"] == first["placements"]
    assert sum(len(x["placements"]) for x in r2["proposedContainers"]) == 65


def test_validator_catches_overlap_and_floating():
    p = proj("p5", skus=[sku(1, 2)])
    pl = lambda iid, x, y: {"instanceId": iid, "skuId": "s1", "containerId": "k", "xMm": x, "yMm": y, "zMm": 0,
                            "dimXMm": 1000, "dimYMm": 500, "dimZMm": 600, "rotationLabel": "", "layerIndex": 0, "anchorMode": "left"}
    p["containers"] = [{"id": "k", "containerSpecId": "th1", "label": "K", "sequenceNumber": 1,
                        "placements": [pl("a", 0, 0), pl("b", 500, 0)]}]
    v = c.post("/api/web/validate", json={"project": p, "specs": [SPEC]}).json()
    assert any(i["code"] == "V2" and set(i["cartonIds"]) == {"a", "b"} for i in v["issues"])
    p["containers"][0]["placements"] = [pl("a", 0, 0), pl("b", 2000, 900)]
    v = c.post("/api/web/validate", json={"project": p, "specs": [SPEC]}).json()
    assert any(i["code"] == "V7" and i["cartonIds"] == ["b"] for i in v["issues"])


def test_delete_keeps_history_and_restore():
    c.put("/api/web/projects/p6", json={"project": proj("p6"), "baseRev": None})
    c.delete("/api/web/projects/p6")
    assert "p6" not in c.get("/api/web/state").json()["revs"]
    revs = c.get("/api/web/projects/p6/revisions").json()
    seq = [r for r in revs if r["action"] == "save"][0]["seq"]
    r = c.post(f"/api/web/projects/p6/restore/{seq}").json()
    assert r["project"]["id"] == "p6" and "p6" in c.get("/api/web/state").json()["revs"]


def test_benchmark_has_no_invented_rows():
    rows = c.post("/api/web/benchmark", json={"project": proj("p7"), "specs": [SPEC], "seconds": 1}).json()
    names = " ".join(r["algorithmName"] for r in rows)
    assert "CargoWiz" not in names and rows[-1]["algorithmId"] == "lower_bound"


def test_rotation_code_4_allows_lying_but_not_length_upright():
    p = proj("p8", skus=[sku(1, 2, L=1000, W=600, H=500, rot="four_way")])
    pl = lambda iid, x, dx, dy, dz: {"instanceId": iid, "skuId": "s1", "containerId": "k", "xMm": x, "yMm": 0, "zMm": 0,
                                     "dimXMm": dx, "dimYMm": dy, "dimZMm": dz, "rotationLabel": "", "layerIndex": 0, "anchorMode": "left"}
    # nằm nghiêng: Rộng (600) làm chiều cao -> hợp lệ với mã 4
    p["containers"] = [{"id": "k", "containerSpecId": "th1", "label": "K", "sequenceNumber": 1,
                        "placements": [pl("a", 0, 1000, 600, 500)]}]
    v = c.post("/api/web/validate", json={"project": p, "specs": [SPEC]}).json()
    assert not any(i["code"] == "V3" for i in v["issues"])
    # dựng Dài (1000) lên làm chiều cao -> sai mã 4
    p["containers"][0]["placements"] = [pl("b", 0, 600, 1000, 500)]
    v = c.post("/api/web/validate", json={"project": p, "specs": [SPEC]}).json()
    assert any(i["code"] == "V3" for i in v["issues"])


def test_weight_lower_bound_when_payload_checked():
    heavy = sku(1, 30, L=1000, W=600, H=500)
    heavy["weightKg"] = 1000  # 30 tấn > tải 1 cont (26 tấn) -> cận dưới >= 2 dù thể tích rất nhỏ
    p = proj("p9", skus=[heavy])
    p["optimizationConfig"] = {**CFG, "respectPayload": True}
    r = c.post("/api/web/optimize", json={"project": p, "specs": [SPEC], "mode": "locked"}).json()
    assert r["proposedMetrics"]["lowerBoundContainers"] >= 2


def test_flat_cartons_fill_gaps_instead_of_opening_new_container():
    """Lỗi đã gặp: còn khe trong cont 1 nhưng engine mở cont 2 cho vài thùng phẳng.
    Lô dưới đây: engine cũ 2 cont (dư 10 thùng S0), engine mới phải 1 cont."""
    def s(i, L, W, H, q, rot):
        return {**sku(i, q, L, W, H, rot), "id": f"x{i}", "factorySku": f"X{i}", "maxStackLayers": 99}
    p = proj("p10", skus=[s(0, 1602, 151, 997, 41, "all"), s(1, 871, 563, 271, 22, "all"),
                          s(2, 1186, 529, 2209, 26, "upright_only"), s(3, 1919, 189, 987, 45, "four_way")])
    r = c.post("/api/web/optimize", json={"project": p, "specs": [SPEC], "mode": "locked"}).json()
    assert r["validation"]["errors"] == 0
    assert r["proposedMetrics"]["containersUsed"] == 1


def test_cont44_same_sku_mixed_orientations_one_container():
    """Lô mẫu 120 kiện (CargoWiz xếp 1 cont 89%). Mã SKU-PANEL phải được xếp cả dựng nghiêng
    (lấp khe cạnh SKU-TALL) lẫn nằm phẳng (lấp khe trên nóc) để vừa 1 cont như CargoWiz."""
    spec = {**SPEC, "internalWidthMm": 2320}
    def s(i, f, L, W, H, q, rot):
        return {**sku(i, q, L, W, H, rot), "id": f"k{i}", "factorySku": f, "maxStackLayers": 99, "weightKg": 0}
    p = proj("p11", skus=[s(1, "SKU-TALL", 1805, 1640, 2289, 4, "upright_only"),
                          s(2, "SKU-PANEL", 1960, 820, 200, 90, "four_way"),
                          s(3, "SKU-FLATMA12", 1290, 1290, 100, 7, "all"),
                          s(4, "SKU-COL", 630, 630, 1270, 10, "upright_only"),
                          s(5, "SKU-BOX", 770, 705, 885, 9, "upright_only")])
    p["optimizationConfig"] = {**CFG, "algorithm": "hybrid_alns_ep"}
    r = c.post("/api/web/optimize", json={"project": p, "specs": [spec], "mode": "locked", "seconds": 10}).json()
    assert r["validation"]["errors"] == 0
    assert r["proposedMetrics"]["containersUsed"] == 1
    dims = {(q["dimYMm"]) for cont in r["proposedContainers"] for q in cont["placements"] if q["skuId"] == "k2"}
    assert {200, 820} <= dims  # cùng mã: có tấm nằm (cao 200) và tấm dựng (cao 820)


def test_stack_layers_counted_by_placed_height_and_99_is_unlimited():
    """Lỗi 20/11/2026: dữ liệu cũ mang 'tối đa 6 lớp' ẩn, engine tính 6 × Cao danh nghĩa (200 mm)
    nên tấm phẳng dựng đứng chỉ được chồng tới 1,2 m -> dư sang cont 2. 99/trống = không giới hạn."""
    spec = {**SPEC, "internalWidthMm": 2320}
    def s(i, f, L, W, H, q, layers):
        return {**sku(i, q, L, W, H, "all"), "id": f"u{i}", "factorySku": f, "maxStackLayers": layers, "weightKg": 0}
    def mk(layers):
        return proj("p12", skus=[s(1, "SKU-TALL", 1805, 1640, 2289, 4, layers), s(2, "SKU-PANEL", 1960, 820, 200, 94, layers),
                                 s(3, "SKU-FLAT", 1290, 1290, 100, 7, layers), s(4, "SKU-COL", 630, 630, 127, 10, layers),
                                 s(5, "SKU-BOX", 770, 705, 885, 9, layers)])
    r = c.post("/api/web/optimize", json={"project": mk(99), "specs": [spec], "mode": "locked"}).json()
    assert r["proposedMetrics"]["containersUsed"] == 1 and r["validation"]["errors"] == 0
    # có giới hạn lớp: engine phải tôn trọng (không cảnh báo V4 nào)
    r = c.post("/api/web/optimize", json={"project": mk(3), "specs": [spec], "mode": "locked"}).json()
    assert not any(i["code"] == "V4" for i in r["validation"]["issues"])


def test_undo_can_restore_previous_state_but_plain_save_cannot_overload():
    p = proj("p13", skus=[sku(1, 10)])
    r = c.post("/api/web/optimize", json={"project": p, "specs": [SPEC], "mode": "locked"}).json()
    p["containers"] = r["proposedContainers"]
    assert c.put("/api/web/projects/p13", json={"project": p, "baseRev": None}).status_code == 200
    red = json.loads(json.dumps(p)); red["skus"][0]["requiredQty"] = 6          # giảm SL (cho phép)
    assert c.put("/api/web/projects/p13", json={"project": red, "baseRev": 1}).status_code == 200
    rec = json.loads(json.dumps(red))                                            # Tính lại: còn 6 thùng
    rec["containers"][0]["placements"] = rec["containers"][0]["placements"][:6]
    assert c.put("/api/web/projects/p13", json={"project": rec, "baseRev": 2}).status_code == 200
    # lưu thường mà quay về 10 thùng / yêu cầu 6 -> chặn
    assert c.put("/api/web/projects/p13", json={"project": red, "baseRev": 3}).status_code == 409
    # Lùi lại đúng trạng thái đó -> cho phép (validator vẫn báo V9)
    r = c.put("/api/web/projects/p13", json={"project": red, "baseRev": 3, "note": "Lùi lại: Tính lại", "specs": [SPEC]})
    assert r.status_code == 200 and any(i["code"] == "V9" for i in r.json()["validation"]["issues"])
