"""Test lõi: validator (bắt lỗi cố ý), engine (hợp lệ + tái lập), ledger (đối soát), luồng dự án.

Mã TCxx tương ứng danh sách test case trong spec.
"""
import io
import json
import random
import sqlite3

import pytest
from openpyxl import Workbook, load_workbook

from clos import db, service
from clos.engine.models import CargoItem, ContainerType, Placement, Rules
from clos.engine.packer import DEFAULT_VARIANTS, FFD_BASELINE, pack, solve
from clos.engine.run import optimize
from clos.engine.validator import validate
from clos.io.exporter import export_run
from clos.io.importer import import_excel

CT = ContainerType("T", "test", 6000, 2400, 2400)


def item(idx, l, w, h, q, code=6, stack=True, sku=None):
    return CargoItem(idx=idx, customer_sku=sku or f"S{idx}", factory_sku=f"F{idx}", description="",
                     length=l, width=w, height=h, quantity=q, orientation_code=code, stackable=stack)


# ----------------------------------------------------------------------------- validator: lỗi cố ý

def codes(rep):
    return {v.code for v in rep.errors}


def test_validator_accepts_clean_layout():
    it = [item(0, 1000, 1000, 1000, 2)]
    ps = [Placement(1, 0, 0, 0, 0, 1000, 1000, 1000, 0, 1, 1), Placement(1, 0, 0, 0, 1000, 1000, 1000, 1000, 0, 2, 2)]
    assert validate(ps, it, CT, Rules(), {0: 2}).ok


def test_V1_out_of_bounds():
    it = [item(0, 1000, 1000, 1000, 1)]
    ps = [Placement(1, 0, 5500, 0, 0, 1000, 1000, 1000, 0, 1, 1)]
    assert "V1" in codes(validate(ps, it, CT, Rules()))


def test_V2_overlap():
    it = [item(0, 1000, 1000, 1000, 2)]
    ps = [Placement(1, 0, 0, 0, 0, 1000, 1000, 1000, 0, 1, 1), Placement(1, 0, 999, 0, 0, 1000, 1000, 1000, 0, 2, 2)]
    assert "V2" in codes(validate(ps, it, CT, Rules()))


def test_V2_touching_is_not_overlap():
    it = [item(0, 1000, 1000, 1000, 2)]
    ps = [Placement(1, 0, 0, 0, 0, 1000, 1000, 1000, 0, 1, 1), Placement(1, 0, 1000, 0, 0, 1000, 1000, 1000, 0, 2, 2)]
    assert validate(ps, it, CT, Rules()).ok


def test_V3_orientation_not_allowed():
    it = [item(0, 1200, 800, 500, 1, code=1)]  # chỉ được 1 hướng
    ps = [Placement(1, 0, 0, 0, 0, 800, 1200, 500, 1, 1, 1)]
    assert "V3" in codes(validate(ps, it, CT, Rules()))


def test_V3_wrong_dims():
    it = [item(0, 1200, 800, 500, 1)]
    ps = [Placement(1, 0, 0, 0, 0, 1199, 800, 500, 0, 1, 1)]
    assert "V3" in codes(validate(ps, it, CT, Rules()))


def test_V4_on_non_stackable():
    it = [item(0, 1000, 1000, 1000, 1, stack=False), item(1, 1000, 1000, 500, 1)]
    ps = [Placement(1, 0, 0, 0, 0, 1000, 1000, 1000, 0, 1, 1), Placement(1, 1, 0, 0, 1000, 1000, 1000, 500, 0, 2, 2)]
    assert "V4" in codes(validate(ps, it, CT, Rules()))


def test_V7_floating_box():
    it = [item(0, 1000, 1000, 1000, 1)]
    ps = [Placement(1, 0, 0, 0, 500, 1000, 1000, 1000, 0, 1, 1)]
    assert "V7" in codes(validate(ps, it, CT, Rules()))


def test_V7_partial_support_threshold():
    it = [item(0, 1000, 1000, 1000, 2)]
    # thùng trên chỉ chồng 60% lên thùng dưới
    ps = [Placement(1, 0, 0, 0, 0, 1000, 1000, 1000, 0, 1, 1), Placement(1, 0, 400, 0, 1000, 1000, 1000, 1000, 0, 2, 2)]
    assert "V7" in codes(validate(ps, it, CT, Rules(min_support_ratio=0.75)))
    assert validate(ps, it, CT, Rules(min_support_ratio=0.5)).ok


def test_V9_overload_and_underload():
    it = [item(0, 1000, 1000, 1000, 1)]
    ps = [Placement(1, 0, 0, 0, 0, 1000, 1000, 1000, 0, 1, 1), Placement(1, 0, 1000, 0, 0, 1000, 1000, 1000, 0, 2, 2)]
    assert "V9" in codes(validate(ps, it, CT, Rules(), {0: 1}))
    rep = validate(ps[:1], it, CT, Rules(), {0: 2})
    assert rep.ok and any(v.code == "V9" for v in rep.violations)  # thiếu = cảnh báo


# ----------------------------------------------------------------------------- engine

def random_items(rng, n_sku):
    out = []
    for i in range(n_sku):
        l, w, h = rng.randint(300, 1500), rng.randint(250, 1100), rng.randint(150, 1200)
        out.append(item(i, l, w, h, rng.randint(1, 120), code=rng.choice([1, 2, 4, 6]), stack=rng.random() > 0.15))
    return out


@pytest.mark.parametrize("seed", range(12))
def test_engine_random_instances_are_valid(seed):
    """TC05/TC06/TC09: mọi phương án engine sinh ra phải qua Validator và khớp số lượng tuyệt đối."""
    rng = random.Random(seed)
    items = random_items(rng, rng.randint(2, 12))
    for v in DEFAULT_VARIANTS + (FFD_BASELINE,):
        s = pack(items, CT, Rules(), v)
        rep = validate(s.placements(), items, CT, Rules(), {i.idx: i.quantity for i in items})
        assert rep.ok, (v.name, rep.to_dict()["violations"][:3])
        loaded = {}
        for p in s.placements():
            loaded[p.item] = loaded.get(p.item, 0) + 1
        for i in items:
            assert loaded.get(i.idx, 0) + s.unplaced.get(i.idx, 0) == i.quantity


def test_engine_deterministic():
    items = random_items(random.Random(7), 8)
    a = optimize(items, CT, Rules(), "fast")[1]
    b = optimize(items, CT, Rules(), "fast")[1]
    assert json.dumps(a["containers"]) == json.dumps(b["containers"])
    c = optimize(items, CT, Rules(), "standard", seed=3)
    d = optimize(items, CT, Rules(), "standard", seed=3)
    assert c[1]["n_containers"] == d[1]["n_containers"]


def test_engine_respects_orientation_1():
    items = [item(0, 1200, 800, 500, 30, code=1)]
    s = pack(items, CT, Rules(), DEFAULT_VARIANTS[0])
    assert all((p.dx, p.dy, p.dz) == (1200, 800, 500) for p in s.placements())


def test_item_too_big_is_reported_not_dropped_silently():
    items = [item(0, 7000, 500, 500, 3, code=1), item(1, 500, 500, 500, 2)]
    s = pack(items, CT, Rules(), DEFAULT_VARIANTS[0])
    assert s.unplaced.get(0) == 3


def test_over_allowance_fills_with_extras_within_limit():
    items = [item(0, 1000, 1000, 1000, 10), item(1, 500, 500, 500, 10)]
    _, summ = optimize(items, CT, Rules(over_allowance_pct=20), "fast")
    for r in summ["reconciliation"]:
        assert r["loaded"] <= r["required"] + r["required"] * 0.2
        assert r["remaining"] == 0
    assert summ["validation"]["ok"]


# ----------------------------------------------------------------------------- import

def _xlsx(rows):
    wb = Workbook()
    ws = wb.active
    for r in rows:
        ws.append(r)
    p = io.BytesIO()
    wb.save(p)
    return p.getvalue()


HDR = ["Factory SKU", "Customer SKU", "Description", "Length (cm)", "Width (cm)", "Height (cm)", "Weight (kg)",
       "Quantity", "Stackable", "Orientation (1/2/4/6)", "Pallet (Y/N)"]


def test_TC01_import_valid(tmp_path):
    f = tmp_path / "ok.xlsx"
    f.write_bytes(_xlsx([HDR, ["F1", "C1", "Ghế", 92, 59, 31, None, 100, "Y", 6, "N"],
                         ["F2", "C2", "Bàn P", 192, 159, 212.4, 50, 6, "N", None, "Y"]]))
    r = import_excel(str(f))
    assert not r.errors and len(r.items) == 2
    assert r.items[0].dims == (920, 590, 310)
    assert r.items[1].orientation_code == 2 and r.items[1].height == 2124 and not r.items[1].stackable


def test_TC02_import_invalid(tmp_path):
    f = tmp_path / "bad.xlsx"
    f.write_bytes(_xlsx([HDR,
                         ["F1", "C1", "", None, 59, 31, None, 100, "Y", 6, "N"],      # thiếu dài
                         ["F2", "C2", "", 90, -5, 31, None, 100, "Y", 6, "N"],        # rộng âm
                         ["F3", "C3", "", 90, 50, 31, None, 1.5, "Y", 6, "N"],        # số lẻ
                         ["F4", "C4", "", 90, 50, 31, None, 10, "Y", 3, "N"],         # hướng sai
                         ["F5", "C5", "", 90, 50, 31, None, 10, "Y", 6, "N"],
                         ["F5", "C5", "", 91, 50, 31, None, 10, "Y", 6, "N"]]))      # trùng, khác kích thước
    r = import_excel(str(f))
    assert len(r.items) == 1
    msgs = " | ".join(e["message"] for e in r.errors)
    for k in ("thiếu Length", "Width phải > 0", "Quantity", "Orientation", "KHÁC kích thước"):
        assert k in msgs


# ----------------------------------------------------------------------------- ledger & luồng dự án

@pytest.fixture
def con(tmp_path):
    p = str(tmp_path / "t.db")
    db.init_db(p)
    c = sqlite3.connect(p)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON")
    yield c
    c.close()


def _project(con, items):
    from clos.io.importer import ImportResult
    pid = service.create_project(con, "T", "K", "x.xlsx", ImportResult(items=items))
    cid = con.execute("INSERT INTO container_types(code,name,length_mm,width_mm,height_mm) VALUES ('T','t',6000,2400,2400)").lastrowid
    return pid, cid


def test_ledger_blocks_negative_and_overload(con):
    pid, _ = _project(con, [item(0, 1000, 1000, 1000, 5)])
    lid = con.execute("SELECT id FROM cargo_lines").fetchone()[0]
    with pytest.raises(sqlite3.IntegrityError, match="vượt"):
        con.execute("INSERT INTO qty_transactions(project_id,cargo_line_id,container_no,delta,reason,created_at)"
                    " VALUES (?,?,1,6,'confirm_load','t')", (pid, lid))
    with pytest.raises(sqlite3.IntegrityError, match="âm"):
        con.execute("INSERT INTO qty_transactions(project_id,cargo_line_id,container_no,delta,reason,created_at)"
                    " VALUES (?,?,1,-1,'unload','t')", (pid, lid))
    con.execute("INSERT INTO qty_transactions(project_id,cargo_line_id,container_no,delta,reason,created_at)"
                " VALUES (?,?,1,3,'confirm_load','t')", (pid, lid))
    with pytest.raises(sqlite3.IntegrityError, match="không được sửa"):
        con.execute("UPDATE qty_transactions SET delta=1")
    with pytest.raises(sqlite3.IntegrityError, match="không được xoá"):
        con.execute("DELETE FROM qty_transactions")


def test_TC05_TC06_TC10_confirm_reconcile_export(con):
    items = random_items(random.Random(3), 6)
    pid, cid = _project(con, items)
    rid = service.run_optimization(con, pid, cid, Rules(), "fast")
    service.confirm_run(con, pid, rid)
    assert db.reconcile_check(con, pid, rid) == []
    for b in db.balance(con, pid):
        assert b["required"] == b["loaded"] + b["remaining"] and b["remaining"] >= 0
    # TC10: số trong file Excel xuất = số trong sổ
    wb = load_workbook(io.BytesIO(export_run(con, rid)))
    ws = wb["Doi soat so luong"]
    hdr = [c.value for c in ws[1]]
    i_load = hdr.index("Đã xếp")
    excel = {r[1]: r[i_load] for r in ws.iter_rows(min_row=2, values_only=True) if r[0] != "TỔNG" and r[1]}
    ledger = {b["customer_sku"]: b["loaded"] for b in db.balance(con, pid)}
    assert excel == ledger


def test_confirm_twice_requires_replace_and_keeps_history(con):
    items = random_items(random.Random(4), 4)
    pid, cid = _project(con, items)
    r1 = service.run_optimization(con, pid, cid, Rules(), "fast")
    service.confirm_run(con, pid, r1)
    r2 = service.run_optimization(con, pid, cid, Rules(min_support_ratio=1.0), "fast")
    with pytest.raises(service.BusinessError, match="Thay thế"):
        service.confirm_run(con, pid, r2)
    service.confirm_run(con, pid, r2, replace_existing=True)
    assert db.reconcile_check(con, pid, r2) == []
    n_unload = con.execute("SELECT COUNT(*) FROM qty_transactions WHERE reason='unload'").fetchone()[0]
    assert n_unload > 0  # lịch sử được giữ bằng giao dịch hoàn trả, không xoá


def test_TC03_TC04_partial_recalc_keeps_locked_containers(con):
    items = [item(0, 1100, 1100, 1100, 40), item(1, 600, 400, 400, 60), item(2, 800, 500, 300, 50)]
    pid, cid = _project(con, items)
    r1 = service.run_optimization(con, pid, cid, Rules(), "fast")
    s1 = json.loads(con.execute("SELECT summary FROM optimization_runs WHERE id=?", (r1,)).fetchone()[0])
    assert s1["n_containers"] >= 2
    keep_no = s1["containers"][0]["no"]
    keep_blocks = s1["containers"][0]["blocks"]
    # TC03: tăng số lượng 1 SKU sau khi đã có phương án
    lid = con.execute("SELECT id FROM cargo_lines WHERE idx=1").fetchone()[0]
    service.update_line(con, pid, lid, {"required": 90})
    r2, rep = service.run_partial(con, pid, r1, [keep_no], Rules(), "fast")
    s2 = json.loads(con.execute("SELECT summary FROM optimization_runs WHERE id=?", (r2,)).fetchone()[0])
    kept = [c for c in s2["containers"] if c["no"] == keep_no][0]
    strip = lambda bs: sorted((b["item"], b["x0"], b["y0"], b["z0"], b["count"]) for b in bs)  # noqa: E731
    assert strip(kept["blocks"]) == strip(keep_blocks)       # cont giữ nguyên
    assert s2["validation"]["ok"]
    assert {r["customer_sku"]: r["loaded"] for r in s2["reconciliation"]}["S1"] == 90


def test_TC12_dimension_change_drops_invalid_kept_container(con):
    items = [item(0, 1100, 1100, 1100, 30), item(1, 600, 400, 400, 40)]
    pid, cid = _project(con, items)
    r1 = service.run_optimization(con, pid, cid, Rules(), "fast")
    s1 = json.loads(con.execute("SELECT summary FROM optimization_runs WHERE id=?", (r1,)).fetchone()[0])
    nos = [c["no"] for c in s1["containers"]]
    lid = con.execute("SELECT id FROM cargo_lines WHERE idx=0").fetchone()[0]
    con.execute("UPDATE optimization_runs SET status='draft'")
    service.confirm_run(con, pid, r1)
    res = service.update_line(con, pid, lid, {"length_mm": 1150})
    assert res["affected_containers"]  # báo cont bị ảnh hưởng
    r2, rep = service.run_partial(con, pid, r1, nos, Rules(), "fast")
    dropped = {d["no"] for d in rep["dropped"]}
    assert set(res["affected_containers"]) <= dropped
    s2 = json.loads(con.execute("SELECT summary FROM optimization_runs WHERE id=?", (r2,)).fetchone()[0])
    assert s2["validation"]["ok"]
