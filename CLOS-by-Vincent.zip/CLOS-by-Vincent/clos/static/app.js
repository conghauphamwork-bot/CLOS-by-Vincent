import * as THREE from "three";
import { OrbitControls } from "/static/vendor/OrbitControls.js";

const $app = document.getElementById("app");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const cm = (mm) => (mm / 10).toLocaleString("vi-VN", { maximumFractionDigits: 1 });
const pct = (x) => (x * 100).toFixed(1) + "%";
const fmt = (n) => Number(n ?? 0).toLocaleString("vi-VN");

async function api(path, opts = {}) {
  const res = await fetch(path, { headers: opts.body && !(opts.body instanceof FormData) ? { "Content-Type": "application/json" } : {}, ...opts });
  if (!res.ok) {
    let msg = res.statusText;
    try { msg = (await res.json()).detail || msg; } catch (_) {}
    throw new Error(typeof msg === "string" ? msg : JSON.stringify(msg));
  }
  return res.json();
}
function toast(msg, err = false) {
  const t = document.getElementById("toast");
  t.textContent = msg; t.className = "toast" + (err ? " err" : "");
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.add("hidden"), err ? 9000 : 4000);
}
function busy(on, text = "Đang xử lý…") {
  document.getElementById("busy-text").textContent = text;
  document.getElementById("busy").classList.toggle("hidden", !on);
}
async function guard(fn, text) {
  busy(true, text);
  try { return await fn(); } catch (e) { toast(e.message, true); } finally { busy(false); }
}
const statusBadge = (s) => ({
  PROVEN_OPTIMAL: '<span class="badge b-ok">Tối ưu về số cont</span>',
  FEASIBLE: '<span class="badge b-info">Hợp lệ (heuristic)</span>',
  PARTIAL: '<span class="badge b-err">Còn hàng chưa xếp</span>',
  NO_SOLUTION: '<span class="badge b-err">Không xếp được</span>',
}[s] || esc(s));
const runBadge = (s) => ({ draft: '<span class="badge b-info">Nháp</span>', confirmed: '<span class="badge b-ok">Đã xác nhận</span>', superseded: '<span class="badge b-warn">Đã thay</span>' }[s] || s);

// ----------------------------------------------------------------------------- router

function route() {
  disposeViewer();
  const h = location.hash.replace(/^#/, "") || "/";
  const parts = h.split("/").filter(Boolean);
  document.querySelectorAll("[data-nav]").forEach((a) => a.classList.toggle("active",
    (parts[0] === "containers" && a.dataset.nav === "containers") || (parts[0] !== "containers" && a.dataset.nav === "projects")));
  if (parts[0] === "containers") return viewContainers();
  if (parts[0] === "p") return viewProject(+parts[1], parts[2] || "cargo");
  if (parts[0] === "r") return viewRun(+parts[1]);
  return viewProjects();
}

// ----------------------------------------------------------------------------- dự án
async function viewProjects() {
  const list = await api("/api/projects");
  $app.innerHTML = `
  <h1>Dự án xếp container</h1><div class="sub">Mỗi dự án = 1 lô hàng (1 file Excel). Dữ liệu lưu trên máy này, mở lại sửa tiếp được.</div>
  <div class="panel">
    <h2>Tạo dự án từ Excel</h2>
    <div class="row">
      <label>File Excel (.xlsx / .xlsm)<input type="file" id="f" accept=".xlsx,.xlsm"></label>
      <label>Tên dự án<input id="pname" placeholder="VD: Đơn hàng CRD 2027"></label>
      <label>Khách hàng<input id="pcust" placeholder="VD: Khách hàng A"></label>
      <button id="btn-import">Import</button>
    </div>
    <div class="muted mt">Nhận 2 dạng: file Excel có sheet <b>CargoWiz</b> + <b>PKT dien kich thuoc</b>) hoặc <a href="/api/template.xlsx">template CLOS</a>.</div>
    <div id="imp-report"></div>
  </div>
  <div class="panel">
    <h2>Danh sách dự án</h2>
    ${list.length ? `<table><thead><tr><th>#</th><th>Tên</th><th>Khách</th><th class="num">Số mã</th><th class="num">Số phương án</th><th>Trạng thái</th><th>Tạo lúc</th></tr></thead><tbody>
    ${list.map((p) => `<tr class="click" data-href="#/p/${p.id}"><td>${p.id}</td><td>${esc(p.name)}</td><td>${esc(p.customer)}</td>
      <td class="num">${p.n_lines}</td><td class="num">${p.n_runs}</td><td>${p.status === "planning" ? '<span class="badge b-ok">Đã có kế hoạch</span>' : '<span class="badge b-info">Nháp</span>'}</td><td>${esc(p.created_at)}</td></tr>`).join("")}
    </tbody></table>` : '<div class="muted">Chưa có dự án nào.</div>'}
  </div>`;
  bindRows();
  document.getElementById("btn-import").onclick = () => guard(async () => {
    const f = document.getElementById("f").files[0];
    if (!f) throw new Error("Chọn file Excel trước");
    const fd = new FormData();
    fd.append("file", f); fd.append("name", document.getElementById("pname").value); fd.append("customer", document.getElementById("pcust").value);
    const r = await api("/api/projects/import", { method: "POST", body: fd });
    if (!r.project_id) {
      document.getElementById("imp-report").innerHTML = importReport(r.report);
      throw new Error("Không có dòng hợp lệ — xem lỗi bên dưới");
    }
    toast(`Đã import ${r.n_items} mã hàng`);
    location.hash = `#/p/${r.project_id}`;
  }, "Đang đọc file Excel…");
}

function importReport(rep) {
  if (!rep) return "";
  const e = rep.errors || [], w = rep.warnings || [];
  const infl = w.filter((x) => x.code === "inflated_qty");
  const other = w.filter((x) => x.code !== "inflated_qty");
  return `
  ${e.length ? `<div class="msg err"><b>${e.length} dòng bị từ chối</b> (không được import):<ul>${e.map((x) => `<li>Dòng ${x.row ?? "-"} ${esc(x.sku || "")}: ${esc(x.message)}</li>`).join("")}</ul></div>` : '<div class="msg ok">Không có dòng nào bị từ chối.</div>'}
  ${infl.length ? `<div class="msg warn"><b>${infl.length} mã nhập CargoWiz khác số yêu cầu</b> (thường ×1,3 để lấp cont). CLOS dùng <b>số yêu cầu</b> ở cột Description; muốn xếp dư hãy bật "dung sai dư" khi chạy tối ưu.</div>` : ""}
  ${other.length ? `<div class="msg warn"><b>${other.length} cảnh báo</b><ul>${other.slice(0, 30).map((x) => `<li>${x.row ? "Dòng " + x.row + " " : ""}${esc(x.sku || "")} ${esc(x.message)}</li>`).join("")}</ul></div>` : ""}`;
}

function bindRows() {
  document.querySelectorAll("tr[data-href]").forEach((tr) => (tr.onclick = () => (location.hash = tr.dataset.href)));
}

async function viewProject(pid, tab) {
  const p = await api(`/api/projects/${pid}`);
  const tabs = [["cargo", "Hàng hoá"], ["optimize", "Tối ưu & phương án"], ["recon", "Đối soát số lượng"], ["history", "Lịch sử"]];
  $app.innerHTML = `
  <div class="flex"><div><h1>${esc(p.name)}</h1><div class="sub">${esc(p.customer || "")} · file ${esc(p.source_file || "")} · ${p.lines.length} mã hàng</div></div></div>
  <div class="tabs">${tabs.map(([k, l]) => `<a href="#/p/${pid}/${k}" class="${k === tab ? "active" : ""}">${l}</a>`).join("")}</div>
  <div id="tab"></div>`;
  const el = document.getElementById("tab");
  if (tab === "cargo") return tabCargo(el, p);
  if (tab === "optimize") return tabOptimize(el, p);
  if (tab === "recon") return tabRecon(el, p);
  if (tab === "history") return tabHistory(el, p);
}

function tabCargo(el, p) {
  const tot = p.lines.reduce((a, l) => a + l.required, 0);
  const vol = p.lines.reduce((a, l) => a + l.required * l.length_mm * l.width_mm * l.height_mm, 0) / 1e9;
  el.innerHTML = `
  <div class="kpis"><div class="kpi"><div class="v">${p.lines.length}</div><div class="l">Mã hàng</div></div>
  <div class="kpi"><div class="v">${fmt(tot)}</div><div class="l">Carton/pallet yêu cầu</div></div>
  <div class="kpi"><div class="v">${vol.toFixed(1)} m³</div><div class="l">Tổng thể tích hàng</div></div></div>
  <details class="panel"><summary><b>Báo cáo import</b></summary>${importReport(p.import_report)}</details>
  <div class="panel"><h2>Danh sách hàng</h2><div class="muted">Bấm "Sửa" để đổi kích thước / số lượng. Đổi số lượng được ghi thành giao dịch có lý do, không ghi đè.</div>
  <div class="scroll mt"><table><thead><tr><th></th><th>Customer SKU</th><th>Factory SKU</th><th>Mô tả</th><th class="num">D×R×C (cm)</th><th class="num">Hướng</th><th>Loại</th><th>Chồng</th><th class="num">Yêu cầu</th><th class="num">Đã xếp</th><th class="num">Còn lại</th><th></th></tr></thead><tbody>
  ${p.lines.map((l) => `<tr><td><span class="sw" style="display:inline-block;background:${l.color}"></span></td><td><b>${esc(l.customer_sku)}</b></td><td>${esc(l.factory_sku)}</td><td>${esc(l.description)}</td>
  <td class="num">${cm(l.length_mm)}×${cm(l.width_mm)}×${cm(l.height_mm)}</td><td class="num">${l.orientation_code}</td><td>${l.is_pallet ? "Pallet" : "Carton"}</td><td>${l.stackable ? "Có" : "Không"}</td>
  <td class="num">${fmt(l.required)}</td><td class="num">${fmt(l.loaded)}</td><td class="num">${fmt(l.remaining)}</td><td><button class="small ghost" data-edit="${l.id}">Sửa</button></td></tr>`).join("")}
  </tbody></table></div></div>`;
  el.querySelectorAll("[data-edit]").forEach((b) => (b.onclick = () => editLine(p, +b.dataset.edit)));
}

async function editLine(p, lid) {
  const l = p.lines.find((x) => x.id === lid);
  const v = prompt(`Sửa ${l.customer_sku}\nNhập theo dạng: dài,rộng,cao (cm);số lượng yêu cầu;hướng (1/2/4/6);chồng (Y/N)\nVD: 92,59,31;1210;6;Y`,
    `${cm(l.length_mm)},${cm(l.width_mm)},${cm(l.height_mm)};${l.required};${l.orientation_code};${l.stackable ? "Y" : "N"}`);
  if (v === null) return;
  const [d, q, o, s] = v.split(";").map((x) => x.trim());
  const [L, W, H] = d.split(",").map((x) => parseFloat(x));
  const body = { length_cm: L, width_cm: W, height_cm: H, required: parseInt(q), orientation_code: parseInt(o), stackable: /^y/i.test(s || "y") };
  if (body.required !== l.required) body.note = prompt("Lý do đổi số lượng (lưu vào lịch sử):", "Khách đổi số lượng") || "Sửa số lượng";
  await guard(async () => {
    const r = await api(`/api/projects/${p.id}/lines/${lid}`, { method: "PATCH", body: JSON.stringify(body) });
    if (r.affected_containers?.length) toast(`Đã lưu. Cont bị ảnh hưởng trong kế hoạch đã xác nhận: ${r.affected_containers.join(", ")} — vào phương án và chọn "Tính lại, giữ cont khác".`);
    else toast("Đã lưu");
    route();
  });
}

async function tabOptimize(el, p) {
  const [cts, modes] = await Promise.all([api("/api/container-types"), api("/api/modes")]);
  const cw = p.import_report?.cargowiz_result;
  el.innerHTML = `
  <div class="panel"><h2>Chạy tối ưu</h2>
  <div class="row">
    <label>Loại cont<select id="ct">${cts.map((c) => `<option value="${c.id}">${esc(c.name)} — ${cm(c.length_mm)}×${cm(c.width_mm)}×${cm(c.height_mm)} cm</option>`).join("")}</select></label>
    <label>Chế độ<select id="mode">${Object.entries(modes).map(([k, m]) => `<option value="${k}" ${k === "standard" ? "selected" : ""}>${esc(m.label)}</option>`).join("")}</select></label>
    <label>Tỉ lệ đỡ đáy tối thiểu α <span class="badge b-warn">chưa xác nhận</span><input id="alpha" type="number" step="0.05" min="0.5" max="1" value="0.75"></label>
    <label>Dung sai dư mỗi mã (%) <span class="badge b-warn">chưa xác nhận</span><input id="over" type="number" step="1" min="0" max="50" value="0"></label>
    <label>Seed<input id="seed" type="number" value="1"></label>
    <button id="run">Chạy tối ưu</button>
  </div>
  <div class="muted mt">Mọi phương án đều qua Validator độc lập trước khi hiển thị. Cùng dữ liệu + cùng seed ⇒ cùng kết quả.</div>
  ${cw ? `<div class="msg warn">File có kết quả CargoWiz cũ: <b>${cw.n_containers} cont</b>. Dùng để so sánh.</div>` : ""}
  </div>
  <div class="panel"><h2>Các phương án</h2>
  ${p.runs.length ? `<table><thead><tr><th>#</th><th>Tạo lúc</th><th>Chế độ</th><th class="num">Số cont</th><th class="num">Cận dưới</th><th class="num">Gap</th><th>Lời giải</th><th>Validator</th><th>Trạng thái</th><th class="num">Giây</th></tr></thead><tbody>
  ${p.runs.map((r) => `<tr class="click" data-href="#/r/${r.id}"><td>${r.id}</td><td>${esc(r.created_at)}</td><td>${esc(r.mode)}</td><td class="num"><b>${r.n_containers}</b></td><td class="num">${r.lower_bound}</td><td class="num">${r.gap != null ? pct(r.gap) : "-"}</td><td>${statusBadge(r.solver_status)}</td><td>${r.valid ? '<span class="badge b-ok">Đạt</span>' : '<span class="badge b-err">Lỗi</span>'}</td><td>${runBadge(r.status)}</td><td class="num">${r.seconds}</td></tr>`).join("")}
  </tbody></table>` : '<div class="muted">Chưa có phương án.</div>'}</div>`;
  bindRows();
  document.getElementById("run").onclick = () => guard(async () => {
    const body = { container_type_id: +ct.value, mode: mode.value, seed: +seed.value, min_support_ratio: +alpha.value, over_allowance_pct: +over.value };
    const r = await api(`/api/projects/${p.id}/runs`, { method: "POST", body: JSON.stringify(body) });
    location.hash = `#/r/${r.run_id}`;
  }, "Đang tính phương án xếp… (chế độ Chuẩn ~30 giây)");
  const { ct, mode, seed, alpha, over } = Object.fromEntries(["ct", "mode", "seed", "alpha", "over"].map((k) => [k, document.getElementById(k)]));
}

function tabRecon(el, p) {
  const nos = [...new Set(p.lines.flatMap((l) => Object.keys(l.by_container)))].map(Number).sort((a, b) => a - b);
  const bad = p.lines.filter((l) => l.required !== l.loaded + l.remaining || l.remaining < 0);
  el.innerHTML = `
  <div class="panel"><h2>Sổ số lượng (kế hoạch đã xác nhận)</h2>
  <div class="msg ${bad.length ? "err" : "ok"}">Kiểm tra Required = Loaded + Remaining: <b>${bad.length ? bad.length + " mã lệch" : "tất cả " + p.lines.length + " mã khớp"}</b>.
  Số liệu lấy từ sổ giao dịch chỉ-ghi-thêm, không tính lại từ giao diện.</div>
  ${nos.length ? "" : '<div class="muted">Chưa xác nhận phương án nào — số đã xếp đang = 0.</div>'}
  <div class="scroll"><table><thead><tr><th>Customer SKU</th><th>Factory SKU</th><th>Mô tả</th><th class="num">Yêu cầu</th>${nos.map((n) => `<th class="num">C${n}</th>`).join("")}<th class="num">Đã xếp</th><th class="num">Còn lại</th></tr></thead><tbody>
  ${p.lines.map((l) => `<tr><td><b>${esc(l.customer_sku)}</b></td><td>${esc(l.factory_sku)}</td><td>${esc(l.description)}</td><td class="num">${fmt(l.required)}</td>${nos.map((n) => `<td class="num">${l.by_container[n] || ""}</td>`).join("")}<td class="num">${fmt(l.loaded)}</td><td class="num">${l.remaining ? `<span class="badge b-warn">${fmt(l.remaining)}</span>` : "0"}</td></tr>`).join("")}
  </tbody></table></div></div>`;
}

async function tabHistory(el, p) {
  const h = await api(`/api/projects/${p.id}/audit`);
  const reason = { confirm_load: "Xác nhận xếp", unload: "Hoàn trả", adjust_required: "Đổi số yêu cầu" };
  el.innerHTML = `<div class="grid2">
  <div class="panel"><h2>Giao dịch số lượng</h2><div class="scroll"><table><thead><tr><th>Lúc</th><th>SKU</th><th class="num">Cont</th><th class="num">+/−</th><th>Loại</th><th>Ghi chú</th></tr></thead><tbody>
  ${h.transactions.map((t) => `<tr><td>${esc(t.created_at)}</td><td>${esc(t.customer_sku)}</td><td class="num">${t.container_no ?? ""}</td><td class="num">${t.delta > 0 ? "+" : ""}${t.delta}</td><td>${reason[t.reason] || t.reason}</td><td>${esc(t.note || "")}</td></tr>`).join("") || '<tr><td colspan="6" class="muted">Chưa có</td></tr>'}
  </tbody></table></div></div>
  <div class="panel"><h2>Nhật ký thao tác</h2><div class="scroll"><table><thead><tr><th>Lúc</th><th>Đối tượng</th><th>Hành động</th><th>Chi tiết</th></tr></thead><tbody>
  ${h.audit.map((a) => `<tr><td>${esc(a.at)}</td><td>${esc(a.entity)} #${a.entity_id ?? ""}</td><td>${esc(a.action)}</td><td style="white-space:normal;max-width:380px" class="muted">${esc(a.detail).slice(0, 220)}</td></tr>`).join("")}
  </tbody></table></div></div></div>`;
}

// ----------------------------------------------------------------------------- loại cont
async function viewContainers() {
  const cts = await api("/api/container-types");
  $app.innerHTML = `<h1>Loại container</h1><div class="sub">Kích thước dùng được (đã trừ hao). Không hardcode — thêm loại mới tại đây.</div>
  <div class="panel"><table><thead><tr><th>Mã</th><th>Tên</th><th class="num">Dài (cm)</th><th class="num">Rộng (cm)</th><th class="num">Cao (cm)</th><th class="num">Thể tích (m³)</th><th>Ghi chú</th></tr></thead><tbody>
  ${cts.map((c) => `<tr><td>${esc(c.code)}</td><td>${esc(c.name)}</td><td class="num">${cm(c.length_mm)}</td><td class="num">${cm(c.width_mm)}</td><td class="num">${cm(c.height_mm)}</td><td class="num">${(c.length_mm * c.width_mm * c.height_mm / 1e9).toFixed(2)}</td><td class="muted">${esc(c.note || "")}</td></tr>`).join("")}
  </tbody></table></div>
  <div class="panel"><h2>Thêm loại cont</h2><div class="row">
  <label>Mã<input id="c-code" placeholder="40HC-CUSTOM2"></label><label>Tên<input id="c-name" placeholder="40' HC tuỳ chỉnh 2"></label>
  <label>Dài (cm)<input id="c-l" type="number" step="0.5"></label><label>Rộng (cm)<input id="c-w" type="number" step="0.5"></label><label>Cao (cm)<input id="c-h" type="number" step="0.5"></label>
  <label>Ghi chú<input id="c-note"></label><button id="c-add">Thêm</button></div></div>`;
  document.getElementById("c-add").onclick = () => guard(async () => {
    const g = (id) => document.getElementById(id).value;
    await api("/api/container-types", { method: "POST", body: JSON.stringify({ code: g("c-code"), name: g("c-name"), length_cm: +g("c-l"), width_cm: +g("c-w"), height_cm: +g("c-h"), note: g("c-note") }) });
    toast("Đã thêm"); route();
  });
}

// ----------------------------------------------------------------------------- workspace phương án
let viewer = null;
function disposeViewer() { if (viewer) { viewer.dispose(); viewer = null; } }

async function viewRun(rid) {
  const r = await api(`/api/runs/${rid}`);
  const s = r.summary;
  const lines = Object.fromEntries(r.lines.map((l) => [l.idx, l]));
  const v = s.validation;
  const recon = s.reconciliation;
  const nMatch = recon.filter((x) => x.status === "khớp").length;
  const locked = new Set(s.locked_containers || []);
  let cur = s.containers[0]?.no;
  $app.innerHTML = `
  <div class="flex"><div><h1>Phương án #${rid} ${runBadge(r.status)}</h1>
  <div class="sub"><a href="#/p/${r.project_id}/optimize">← về dự án</a> · ${esc(s.config.container_type.name)} · chế độ ${esc(r.mode)} · seed ${r.seed} · input ${esc(r.input_hash)} · ${r.seconds}s</div></div>
  <div class="spacer"></div>
  <a href="/api/runs/${rid}/export.xlsx"><button class="secondary">Xuất Excel</button></a>
  <button id="partial" class="secondary">Tính lại, giữ cont đã khoá</button>
  <button id="confirm" ${r.status !== "draft" || !r.valid ? "disabled" : ""}>Xác nhận vào sổ số lượng</button></div>
  <div class="kpis">
    <div class="kpi"><div class="v">${s.n_containers}</div><div class="l">Số cont</div></div>
    <div class="kpi"><div class="v">${s.lower_bound}</div><div class="l">Cận dưới (thể tích)</div></div>
    <div class="kpi"><div class="v">${s.gap != null ? pct(s.gap) : "-"}</div><div class="l">Gap so với cận dưới</div></div>
    <div class="kpi"><div class="v">${pct(s.avg_volume_util)}</div><div class="l">Độ đầy thể tích TB</div></div>
    <div class="kpi"><div class="v">${nMatch}/${recon.length}</div><div class="l">Mã khớp đúng số yêu cầu</div></div>
    <div class="kpi"><div class="v">${v.ok ? '<span style="color:var(--ok)">Đạt</span>' : '<span style="color:var(--err)">' + v.n_errors + " lỗi</span>"}</div><div class="l">Validator (${v.checked.join(", ")})</div></div>
  </div>
  <div class="msg ${s.solver_status === "PROVEN_OPTIMAL" ? "ok" : "warn"}">${statusBadge(s.solver_status)} ${esc(s.status_note)}.
  ${s.partial ? ` Giữ nguyên cont: <b>${s.partial.kept.join(", ") || "không"}</b>${s.partial.dropped.length ? ` · Không giữ được: ${s.partial.dropped.map((d) => `cont ${d.no} (${esc(d.reasons.join("; "))})`).join(", ")}` : ""}.` : ""}
  ${Object.keys(s.unplaced).length ? `<br><b>Chưa xếp được:</b> ${Object.entries(s.unplaced).map(([k, q]) => `${esc(k)}: ${q}`).join(", ")}` : ""}</div>
  ${v.skipped.length ? `<div class="muted">Chưa kiểm: ${v.skipped.map((x) => `${x.code} – ${esc(x.reason)}`).join(" · ")}</div>` : ""}
  ${v.violations.length ? `<details class="panel"><summary><b>${v.violations.length} ghi chú Validator</b></summary><table><tbody>${v.violations.slice(0, 200).map((x) => `<tr><td>${x.code}</td><td>${x.level === "error" ? '<span class="badge b-err">Lỗi</span>' : '<span class="badge b-warn">Cảnh báo</span>'}</td><td>${x.container ?? ""}</td><td>${esc(x.message)}</td></tr>`).join("")}</tbody></table></details>` : ""}
  <div class="ws mt">
    <div class="panel contlist"><h2>Container</h2><div id="clist"></div></div>
    <div><div id="viewer"><div class="vtools"><span id="vname"></span><span>Bước xếp</span><input type="range" id="step" min="0" value="0"><span id="steplabel"></span>
      <button class="small ghost" id="vreset">Góc nhìn</button></div><div class="tip" id="tip"></div></div>
      <div class="panel mt"><h2>Thứ tự xếp (từ vách trong ra cửa)</h2><div class="scroll" style="max-height:260px" id="steps"></div></div></div>
    <div class="panel legend"><h2>Chú giải</h2><div class="muted">Bấm 1 mã để làm nổi bật. Số trong ngoặc: số thùng của mã trong cont này.</div><div id="legend"></div></div>
  </div>
  <div class="panel"><h2>Đối soát số lượng của phương án</h2><div class="scroll"><table><thead><tr><th>Customer SKU</th><th>Factory SKU</th><th>Mô tả</th><th class="num">Yêu cầu</th>${s.containers.map((c) => `<th class="num">C${c.no}</th>`).join("")}<th class="num">Đã xếp</th><th class="num">Còn lại</th><th class="num">Dư</th><th>Tình trạng</th></tr></thead><tbody>
  ${recon.map((x) => `<tr><td><b>${esc(x.customer_sku)}</b></td><td>${esc(x.factory_sku)}</td><td>${esc(x.description)}</td><td class="num">${fmt(x.required)}</td>${s.containers.map((c) => `<td class="num">${x.by_container[c.no] || ""}</td>`).join("")}<td class="num">${fmt(x.loaded)}</td><td class="num">${x.remaining}</td><td class="num">${x.extra}</td><td>${x.status === "khớp" ? '<span class="badge b-ok">khớp</span>' : `<span class="badge b-warn">${x.status}</span>`}</td></tr>`).join("")}
  </tbody></table></div></div>`;

  viewer = createViewer(document.getElementById("viewer"), s.config.container_type);
  const renderList = () => {
    document.getElementById("clist").innerHTML = s.containers.map((c) => `<div class="c ${c.no === cur ? "active" : ""}" data-no="${c.no}">
      <div style="flex:1"><div class="flex"><input type="checkbox" data-lock="${c.no}" ${locked.has(c.no) ? "checked" : ""} title="Khoá cont này khi tính lại"><b>Cont ${c.no}</b><span class="spacer"></span><span class="muted">${pct(c.volume_util)}</span></div>
      <div class="bar"><div style="width:${Math.min(100, c.volume_util * 100)}%"></div></div><div class="muted" style="font-size:11px">${c.n_boxes} thùng · ${Object.keys(c.counts).length} mã</div></div></div>`).join("");
    document.querySelectorAll("#clist .c").forEach((d) => (d.onclick = (e) => { if (e.target.dataset.lock) return; cur = +d.dataset.no; renderList(); show(); }));
    document.querySelectorAll("[data-lock]").forEach((cb) => (cb.onchange = () => { const n = +cb.dataset.lock; cb.checked ? locked.add(n) : locked.delete(n); }));
  };
  let focus = null;
  const show = () => {
    const c = s.containers.find((x) => x.no === cur);
    if (!c) return;
    document.getElementById("vname").innerHTML = `<b>Cont ${c.no}</b> · ${pct(c.volume_util)} · dùng ${cm(c.used_length)} cm`;
    const st = document.getElementById("step");
    st.max = c.blocks.length; st.value = c.blocks.length;
    const upd = () => { viewer.setStep(+st.value); document.getElementById("steplabel").textContent = `${st.value}/${c.blocks.length}`; };
    st.oninput = upd;
    viewer.load(c, lines, focus);
    upd();
    const tot = Object.fromEntries(recon.map((x) => [x.customer_sku, x]));
    const skus = Object.entries(c.counts).sort((a, b) => b[1] - a[1]);
    document.getElementById("legend").innerHTML = skus.map(([sku, n]) => {
      const l = r.lines.find((x) => x.customer_sku === sku); const t = tot[sku];
      return `<div class="li ${focus && focus !== sku ? "dim" : ""}" data-sku="${esc(sku)}"><div class="sw" style="background:${l.color}"></div>
      <div><div class="sku">${esc(sku)} <span class="muted">(${n})</span></div><div class="meta">${esc(l.factory_sku)} · ${esc(l.description)}</div>
      <div class="meta">${cm(l.length_mm)}×${cm(l.width_mm)}×${cm(l.height_mm)} cm · ${l.is_pallet ? "Pallet" : "Carton"} · hướng ${l.orientation_code}</div></div>
      <div class="right meta">YC ${fmt(t.required)}<br>Xếp ${fmt(t.loaded)}<br>Còn ${fmt(t.remaining)}</div></div>`;
    }).join("");
    document.querySelectorAll(".legend .li").forEach((d) => (d.onclick = () => { focus = focus === d.dataset.sku ? null : d.dataset.sku; show(); }));
    document.getElementById("steps").innerHTML = `<table><thead><tr><th class="num">Bước</th><th>SKU</th><th class="num">SL</th><th>Bố trí</th><th>Kích thước đặt (cm)</th><th class="num">Cách vách trong</th><th class="num">Từ trái</th><th class="num">Từ sàn</th></tr></thead><tbody>
      ${c.blocks.map((b) => `<tr class="click" data-step="${b.step}"><td class="num">${b.step}</td><td>${esc(b.sku)}${b.extra ? ' <span class="badge b-warn">dư</span>' : ""}</td><td class="num">${b.count}</td><td>${b.nx}×${b.ny}×${b.nz}</td><td>${cm(b.dx)}×${cm(b.dy)}×${cm(b.dz)}</td><td class="num">${cm(b.x0)}</td><td class="num">${cm(b.y0)}</td><td class="num">${cm(b.z0)}</td></tr>`).join("")}</tbody></table>`;
    document.querySelectorAll("#steps tr[data-step]").forEach((tr) => (tr.onclick = () => { st.value = tr.dataset.step; upd(); }));
  };
  renderList(); show();
  document.getElementById("vreset").onclick = () => viewer.resetView();

  document.getElementById("confirm").onclick = () => guard(async () => {
    try {
      await api(`/api/runs/${rid}/confirm`, { method: "POST", body: JSON.stringify({ replace: false }) });
    } catch (e) {
      if (!/Thay thế/.test(e.message)) throw e;
      busy(false);
      if (!confirm(e.message + "\n\nThay thế kế hoạch cũ bằng phương án này?")) return;
      await api(`/api/runs/${rid}/confirm`, { method: "POST", body: JSON.stringify({ replace: true }) });
    }
    toast("Đã xác nhận. Sổ số lượng đã cập nhật và đối soát khớp.");
    route();
  }, "Đang ghi sổ và đối soát…");
  document.getElementById("partial").onclick = () => guard(async () => {
    if (!locked.size) throw new Error("Tick ô ở các cont muốn giữ nguyên trước (danh sách bên trái)");
    const body = { base_run_id: rid, keep: [...locked], container_type_id: r.container_type_id, mode: "standard", seed: r.seed,
      min_support_ratio: s.config.rules.min_support_ratio, over_allowance_pct: s.config.rules.over_allowance_pct };
    const res = await api(`/api/projects/${r.project_id}/runs/partial`, { method: "POST", body: JSON.stringify(body) });
    toast(`Tạo phương án #${res.run_id}: giữ ${res.report.kept.length} cont, ${res.report.dropped.length} cont không còn hợp lệ.`);
    location.hash = `#/r/${res.run_id}`;
  }, "Đang tính lại phần còn lại…");
}

// ----------------------------------------------------------------------------- 3D
function createViewer(host, ct) {
  const W = () => host.clientWidth, H = () => host.clientHeight;
  const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(W(), H());
  host.prepend(renderer.domElement);
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xeef2f6);
  const L = ct.length / 1000, Wd = ct.width / 1000, Hh = ct.height / 1000;
  const camera = new THREE.PerspectiveCamera(40, W() / H(), 0.05, 200);
  const controls = new OrbitControls(camera, renderer.domElement);
  scene.add(new THREE.HemisphereLight(0xffffff, 0x8899aa, 1.6));
  const dl = new THREE.DirectionalLight(0xffffff, 1.4); dl.position.set(-4, 8, 6); scene.add(dl);
  // khung cont + sàn + đánh dấu cửa
  const frame = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(L, Hh, Wd)), new THREE.LineBasicMaterial({ color: 0x1f4e79 }));
  frame.position.set(L / 2, Hh / 2, Wd / 2); scene.add(frame);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(L, Wd), new THREE.MeshBasicMaterial({ color: 0xd6dde5 }));
  floor.rotation.x = -Math.PI / 2; floor.position.set(L / 2, 0, Wd / 2); scene.add(floor);
  const door = new THREE.Mesh(new THREE.PlaneGeometry(Wd, Hh), new THREE.MeshBasicMaterial({ color: 0xc62828, transparent: true, opacity: 0.07, side: THREE.DoubleSide }));
  door.rotation.y = Math.PI / 2; door.position.set(L, Hh / 2, Wd / 2); scene.add(door);
  const doorLabel = makeLabel("CỬA"); doorLabel.position.set(L + 0.15, Hh + 0.25, Wd / 2); scene.add(doorLabel);
  const backLabel = makeLabel("VÁCH TRONG"); backLabel.position.set(-0.2, Hh + 0.25, Wd / 2); scene.add(backLabel);

  let group = new THREE.Group(); scene.add(group);
  let boxes = []; // {mesh, step, info}
  const tip = host.querySelector("#tip");
  const ray = new THREE.Raycaster(), mouse = new THREE.Vector2();

  function resetView() {
    // nhìn chéo từ phía cửa, thấy trọn chiều dài cont
    const d = (L / 2) / Math.tan(THREE.MathUtils.degToRad(camera.fov / 2) * Math.max(1, camera.aspect)) * 1.05;
    camera.position.set(L * 0.62, Hh * 1.9 + d * 0.35, Wd / 2 + d);
    controls.target.set(L / 2, Hh / 2.5, Wd / 2); controls.update();
  }
  resetView();

  function load(c, lines, focus) {
    scene.remove(group); group.traverse((o) => { o.geometry?.dispose(); o.material?.dispose?.(); });
    group = new THREE.Group(); scene.add(group); boxes = [];
    const gap = 0.004;
    const edgePts = [];
    for (const b of c.blocks) {
      const l = lines[b.item];
      const dim = focus && focus !== l.customer_sku;
      const mat = new THREE.MeshLambertMaterial({ color: l.color, transparent: dim, opacity: dim ? 0.12 : 1 });
      const geo = new THREE.BoxGeometry(b.dx / 1000 - gap, b.dz / 1000 - gap, b.dy / 1000 - gap);
      const n = b.nx * b.ny * b.nz;
      const mesh = new THREE.InstancedMesh(geo, mat, n);
      const m = new THREE.Matrix4(); let k = 0;
      for (let ix = 0; ix < b.nx; ix++) for (let iy = 0; iy < b.ny; iy++) for (let iz = 0; iz < b.nz; iz++) {
        const x = (b.x0 + ix * b.dx + b.dx / 2) / 1000, y = (b.z0 + iz * b.dz + b.dz / 2) / 1000, z = (b.y0 + iy * b.dy + b.dy / 2) / 1000;
        m.makeTranslation(x, y, z); mesh.setMatrixAt(k++, m);
        if (!dim) pushEdges(edgePts, x, y, z, b.dx / 1000 - gap, b.dz / 1000 - gap, b.dy / 1000 - gap, b.step);
      }
      mesh.userData = { step: b.step, info: `Bước ${b.step} · ${l.customer_sku} · ${l.description}<br>${b.count} thùng (${b.nx}×${b.ny}×${b.nz}) · đặt ${cm(b.dx)}×${cm(b.dy)}×${cm(b.dz)} cm<br>cách vách trong ${cm(b.x0)} cm · từ trái ${cm(b.y0)} cm · từ sàn ${cm(b.z0)} cm` };
      group.add(mesh); boxes.push(mesh);
    }
    const eg = new THREE.BufferGeometry();
    eg.setAttribute("position", new THREE.Float32BufferAttribute(edgePts.flatMap((e) => e.p), 3));
    edges = { geo: eg, steps: edgePts.map((e) => e.step) };
    edgeLines = new THREE.LineSegments(eg, new THREE.LineBasicMaterial({ color: 0x23303d, transparent: true, opacity: 0.45 }));
    group.add(edgeLines);
  }
  let edges = null, edgeLines = null;
  function setStep(s) {
    for (const m of boxes) m.visible = m.userData.step <= s;
    if (edges) {
      let cnt = 0; for (const st of edges.steps) { if (st <= s) cnt++; else break; }
      edges.geo.setDrawRange(0, cnt * 24);
    }
  }
  function onMove(e) {
    const r = renderer.domElement.getBoundingClientRect();
    mouse.x = ((e.clientX - r.left) / r.width) * 2 - 1; mouse.y = -((e.clientY - r.top) / r.height) * 2 + 1;
    ray.setFromCamera(mouse, camera);
    const hit = ray.intersectObjects(boxes.filter((b) => b.visible && !b.material.transparent), false)[0];
    if (hit) { tip.style.display = "block"; tip.innerHTML = hit.object.userData.info; tip.style.left = e.clientX - r.left + 14 + "px"; tip.style.top = e.clientY - r.top + 14 + "px"; }
    else tip.style.display = "none";
  }
  renderer.domElement.addEventListener("mousemove", onMove);
  const onResize = () => { renderer.setSize(W(), H()); camera.aspect = W() / H(); camera.updateProjectionMatrix(); };
  window.addEventListener("resize", onResize);
  let alive = true;
  (function loop() { if (!alive) return; requestAnimationFrame(loop); controls.update(); renderer.render(scene, camera); })();
  return {
    load, setStep, resetView,
    dispose() { alive = false; window.removeEventListener("resize", onResize); renderer.dispose(); renderer.domElement.remove(); },
  };
}

function pushEdges(out, x, y, z, a, b, c, step) {
  const hx = a / 2, hy = b / 2, hz = c / 2;
  const v = [[-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1], [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]].map(([i, j, k]) => [x + i * hx, y + j * hy, z + k * hz]);
  const e = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]];
  out.push({ step, p: e.flatMap(([i, j]) => [...v[i], ...v[j]]) });
}

function makeLabel(text) {
  const c = document.createElement("canvas"); c.width = 256; c.height = 64;
  const g = c.getContext("2d"); g.font = "bold 30px Segoe UI, Arial"; g.fillStyle = "#1f4e79"; g.textAlign = "center"; g.fillText(text, 128, 42);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), depthTest: false }));
  s.scale.set(1.2, 0.3, 1); return s;
}

window.addEventListener("hashchange", route);
route();
