"""Bước cải thiện kiểu ALNS (phá - sửa) trên phương án đã có.

- Phá: chọn một nhóm cont (cont kém nhất, cont cuối, hoặc nhóm ngẫu nhiên có seed),
  gom toàn bộ hàng trong các cont đó lại.
- Sửa: xếp lại nhóm hàng đó bằng mọi biến thể của constructor.
- Chấp nhận nếu dùng ít cont hơn, hoặc cùng số cont nhưng cont kém nhất đầy hơn.

Có seed => chạy lại với cùng seed ra đúng kết quả cũ (tái lập được).
Cont đã khoá (locked) không bao giờ bị phá.
"""
from __future__ import annotations

import copy
import random
import time
from dataclasses import replace

from .models import CargoItem, ContainerType, Rules
from .packer import DEFAULT_VARIANTS, ContainerState, Solution, Variant, _fill, pack


def _util(st: ContainerState) -> float:
    return sum(b.count * b.dx * b.dy * b.dz for b in st.blocks) / st.ctype.volume


def _counts(conts: list[ContainerState]) -> dict[int, int]:
    out: dict[int, int] = {}
    for st in conts:
        for b in st.blocks:
            if not b.extra:
                out[b.item] = out.get(b.item, 0) + b.count
    return out


def _renumber(conts: list[ContainerState]) -> list[ContainerState]:
    # cont đầy nhất xếp trước, cont còn trống nhiều nhất để cuối (dễ thêm hàng)
    conts = sorted(conts, key=lambda c: -_util(c))
    for i, c in enumerate(conts, start=1):
        c.no = i
    return conts


def _repack(items: list[CargoItem], counts: dict[int, int], ctype: ContainerType,
            rules: Rules, variants: tuple[Variant, ...]) -> list[ContainerState] | None:
    sub = [replace(it, quantity=counts.get(it.idx, 0)) for it in items if counts.get(it.idx, 0) > 0]
    best = None
    for v in variants:
        s = pack(sub, ctype, replace(rules, over_allowance_pct=0), v)
        if s.unplaced:
            continue
        key = (s.n_containers, -sum(_util(c) ** 2 for c in s.containers))
        if best is None or key < best[0]:
            best = (key, s.containers)
    return best[1] if best else None


def _drain(free: list[ContainerState], target: ContainerState, items: list[CargoItem], ctype: ContainerType,
           rules: Rules, variants: tuple[Variant, ...]) -> list[ContainerState] | None:
    """Nước đi "dồn cont lỏng": KHÔNG dỡ các cont khác, chỉ nhét hàng của cont `target`
    vào chỗ trống còn lại của chúng (giống người xếp đặt thêm vài thùng nằm ngang trên nóc).
    Phần không nhét được thì xếp lại vào 1 cont. Trả về bộ cont mới (gồm cả các cont `free` khác)."""
    counts = _counts([target])
    total = sum(counts.values())
    if total == 0:
        return [c for c in free if c is not target]
    others = [c for c in free if c is not target]
    best = None
    for v in variants:
        trial = copy.deepcopy(others)
        rem = dict(counts)
        live = [it for it in items if rem.get(it.idx, 0) > 0]
        # cont đầy nhất trước: lấp nốt khe của nó
        for st in sorted(trial, key=lambda c: -_util(c)):
            if not any(rem.get(it.idx, 0) > 0 for it in live):
                break
            _rebuild_spaces(st, items)
            _fill(st, live, rem, v, rules.min_support_ratio)
        left = sum(rem.values())
        if left == total:
            continue
        if best is None or left < best[0]:
            best = (left, trial, rem)
        if left == 0:
            break
    if best is None:
        return None
    left, trial, rem = best
    if left:
        rest = _repack(items, rem, ctype, rules, variants)
        if rest is None or len(rest) > 1:
            return None
        trial = trial + rest
    return trial


def consolidate(conts: list[ContainerState], items: list[CargoItem], ctype: ContainerType, rules: Rules,
                locked: set[int] | None = None, variants: tuple[Variant, ...] = DEFAULT_VARIANTS,
                time_limit: float = 20.0) -> tuple[list[ContainerState], int]:
    """Lặp "dồn cont lỏng" cho tới khi không còn cải thiện. Trả về (bộ cont, số lần cải thiện)."""
    t0 = time.perf_counter()
    locked = locked or set()
    gains = 0

    def score(cs):
        return (len(cs), -round(sum(_util(c) ** 2 for c in cs), 6))

    tried: set[int] = set()
    while time.perf_counter() - t0 < time_limit:
        free = [c for c in conts if c.no not in locked]
        cands = [c for c in sorted(free, key=_util) if id(c) not in tried]
        if len(free) < 2 or not cands:
            break
        target = cands[0]
        new_free = _drain(free, target, items, ctype, rules, variants)
        if new_free is not None:
            candidate = [c for c in conts if c.no in locked] + new_free
            if score(candidate) < score(conts):
                conts = _renumber(candidate)
                gains += 1
                tried.clear()
                continue
        tried.add(id(target))
        # chỉ thử 3 cont lỏng nhất mỗi vòng để giữ tốc độ
        if len(tried) >= 3:
            break
    return conts, gains


SCORINGS = ("volume", "fit", "big-first", "hard-first")


def random_variants(rng: random.Random, n: int) -> tuple[Variant, ...]:
    """Sinh n "kiểu thợ" ngẫu nhiên (có seed) để vòng cải thiện không bị kẹt ở 10 kiểu cố định."""
    out = []
    for _ in range(n):
        out.append(Variant(f"R{rng.randrange(10**6)}", rng.choice(("x-z-y", "x-y-z")), rng.choice(SCORINGS),
                           rng.choice(("left", "right")), noise=rng.choice((0.05, 0.12, 0.25, 0.4)),
                           seed=rng.randrange(1 << 30)))
    return tuple(out)


def improve(sol: Solution, items: list[CargoItem], ctype: ContainerType, rules: Rules,
            time_limit: float = 15.0, seed: int = 42, locked: set[int] | None = None,
            variants: tuple[Variant, ...] = DEFAULT_VARIANTS, max_stall: int = 150) -> tuple[Solution, dict]:
    t0 = time.perf_counter()
    rng = random.Random(seed)
    locked = locked or set()
    conts = _renumber([c for c in sol.containers])
    log = {"iterations": 0, "improvements": 0, "start_containers": len(conts), "history": []}
    if sol.unplaced:
        return sol, log

    def score(cs):
        # ít cont hơn là trên hết; cùng số cont thì ưu tiên hàng DỒN vào ít cont
        # (tổng bình phương độ đầy lớn) để dần làm rỗng 1 cont — tiêu chí kiểu Falkenauer
        return (len(cs), -round(sum(_util(c) ** 2 for c in cs), 6))

    stall = 0
    while time.perf_counter() - t0 < time_limit and stall < max_stall:
        log["iterations"] += 1
        free = [c for c in conts if c.no not in locked]
        if len(free) < 2:
            break
        by_util = sorted(free, key=_util)
        k = rng.randint(2, min(6, len(free)))
        mode = log["iterations"] % 3
        if len(free) <= 3:
            group = list(free)                        # lô nhỏ: xếp lại toàn bộ (kiểu khởi động lại)
        elif mode == 0:
            group = by_util[:k]                       # các cont kém nhất
        elif mode == 1:
            group = by_util[:1] + rng.sample(by_util[1:], k - 1)  # cont kém nhất + ngẫu nhiên
        else:
            group = rng.sample(free, k)               # ngẫu nhiên
        # 10 kiểu cố định + vài kiểu ngẫu nhiên mới mỗi lượt
        new = _repack(items, _counts(group), ctype, rules, variants + random_variants(rng, 4))
        if new is None:
            stall += 1
            continue
        candidate = [c for c in conts if c not in group] + new
        if score(candidate) < score(conts):
            log["improvements"] += 1
            log["history"].append({"iter": log["iterations"], "containers": len(candidate),
                                   "min_util": round(min(_util(c) for c in candidate) * 100, 1),
                                   "last_util": round(sorted(_util(c) for c in candidate)[0] * 100, 1),
                                   "t": round(time.perf_counter() - t0, 2)})
            conts = _renumber(candidate)
            stall = 0
        else:
            stall += 1
    # cuối cùng: "dồn cont lỏng" (không lấy thời gian của vòng phá–sửa)
    conts, g = consolidate(conts, items, ctype, rules, locked, variants, time_limit=max(2.0, time_limit / 4))
    log["consolidate_gains"] = g
    # lượt cuối: lấp hàng dư trong dung sai (nếu bật)
    out = Solution(sol.variant, conts, {}, sol.seconds + time.perf_counter() - t0)
    if rules.over_allowance_pct > 0:
        from .packer import _fill
        import math
        extra = {it.idx: int(math.floor(it.quantity * rules.over_allowance_pct / 100)) for it in items}
        for st in conts:
            st.blocks = [b for b in st.blocks if not b.extra]
        for st in conts:
            _rebuild_spaces(st, items)
            _fill(st, items, extra, sol.variant, rules.min_support_ratio, extra=True)
    log["seconds"] = round(time.perf_counter() - t0, 2)
    log["end_containers"] = len(conts)
    return out, log


def _rebuild_spaces(st: ContainerState, items: list[CargoItem]) -> None:
    from .packer import _update_spaces
    st.spaces = [(0, 0, 0, st.ctype.length, st.ctype.width, st.ctype.height)]
    md = min(min(it.dims) for it in items)
    for b in st.blocks:
        st.spaces = _update_spaces(st.spaces, b, md)
