"""Validator ĐỘC LẬP với engine.

Đầu vào chỉ là danh sách thùng đã đặt (toạ độ + kích thước) + dữ liệu hàng + luật.
Không dùng lại bất kỳ hàm hình học nào của packer — nếu engine tính sai,
validator vẫn bắt được.

Mã kiểm tra (khớp tài liệu Phase 1, mục E4):
V1 vượt biên cont · V2 chồng lấn · V3 hướng xoay sai · V4 chồng lên hàng cấm chồng / quá số lớp
V5 vượt tải trọng · V7 không đủ đỡ đáy · V9 đối soát số lượng
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field

from .models import ORIENTATIONS, CargoItem, ContainerType, Placement, Rules


@dataclass
class Violation:
    code: str
    level: str  # "error" | "warning"
    container: int | None
    item: int | None
    message: str
    ref: str | None = None

    def to_dict(self) -> dict:
        return self.__dict__.copy()


@dataclass
class ValidationReport:
    violations: list[Violation] = field(default_factory=list)
    checked: list[str] = field(default_factory=list)
    skipped: list[dict] = field(default_factory=list)

    @property
    def errors(self) -> list[Violation]:
        return [v for v in self.violations if v.level == "error"]

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict:
        counts: dict[str, int] = defaultdict(int)
        for v in self.violations:
            counts[v.code] += 1
        return {
            "ok": self.ok,
            "n_errors": len(self.errors),
            "n_warnings": len(self.violations) - len(self.errors),
            "by_code": dict(counts),
            "checked": self.checked,
            "skipped": self.skipped,
            "violations": [v.to_dict() for v in self.violations[:500]],
        }


def _orientation_of(item: CargoItem, dx: int, dy: int, dz: int) -> set[int]:
    d = (item.length, item.width, item.height)
    return {i for i, (a, b, c) in enumerate(ORIENTATIONS) if (d[a], d[b], d[c]) == (dx, dy, dz)}


def validate(placements: list[Placement], items: list[CargoItem], ctype: ContainerType,
             rules: Rules, required: dict[int, int] | None = None,
             allowed_extra: dict[int, int] | None = None) -> ValidationReport:
    rep = ValidationReport()
    by_idx = {it.idx: it for it in items}
    L, W, H = ctype.length, ctype.width, ctype.height
    per_cont: dict[int, list[Placement]] = defaultdict(list)
    for p in placements:
        per_cont[p.container].append(p)

    rep.checked += ["V1", "V2", "V3", "V4", "V7", "V9"]

    for c, ps in per_cont.items():
        # V1 + V3
        for p in ps:
            it = by_idx.get(p.item)
            if it is None:
                rep.violations.append(Violation("V9", "error", c, p.item, "Thùng thuộc SKU không có trong dự án", ref=p.ref))
                continue
            if p.x < 0 or p.y < 0 or p.z < 0 or p.x + p.dx > L or p.y + p.dy > W or p.z + p.dz > H:
                rep.violations.append(Violation("V1", "error", c, p.item,
                                                f"{it.customer_sku} tại ({p.x},{p.y},{p.z}) vượt lòng cont", ref=p.ref))
            ors = _orientation_of(it, p.dx, p.dy, p.dz)
            if not ors:
                rep.violations.append(Violation("V3", "error", c, p.item,
                                                f"{it.customer_sku}: kích thước đặt {p.dx}×{p.dy}×{p.dz} không khớp kích thước thùng", ref=p.ref))
            elif not (ors & set(it.allowed_orientations)):
                rep.violations.append(Violation("V3", "error", c, p.item,
                                                f"{it.customer_sku}: hướng đặt không được phép (mã {it.orientation_code})", ref=p.ref))

        # V2 chồng lấn — quét theo trục x
        ordered = sorted(ps, key=lambda p: p.x)
        active: list[Placement] = []
        n_overlap = 0
        for p in ordered:
            active = [a for a in active if a.x + a.dx > p.x]
            for a in active:
                if (a.y < p.y + p.dy and p.y < a.y + a.dy and a.z < p.z + p.dz and p.z < a.z + a.dz
                        and a.x < p.x + p.dx):
                    n_overlap += 1
                    if n_overlap <= 20:
                        rep.violations.append(Violation("V2", "error", c, p.item,
                                                        f"{by_idx[p.item].customer_sku} chồng lấn {by_idx[a.item].customer_sku} tại x={p.x}",
                                                        ref=f"{p.ref}|{a.ref}" if p.ref else None))
            active.append(p)
        if n_overlap > 20:
            rep.violations.append(Violation("V2", "error", c, None, f"Tổng cộng {n_overlap} cặp chồng lấn"))

        # V4 + V7: đỡ đáy và cấm chồng
        tops: dict[int, list[Placement]] = defaultdict(list)
        for p in ps:
            tops[p.z + p.dz].append(p)
        alpha = rules.min_support_ratio
        for p in ps:
            if p.z == 0:
                continue
            area = 0
            on_forbidden = False
            for q in tops.get(p.z, []):
                ox = min(p.x + p.dx, q.x + q.dx) - max(p.x, q.x)
                oy = min(p.y + p.dy, q.y + q.dy) - max(p.y, q.y)
                if ox > 0 and oy > 0:
                    area += ox * oy
                    if not by_idx[q.item].stackable:
                        on_forbidden = True
            ratio = area / (p.dx * p.dy)
            if on_forbidden:
                rep.violations.append(Violation("V4", "error", c, p.item,
                                                f"{by_idx[p.item].customer_sku} đặt lên hàng cấm chồng", ref=p.ref))
            if ratio + 1e-9 < alpha:
                rep.violations.append(Violation("V7", "error", c, p.item,
                                                f"{by_idx[p.item].customer_sku} chỉ được đỡ {ratio:.0%} (< {alpha:.0%}) tại z={p.z}", ref=p.ref))
        # V4 số lớp tối đa (đếm thùng cùng cột chồng thẳng lên nhau)
        for p in ps:
            it = by_idx[p.item]
            if it.max_stack_layers and p.z >= p.dz * it.max_stack_layers:
                rep.violations.append(Violation("V4", "warning", c, p.item,
                                                f"{it.customer_sku} có thể vượt {it.max_stack_layers} lớp", ref=p.ref))

        # V5 tải trọng (chỉ khi có dữ liệu)
        if rules.allow_weight_check and ctype.max_payload_kg:
            total = sum(by_idx[p.item].weight or 0 for p in ps)
            if total > ctype.max_payload_kg:
                rep.violations.append(Violation("V5", "error", c, None,
                                                f"Tổng {total:.0f} kg > tải tối đa {ctype.max_payload_kg:.0f} kg"))

    if not (rules.allow_weight_check and ctype.max_payload_kg):
        rep.skipped.append({"code": "V5", "reason": "Chưa có dữ liệu kg / tải trọng tối đa (luật đang 'open')"})
    rep.skipped.append({"code": "V6", "reason": "Phân bố trọng lượng: chưa có dữ liệu kg"})
    rep.skipped.append({"code": "V8", "reason": "Thứ tự dỡ hàng theo nhóm: luật chưa xác nhận"})

    # V9 đối soát số lượng
    if required is not None:
        loaded: dict[int, int] = defaultdict(int)
        for p in placements:
            loaded[p.item] += 1
        allowed_extra = allowed_extra or {}
        for idx, req in required.items():
            got = loaded.get(idx, 0)
            sku = by_idx[idx].customer_sku if idx in by_idx else idx
            if got > req + allowed_extra.get(idx, 0):
                rep.violations.append(Violation("V9", "error", None, idx,
                                                f"{sku}: xếp {got} > yêu cầu {req} + dung sai {allowed_extra.get(idx, 0)}"))
            elif got < req:
                rep.violations.append(Violation("V9", "warning", None, idx,
                                                f"{sku}: mới xếp {got}/{req}, còn lại {req - got}"))
    return rep
