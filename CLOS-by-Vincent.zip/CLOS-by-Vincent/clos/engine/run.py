"""Điều phối 1 lần chạy tối ưu: constructor -> cải thiện -> validator -> số liệu."""
from __future__ import annotations

import hashlib
import json
import math
import time
from dataclasses import replace

from .improve import improve
from .models import CargoItem, ContainerType, Placement, Rules
from .packer import DEFAULT_VARIANTS, Solution, lower_bound_containers, solve
from .validator import validate

ENGINE_VERSION = "0.1.0-prototype"

MODES = {
    "fast": {"time_limit": 0.0, "label": "Nhanh (chỉ constructor)"},
    "standard": {"time_limit": 30.0, "label": "Chuẩn (~30 giây)"},
    "deep": {"time_limit": 120.0, "label": "Sâu (~2 phút)"},
}


def input_hash(items: list[CargoItem], ctype: ContainerType, rules: Rules) -> str:
    payload = {
        "items": [[i.customer_sku, i.dims, i.quantity, i.orientation_code, i.stackable] for i in items],
        "ctype": [ctype.length, ctype.width, ctype.height],
        "rules": [rules.min_support_ratio, rules.over_allowance_pct],
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()[:16]


def load_steps(st_blocks: list[dict]) -> list[dict]:
    """Thứ tự xếp thực tế: từ vách trong ra cửa, từ dưới lên, trái sang phải."""
    return sorted(st_blocks, key=lambda b: (b["x0"], b["z0"], b["y0"]))


def summarize(sol: Solution, items: list[CargoItem], ctype: ContainerType, rules: Rules) -> dict:
    by_idx = {it.idx: it for it in items}
    placements = sol.placements()
    allowed_extra = {it.idx: int(math.floor(it.quantity * rules.over_allowance_pct / 100)) for it in items}
    rep = validate(placements, items, ctype, rules, {it.idx: it.quantity for it in items}, allowed_extra)

    containers = []
    for st in sol.containers:
        blocks = []
        for bi, b in enumerate(st.blocks, start=1):
            blocks.append({"block": bi, "item": b.item, "sku": by_idx[b.item].customer_sku,
                           "x0": b.x0, "y0": b.y0, "z0": b.z0, "dx": b.dx, "dy": b.dy, "dz": b.dz,
                           "nx": b.nx, "ny": b.ny, "nz": b.nz, "count": b.count,
                           "orientation": b.orientation, "extra": b.extra})
        steps = load_steps(blocks)
        for s_no, b in enumerate(steps, start=1):
            b["step"] = s_no
        vol = sum(b["count"] * b["dx"] * b["dy"] * b["dz"] for b in blocks)
        counts: dict[str, int] = {}
        for b in blocks:
            counts[b["sku"]] = counts.get(b["sku"], 0) + b["count"]
        containers.append({
            "no": st.no,
            "n_boxes": sum(b["count"] for b in blocks),
            "volume_util": round(vol / ctype.volume, 4),
            "used_length": max((b["x0"] + b["dx"] * b["nx"] for b in blocks), default=0),
            "counts": counts,
            "blocks": steps,
        })

    # đối soát: Required = Loaded + Remaining cho từng SKU
    loaded_by: dict[int, dict[int, int]] = {}
    for p in placements:
        loaded_by.setdefault(p.item, {})
        loaded_by[p.item][p.container] = loaded_by[p.item].get(p.container, 0) + 1
    recon = []
    for it in items:
        per = loaded_by.get(it.idx, {})
        total = sum(per.values())
        recon.append({"item": it.idx, "customer_sku": it.customer_sku, "factory_sku": it.factory_sku,
                      "description": it.description, "required": it.quantity, "loaded": total,
                      "remaining": max(it.quantity - total, 0), "extra": max(total - it.quantity, 0),
                      "by_container": {str(k): v for k, v in sorted(per.items())},
                      "status": "khớp" if total == it.quantity else ("thiếu" if total < it.quantity else "dư")})

    lb = lower_bound_containers(items, ctype)
    n = sol.n_containers
    if sol.unplaced:
        status = "NO_SOLUTION" if not placements else "PARTIAL"
    elif n == lb:
        status = "PROVEN_OPTIMAL"
    else:
        status = "FEASIBLE"
    total_vol = sum(it.volume * it.quantity for it in items)
    return {
        "n_containers": n,
        "lower_bound": lb,
        "gap": round((n - lb) / lb, 4) if lb else None,
        "solver_status": status,
        "status_note": ("Đã chứng minh tối ưu VỀ SỐ CONT (bằng cận dưới thể tích)" if status == "PROVEN_OPTIMAL"
                        else "Phương án hợp lệ do heuristic tìm — chưa chứng minh tối ưu"),
        "avg_volume_util": round(total_vol / (n * ctype.volume), 4) if n else 0,
        "unplaced": {by_idx[k].customer_sku: v for k, v in sol.unplaced.items()},
        "containers": containers,
        "reconciliation": recon,
        "validation": rep.to_dict(),
    }


def optimize(items: list[CargoItem], ctype: ContainerType, rules: Rules,
             mode: str = "standard", seed: int = 1) -> tuple[Solution, dict]:
    t0 = time.perf_counter()
    base_rules = replace(rules, over_allowance_pct=0)
    best, all_sols = solve(items, ctype, base_rules)
    portfolio = [{"variant": s.variant.name, "n_containers": s.n_containers,
                  "unplaced": sum(s.unplaced.values()), "seconds": round(s.seconds, 2)} for s in all_sols]
    tl = MODES.get(mode, MODES["standard"])["time_limit"]
    improve_log = None
    sol = best
    if tl > 0 or rules.over_allowance_pct > 0:
        sol, improve_log = improve(best, items, ctype, rules, time_limit=tl, seed=seed)
    summary = summarize(sol, items, ctype, rules)
    summary["config"] = {
        "engine_version": ENGINE_VERSION, "mode": mode, "seed": seed,
        "constructor_best": best.variant.name, "constructor_containers": best.n_containers,
        "rules": rules.to_dict(), "container_type": ctype.to_dict(),
        "input_hash": input_hash(items, ctype, rules),
    }
    summary["portfolio"] = portfolio
    summary["improve_log"] = improve_log
    summary["seconds"] = round(time.perf_counter() - t0, 2)
    return sol, summary


def placements_from_summary(summary: dict) -> list[Placement]:
    out = []
    for c in summary["containers"]:
        for b in c["blocks"]:
            for ix in range(b["nx"]):
                for iy in range(b["ny"]):
                    for iz in range(b["nz"]):
                        out.append(Placement(c["no"], b["item"], b["x0"] + ix * b["dx"], b["y0"] + iy * b["dy"],
                                             b["z0"] + iz * b["dz"], b["dx"], b["dy"], b["dz"], b["orientation"],
                                             b["step"], b["block"], b["extra"]))
    return out
