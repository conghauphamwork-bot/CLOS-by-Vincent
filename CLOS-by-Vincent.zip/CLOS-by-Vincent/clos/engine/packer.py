"""Engine xếp hàng: Maximal Spaces + block building (constructor deterministic).

Ý tưởng:
- Cont được mô tả bằng danh sách "khoảng trống tối đại" (maximal spaces) có thể chồng lấn nhau.
- Mỗi bước chọn 1 khoảng trống gần vách trong nhất, rồi đặt vào đó 1 KHỐI gồm nx × ny × nz
  thùng cùng SKU, cùng hướng. Xếp theo khối cho kết quả gọn, ổn định, dễ bốc xếp.
- Không có yếu tố ngẫu nhiên: cùng đầu vào + cùng biến thể => cùng kết quả.
- Nhiều biến thể (thứ tự chọn khoảng trống, cách chấm điểm khối, anchor trái/phải)
  chạy song song; chọn phương án tốt nhất theo mục tiêu từ điển.
"""
from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass, field

from .models import CargoItem, ContainerType, Placement, Rules, oriented_dims

Space = tuple[int, int, int, int, int, int]  # x0, y0, z0, x1, y1, z1


@dataclass
class Block:
    x0: int
    y0: int
    z0: int
    dx: int
    dy: int
    dz: int
    nx: int
    ny: int
    nz: int
    item: int
    orientation: int
    stackable: bool
    extra: bool = False

    @property
    def x1(self) -> int:
        return self.x0 + self.dx * self.nx

    @property
    def y1(self) -> int:
        return self.y0 + self.dy * self.ny

    @property
    def z1(self) -> int:
        return self.z0 + self.dz * self.nz

    @property
    def count(self) -> int:
        return self.nx * self.ny * self.nz


@dataclass
class ContainerState:
    no: int
    ctype: ContainerType
    spaces: list[Space] = field(default_factory=list)
    blocks: list[Block] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.spaces:
            self.spaces = [(0, 0, 0, self.ctype.length, self.ctype.width, self.ctype.height)]


@dataclass(frozen=True)
class Variant:
    name: str
    space_order: str = "x-z-y"   # "x-z-y": sâu -> thấp -> trái ; "x-y-z": sâu -> trái -> thấp
    scoring: str = "volume"      # "volume": khối to nhất ; "fit": khít nhất theo ngang/cao
    anchor: str = "left"         # "left" | "right"
    # Biến thể ngẫu nhiên có kiểm soát (dùng trong vòng cải thiện): điểm của mỗi khối bị
    # lệch ±noise để thử thứ tự đặt khác. Cùng seed => cùng kết quả (tái lập được).
    noise: float = 0.0
    seed: int = 0


DEFAULT_VARIANTS: tuple[Variant, ...] = (
    Variant("V1 sâu-thấp-trái / khối lớn", "x-z-y", "volume", "left"),
    Variant("V2 sâu-thấp-trái / khít", "x-z-y", "fit", "left"),
    Variant("V3 sâu-trái-thấp / khối lớn", "x-y-z", "volume", "left"),
    Variant("V4 sâu-trái-thấp / khít", "x-y-z", "fit", "left"),
    Variant("V5 sâu-thấp-phải / khối lớn", "x-z-y", "volume", "right"),
    Variant("V6 sâu-thấp-phải / khít", "x-z-y", "fit", "right"),
    Variant("V7 hàng to trước / sâu-thấp-trái", "x-z-y", "big-first", "left"),
    Variant("V8 hàng to trước / sâu-trái-thấp", "x-y-z", "big-first", "left"),
    Variant("V9 hàng khó trước / sâu-thấp-trái", "x-z-y", "hard-first", "left"),
    Variant("V10 hàng to trước / sâu-thấp-phải", "x-z-y", "big-first", "right"),
)

# Baseline kiểu First-Fit-Decreasing: đặt từng thùng một (không gộp khối).
FFD_BASELINE = Variant("FFD baseline (từng thùng)", "x-z-y", "ffd", "left")


# ----------------------------------------------------------------------------- hình học

def _overlap_1d(a0: int, a1: int, b0: int, b1: int) -> int:
    return max(0, min(a1, b1) - max(a0, b0))


def _intersects(s: Space, b: Block) -> bool:
    return (s[0] < b.x1 and b.x0 < s[3] and s[1] < b.y1 and b.y0 < s[4]
            and s[2] < b.z1 and b.z0 < s[5])


def _contains(a: Space, b: Space) -> bool:
    """a chứa trọn b."""
    return a[0] <= b[0] and a[1] <= b[1] and a[2] <= b[2] and a[3] >= b[3] and a[4] >= b[4] and a[5] >= b[5]


def _split(s: Space, b: Block) -> list[Space]:
    """Phần còn lại của khoảng trống s sau khi đặt khối b (tối đa 6 mảnh, chồng lấn nhau)."""
    x0, y0, z0, x1, y1, z1 = s
    out: list[Space] = []
    if b.x0 > x0:
        out.append((x0, y0, z0, b.x0, y1, z1))
    if b.x1 < x1:
        out.append((b.x1, y0, z0, x1, y1, z1))
    if b.y0 > y0:
        out.append((x0, y0, z0, x1, b.y0, z1))
    if b.y1 < y1:
        out.append((x0, b.y1, z0, x1, y1, z1))
    if b.z0 > z0:
        out.append((x0, y0, z0, x1, y1, b.z0))
    if b.z1 < z1:
        out.append((x0, y0, b.z1, x1, y1, z1))
    return out


def _update_spaces(spaces: list[Space], b: Block, min_dim: int) -> list[Space]:
    kept: list[Space] = []
    pieces: list[Space] = []
    for s in spaces:
        if _intersects(s, b):
            pieces.extend(_split(s, b))
        else:
            kept.append(s)
    # bỏ mảnh quá nhỏ để chứa bất kỳ thùng nào còn lại
    pieces = [p for p in pieces
              if p[3] - p[0] >= min_dim and p[4] - p[1] >= min_dim and p[5] - p[2] >= min_dim]
    # bỏ mảnh bị chứa trong khoảng trống khác (không gian cũ không thể nằm trong mảnh mới)
    pieces = list(dict.fromkeys(pieces))
    result = list(kept)
    for i, p in enumerate(pieces):
        if any(_contains(k, p) for k in kept):
            continue
        if any(j != i and _contains(q, p) and (q != p) for j, q in enumerate(pieces)):
            continue
        result.append(p)
    return result


# ----------------------------------------------------------------------------- đỡ đáy

def _support_ok(st: ContainerState, x0: int, y0: int, z0: int,
                dx: int, dy: int, nx: int, ny: int, alpha: float) -> bool:
    """Kiểm tra từng thùng ở lớp đáy của khối có được đỡ >= alpha và không đè lên hàng cấm chồng."""
    if z0 == 0:
        return True
    below = [b for b in st.blocks if b.z1 == z0
             and b.x0 < x0 + dx * nx and x0 < b.x1 and b.y0 < y0 + dy * ny and y0 < b.y1]
    if not below:
        return False
    for b in below:
        if not b.stackable:
            return False  # không được đặt gì lên thùng cấm chồng
    need = alpha * dx * dy
    for ix in range(nx):
        bx0 = x0 + ix * dx
        for iy in range(ny):
            by0 = y0 + iy * dy
            area = 0
            for b in below:
                ox = _overlap_1d(bx0, bx0 + dx, b.x0, b.x1)
                if ox:
                    area += ox * _overlap_1d(by0, by0 + dy, b.y0, b.y1)
            if area + 1e-9 < need:
                return False
    return True


# ----------------------------------------------------------------------------- chọn khối

def _block_candidates(item: CargoItem, remaining: int, s: Space) -> list[tuple[int, int, int, int, int, int, int]]:
    """Trả về (orientation, dx, dy, dz, nx, ny, nz) khả thi trong khoảng trống s."""
    sx, sy, sz = s[3] - s[0], s[4] - s[1], s[5] - s[2]
    out = []
    for o in item.allowed_orientations:
        dx, dy, dz = oriented_dims(item.dims, o)
        if dx > sx or dy > sy or dz > sz:
            continue
        mz = sz // dz
        if not item.stackable:
            mz = 1
        if item.max_stack_layers:
            mz = min(mz, item.max_stack_layers)
            # giới hạn chiều cao chồng tính từ sàn (khớp validator V4): đáy thùng phải thấp hơn H × số lớp
            cap = dz * item.max_stack_layers   # số lớp theo chiều cao khi đặt (thùng nằm/dựng khác nhau)
            if s[2] >= cap:
                continue
            mz = min(mz, -(-(cap - s[2]) // dz))
        my = sy // dy
        mx = sx // dx
        per = my * mz
        nx = min(mx, remaining // per) if per else 0
        if nx >= 1:
            out.append((o, dx, dy, dz, nx, my, mz))
        else:
            # không đủ hàng cho 1 lát đầy: xếp cột cao tối đa, ít cột hơn
            ny = min(my, remaining // mz)
            if ny >= 1:
                out.append((o, dx, dy, dz, 1, ny, mz))
            elif remaining >= 1:
                # phần lẻ nhỏ hơn 1 cột: 1 cột thấp hơn
                out.append((o, dx, dy, dz, 1, 1, min(mz, remaining)))
        # Phương án dự phòng: khối nhỏ hơn. Khi khối to nhất KHÔNG được đỡ đủ (vd khoảng trống
        # trên nóc một khối hàng mặt trên không phẳng), vẫn còn khối 1 lát / 1 cột / 1 thùng để
        # thử — trước đây khoảng trống bị bỏ luôn dù vẫn đặt vừa vài thùng nằm ngang.
        if remaining >= 1:
            ny1 = max(1, min(my, remaining // max(1, mz)))
            for cand in ((o, dx, dy, dz, 1, ny1, mz if ny1 * mz <= remaining else 1),
                         (o, dx, dy, dz, 1, 1, min(mz, remaining)),
                         (o, dx, dy, dz, 1, 1, 1)):
                if cand not in out and cand[4] * cand[5] * cand[6] <= remaining:
                    out.append(cand)
    return out


def _choose_block(st: ContainerState, items: list[CargoItem], rem: dict[int, int],
                  s: Space, variant: Variant, alpha: float, extra: bool) -> Block | None:
    sx, sy, sz = s[3] - s[0], s[4] - s[1], s[5] - s[2]
    best = None
    best_key = None
    rng = random.Random(hash((variant.seed, st.no, len(st.blocks), s))) if variant.noise else None
    for it in items:
        r = rem.get(it.idx, 0)
        if r <= 0:
            continue
        if variant.scoring == "ffd":
            cands = []
            for o in it.allowed_orientations:
                dx, dy, dz = oriented_dims(it.dims, o)
                if it.max_stack_layers and s[2] >= dz * it.max_stack_layers:
                    continue
                if dx <= sx and dy <= sy and dz <= sz:
                    cands.append((o, dx, dy, dz, 1, 1, 1))
        else:
            cands = _block_candidates(it, r, s)
        for (o, dx, dy, dz, nx, ny, nz) in cands:
            bvol = dx * dy * dz * nx * ny * nz
            waste_y = sy - dy * ny
            waste_z = sz - dz * nz
            if variant.scoring == "volume":
                key = (bvol, -(waste_y + waste_z), -o)
            elif variant.scoring == "fit":
                key = (-(waste_y + waste_z), bvol, -o)
            elif variant.scoring == "big-first":
                # hàng to/khó xếp (pallet, thùng lớn) vào trước, hàng nhỏ dùng để lấp khe
                key = (it.volume, bvol, -(waste_y + waste_z), -o)
            elif variant.scoring == "hard-first":
                # cạnh nhỏ nhất lớn nhất = ít linh hoạt nhất -> xếp trước
                key = (min(it.dims), it.volume, bvol, -o)
            else:  # ffd: thùng lớn nhất trước, hướng thấp nhất
                key = (it.volume, -dz, -o)
            if rng is not None:
                key = (key[0] * (1 + variant.noise * (2 * rng.random() - 1)),) + key[1:]
            if best_key is not None and key <= best_key:
                continue
            bw = dy * ny
            y0 = s[1] if variant.anchor == "left" else s[4] - bw
            if not _support_ok(st, s[0], y0, s[2], dx, dy, nx, ny, alpha):
                continue
            best_key = key
            best = Block(s[0], y0, s[2], dx, dy, dz, nx, ny, nz, it.idx, o, it.stackable, extra)
    return best


def _space_key(s: Space, variant: Variant, width: int):
    y = s[1] if variant.anchor == "left" else width - s[4]
    if variant.space_order == "x-y-z":
        return (s[0], y, s[2])
    return (s[0], s[2], y)


def _fill(st: ContainerState, items: list[CargoItem], rem: dict[int, int],
          variant: Variant, alpha: float, extra: bool = False) -> int:
    """Lấp cont st đến khi không còn khối nào vừa. Trả về số thùng đã đặt."""
    placed = 0
    while st.spaces and any(rem.get(it.idx, 0) > 0 for it in items):
        live = [it for it in items if rem.get(it.idx, 0) > 0]
        min_dim = min(min(it.dims) for it in live)
        order = sorted(st.spaces, key=lambda s: _space_key(s, variant, st.ctype.width))
        chosen = None
        dead: set[Space] = set()
        for s in order:
            b = _choose_block(st, live, rem, s, variant, alpha, extra)
            if b is not None:
                chosen = b
                break
            dead.add(s)
        if dead:
            st.spaces = [s for s in st.spaces if s not in dead]
        if chosen is None:
            break
        st.blocks.append(chosen)
        rem[chosen.item] -= chosen.count
        placed += chosen.count
        live_after = [it for it in items if rem.get(it.idx, 0) > 0]
        md = min((min(it.dims) for it in live_after), default=min_dim)
        st.spaces = _update_spaces(st.spaces, chosen, md)
    return placed


# ----------------------------------------------------------------------------- giải

@dataclass
class Solution:
    variant: Variant
    containers: list[ContainerState]
    unplaced: dict[int, int]
    seconds: float

    @property
    def n_containers(self) -> int:
        return len(self.containers)

    def last_used_length(self) -> int:
        if not self.containers:
            return 0
        return max((b.x1 for b in self.containers[-1].blocks), default=0)

    def objective(self) -> tuple:
        """Mục tiêu từ điển (nhỏ hơn = tốt hơn):
        1) số thùng KHÔNG xếp được, 2) số cont, 3) chiều dài đã dùng của cont cuối
        (càng ngắn = khoảng trống dồn về cuối cont cuối càng lớn, dễ thêm hàng)."""
        return (sum(self.unplaced.values()), self.n_containers, self.last_used_length())

    def placements(self) -> list[Placement]:
        out: list[Placement] = []
        for st in self.containers:
            for bi, b in enumerate(st.blocks):
                for ix in range(b.nx):
                    for iy in range(b.ny):
                        for iz in range(b.nz):
                            out.append(Placement(
                                container=st.no, item=b.item,
                                x=b.x0 + ix * b.dx, y=b.y0 + iy * b.dy, z=b.z0 + iz * b.dz,
                                dx=b.dx, dy=b.dy, dz=b.dz, orientation=b.orientation,
                                load_seq=bi + 1, block=bi + 1, extra=b.extra))
        return out


def pack(items: list[CargoItem], ctype: ContainerType, rules: Rules,
         variant: Variant, max_containers: int = 500) -> Solution:
    t0 = time.perf_counter()
    rem = {it.idx: it.quantity for it in items}
    containers: list[ContainerState] = []
    # hàng không vừa cont theo bất kỳ hướng nào -> không xếp
    for it in items:
        if not any(all(d <= c for d, c in zip(oriented_dims(it.dims, o), (ctype.length, ctype.width, ctype.height)))
                   for o in it.allowed_orientations):
            rem[it.idx] = 0
    unfit = {it.idx: it.quantity for it in items if rem[it.idx] == 0 and it.quantity > 0}
    while any(v > 0 for v in rem.values()) and len(containers) < max_containers:
        st = ContainerState(len(containers) + 1, ctype)
        n = _fill(st, items, rem, variant, rules.min_support_ratio)
        if n == 0:
            break
        containers.append(st)
    # lượt 2: lấp chỗ trống bằng hàng dư trong dung sai được phép (nếu bật)
    if rules.over_allowance_pct > 0:
        extra_rem = {it.idx: int(math.floor(it.quantity * rules.over_allowance_pct / 100)) for it in items}
        for st in containers:
            _fill(st, items, extra_rem, variant, rules.min_support_ratio, extra=True)
    unplaced = {k: v for k, v in rem.items() if v > 0}
    for k, v in unfit.items():
        unplaced[k] = v
    return Solution(variant, containers, unplaced, time.perf_counter() - t0)


def lower_bound_containers(items: list[CargoItem], ctype: ContainerType) -> int:
    """Cận dưới số cont theo thể tích (luôn đúng nhưng lỏng với hàng cồng kềnh)."""
    vol = sum(it.volume * it.quantity for it in items)
    return math.ceil(vol / ctype.volume) if vol else 0


def solve(items: list[CargoItem], ctype: ContainerType, rules: Rules,
          variants: tuple[Variant, ...] = DEFAULT_VARIANTS) -> tuple[Solution, list[Solution]]:
    """Chạy mọi biến thể, trả về (phương án tốt nhất, tất cả phương án đã sắp hạng)."""
    sols = [pack(items, ctype, rules, v) for v in variants]
    sols.sort(key=lambda s: s.objective())
    return sols[0], sols
