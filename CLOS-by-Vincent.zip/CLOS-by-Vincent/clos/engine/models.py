"""Mô hình dữ liệu dùng chung cho engine và validator.

Mọi kích thước nội bộ là số nguyên milimét (mm) để kết quả tái lập được,
không bị sai số dấu phẩy động.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict

# 6 hướng đặt thùng. Mỗi hướng là bộ chỉ số (trục x, trục y, trục z) lấy từ (L, W, H).
# x = chiều dài cont (0 = vách trong, tăng dần về phía cửa)
# y = chiều ngang cont, z = chiều cao.
ORIENTATIONS: list[tuple[int, int, int]] = [
    (0, 1, 2),  # 0: L dọc cont, W ngang cont, H đứng  (CargoWiz "1 Way")
    (1, 0, 2),  # 1: xoay ngang 90°                     (thêm vào "2 Ways")
    (0, 2, 1),  # 2: nằm nghiêng, L vẫn dọc cont
    (2, 0, 1),  # 3: nằm nghiêng, xoay ngang
    (1, 2, 0),  # 4: dựng L thành chiều cao
    (2, 1, 0),  # 5: dựng L thành chiều cao, xoay
]

# Mã hướng xoay của CargoWiz -> tập hướng cho phép.
# 4 Ways = mọi hướng trừ dựng chiều dài thành chiều cao (bỏ hướng 4, 5).
CARGOWIZ_ORIENTATION_CODES: dict[int, tuple[int, ...]] = {
    1: (0,),
    2: (0, 1),
    4: (0, 1, 2, 3),
    6: (0, 1, 2, 3, 4, 5),
}


def oriented_dims(dims: tuple[int, int, int], orientation: int) -> tuple[int, int, int]:
    ix, iy, iz = ORIENTATIONS[orientation]
    return dims[ix], dims[iy], dims[iz]


@dataclass
class CargoItem:
    """Một dòng hàng (SKU) cần xếp."""
    idx: int
    customer_sku: str
    factory_sku: str
    description: str
    length: int  # mm
    width: int   # mm
    height: int  # mm
    quantity: int  # số carton/pallet yêu cầu
    orientation_code: int = 6
    stackable: bool = True
    is_pallet: bool = False
    weight: float | None = None  # kg / đơn vị, None = chưa có dữ liệu
    max_stack_layers: int | None = None
    color: str = "#888888"

    @property
    def dims(self) -> tuple[int, int, int]:
        return (self.length, self.width, self.height)

    @property
    def allowed_orientations(self) -> tuple[int, ...]:
        return CARGOWIZ_ORIENTATION_CODES[self.orientation_code]

    @property
    def volume(self) -> int:
        return self.length * self.width * self.height

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ContainerType:
    code: str
    name: str
    length: int  # mm, kích thước dùng được
    width: int
    height: int
    max_payload_kg: float | None = None

    @property
    def volume(self) -> int:
        return self.length * self.width * self.height

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Placement:
    """Một thùng cụ thể đã được đặt trong cont (toạ độ góc trong-trái-dưới)."""
    container: int  # số thứ tự cont trong dự án, bắt đầu từ 1
    item: int       # CargoItem.idx
    x: int
    y: int
    z: int
    dx: int
    dy: int
    dz: int
    orientation: int
    load_seq: int   # thứ tự xếp (theo khối)
    block: int      # id khối trong cont
    extra: bool = False  # True = hàng dư nằm trong dung sai được phép
    ref: str | None = None  # id thùng phía giao diện (để chỉ đúng thùng bị lỗi)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Rules:
    """Luật nghiệp vụ cấu hình được. Giá trị mặc định là GIẢ ĐỊNH, chưa xác nhận."""
    min_support_ratio: float = 0.75   # α — chưa xác nhận
    allow_weight_check: bool = False  # chưa có dữ liệu kg
    over_allowance_pct: float = 0.0   # % dư tối đa mỗi SKU khi lấp chỗ — chưa xác nhận
    rule_status: dict = field(default_factory=lambda: {
        "min_support_ratio": "assumed",
        "stackable_default": "assumed (file hiện tại không có cột Stackable)",
        "over_allowance_pct": "open",
        "max_payload_kg": "open",
    })

    def to_dict(self) -> dict:
        return asdict(self)
