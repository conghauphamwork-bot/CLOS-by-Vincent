"""Nghiệp vụ: tạo dự án từ Excel, chạy tối ưu, tính lại giữ cont, xác nhận vào sổ số lượng."""
from __future__ import annotations

import json
from dataclasses import replace

from clos import db
from clos.engine.improve import improve
from clos.engine.models import CargoItem, ContainerType, Rules, oriented_dims
from clos.engine.packer import Block, ContainerState, Solution, solve
from clos.engine.run import ENGINE_VERSION, MODES, input_hash, optimize, placements_from_summary, summarize
from clos.io.importer import ImportResult


class BusinessError(Exception):
    pass


# ----------------------------------------------------------------------------- đọc dữ liệu

def get_ctype(con, ctype_id: int) -> ContainerType:
    r = con.execute("SELECT * FROM container_types WHERE id=?", (ctype_id,)).fetchone()
    if not r:
        raise BusinessError("Không tìm thấy loại cont")
    return ContainerType(r["code"], r["name"], r["length_mm"], r["width_mm"], r["height_mm"], r["max_payload_kg"])


def load_items(con, project_id: int) -> tuple[list[CargoItem], dict[int, int]]:
    """Trả về danh sách hàng (số lượng = required hiện tại theo sổ) + map idx -> cargo_line_id."""
    rows = con.execute("SELECT * FROM cargo_lines WHERE project_id=? ORDER BY idx", (project_id,)).fetchall()
    req = {b["cargo_line_id"]: b["required"] for b in db.balance(con, project_id)}
    items, idmap = [], {}
    for r in rows:
        items.append(CargoItem(idx=r["idx"], customer_sku=r["customer_sku"], factory_sku=r["factory_sku"] or "",
                               description=r["description"] or "", length=r["length_mm"], width=r["width_mm"],
                               height=r["height_mm"], quantity=req.get(r["id"], r["base_quantity"]),
                               orientation_code=r["orientation_code"], stackable=bool(r["stackable"]),
                               is_pallet=bool(r["is_pallet"]), weight=r["weight_kg"],
                               max_stack_layers=r["max_stack_layers"], color=r["color"] or "#888"))
        idmap[r["idx"]] = r["id"]
    return items, idmap


# ----------------------------------------------------------------------------- dự án

def create_project(con, name: str, customer: str, filename: str, imp: ImportResult) -> int:
    if not imp.items:
        raise BusinessError("Không có dòng hàng hợp lệ nào để tạo dự án")
    cur = con.execute("INSERT INTO projects(name,customer,source_file,import_report,created_at) VALUES (?,?,?,?,?)",
                      (name, customer, filename, json.dumps({"errors": imp.errors, "warnings": imp.warnings,
                                                             "source_format": imp.source_format,
                                                             "cargowiz_result": imp.cargowiz_result},
                                                            ensure_ascii=False), db.now()))
    pid = cur.lastrowid
    for it in imp.items:
        con.execute("INSERT INTO cargo_lines(project_id,idx,customer_sku,factory_sku,description,length_mm,width_mm,"
                    "height_mm,base_quantity,orientation_code,stackable,is_pallet,weight_kg,max_stack_layers,color)"
                    " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (pid, it.idx, it.customer_sku, it.factory_sku, it.description, it.length, it.width, it.height,
                     it.quantity, it.orientation_code, int(it.stackable), int(it.is_pallet), it.weight,
                     it.max_stack_layers, it.color))
    db.audit(con, "project", pid, "create_from_excel",
             {"file": filename, "lines": len(imp.items), "errors": len(imp.errors), "warnings": len(imp.warnings)})
    return pid


def update_line(con, project_id: int, line_id: int, changes: dict, user: str = "local") -> dict:
    """Sửa thông tin 1 SKU. Đổi số lượng => ghi giao dịch adjust_required (không sửa đè)."""
    r = con.execute("SELECT * FROM cargo_lines WHERE id=? AND project_id=?", (line_id, project_id)).fetchone()
    if not r:
        raise BusinessError("Không tìm thấy dòng hàng")
    before = dict(r)
    allowed = {"length_mm", "width_mm", "height_mm", "orientation_code", "stackable", "is_pallet",
               "weight_kg", "max_stack_layers", "description", "factory_sku"}
    sets = {k: v for k, v in changes.items() if k in allowed}
    for k in ("length_mm", "width_mm", "height_mm"):
        if k in sets and (sets[k] is None or int(sets[k]) <= 0):
            raise BusinessError(f"{k} phải > 0")
    if "orientation_code" in sets and int(sets["orientation_code"]) not in (1, 2, 4, 6):
        raise BusinessError("Hướng xoay chỉ nhận 1, 2, 4, 6")
    if sets:
        con.execute("UPDATE cargo_lines SET " + ", ".join(f"{k}=?" for k in sets) + " WHERE id=?",
                    (*sets.values(), line_id))
    if "required" in changes:
        bal = {b["cargo_line_id"]: b for b in db.balance(con, project_id)}[line_id]
        delta = int(changes["required"]) - bal["required"]
        if delta:
            con.execute("INSERT INTO qty_transactions(project_id,cargo_line_id,delta,reason,note,user_name,created_at)"
                        " VALUES (?,?,?,?,?,?,?)", (project_id, line_id, delta, "adjust_required",
                                                    changes.get("note") or "Sửa số lượng yêu cầu", user, db.now()))
    db.audit(con, "cargo_line", line_id, "update", {"before": before, "changes": changes}, user)
    affected = affected_containers(con, project_id, line_id) if (sets.keys() & {"length_mm", "width_mm", "height_mm", "orientation_code", "stackable"} or "required" in changes) else []
    return {"affected_containers": affected}


def affected_containers(con, project_id: int, line_id: int) -> list[int]:
    run = confirmed_run(con, project_id)
    if not run:
        return []
    return [r["container_no"] for r in con.execute(
        "SELECT DISTINCT container_no FROM placements WHERE run_id=? AND cargo_line_id=? ORDER BY 1",
        (run["id"], line_id))]


def confirmed_run(con, project_id: int):
    return con.execute("SELECT * FROM optimization_runs WHERE project_id=? AND status='confirmed'"
                       " ORDER BY id DESC LIMIT 1", (project_id,)).fetchone()


# ----------------------------------------------------------------------------- chạy tối ưu

def _store_run(con, project_id: int, ctype_id: int, summary: dict, idmap: dict[int, int]) -> int:
    cfg = summary["config"]
    cur = con.execute(
        "INSERT INTO optimization_runs(project_id,container_type_id,mode,seed,input_hash,engine_version,solver_status,"
        "n_containers,lower_bound,gap,seconds,valid,summary,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (project_id, ctype_id, cfg["mode"], cfg["seed"], cfg["input_hash"], ENGINE_VERSION, summary["solver_status"],
         summary["n_containers"], summary["lower_bound"], summary["gap"], summary["seconds"],
         int(summary["validation"]["ok"]), json.dumps(summary, ensure_ascii=False), db.now()))
    run_id = cur.lastrowid
    rows = [(run_id, p.container, idmap[p.item], p.x, p.y, p.z, p.dx, p.dy, p.dz, p.orientation, p.load_seq,
             p.block, int(p.extra)) for p in placements_from_summary(summary)]
    con.executemany("INSERT INTO placements(run_id,container_no,cargo_line_id,x,y,z,dx,dy,dz,orientation,load_seq,"
                    "block,extra) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
    db.audit(con, "optimization_run", run_id, "create",
             {"mode": cfg["mode"], "n_containers": summary["n_containers"], "valid": summary["validation"]["ok"]})
    return run_id


def run_optimization(con, project_id: int, ctype_id: int, rules: Rules, mode: str = "standard",
                     seed: int = 1) -> int:
    if mode not in MODES:
        raise BusinessError("Chế độ chạy không hợp lệ")
    items, idmap = load_items(con, project_id)
    ctype = get_ctype(con, ctype_id)
    _, summary = optimize(items, ctype, rules, mode, seed)
    return _store_run(con, project_id, ctype_id, summary, idmap)


def _state_from_summary(c: dict, ctype: ContainerType) -> ContainerState:
    st = ContainerState(c["no"], ctype)
    st.blocks = [Block(b["x0"], b["y0"], b["z0"], b["dx"], b["dy"], b["dz"], b["nx"], b["ny"], b["nz"], b["item"],
                       b["orientation"], True, b["extra"]) for b in sorted(c["blocks"], key=lambda b: b["block"])]
    return st


def run_partial(con, project_id: int, base_run_id: int, keep: list[int], rules: Rules,
                mode: str = "standard", seed: int = 1) -> tuple[int, dict]:
    """Tính lại nhưng GIỮ NGUYÊN các cont trong `keep` (nếu chúng còn hợp lệ với dữ liệu hiện tại)."""
    base = con.execute("SELECT * FROM optimization_runs WHERE id=? AND project_id=?", (base_run_id, project_id)).fetchone()
    if not base:
        raise BusinessError("Không tìm thấy phương án gốc")
    bsum = json.loads(base["summary"])
    ctype = get_ctype(con, base["container_type_id"])
    items, idmap = load_items(con, project_id)
    by_idx = {it.idx: it for it in items}
    report = {"kept": [], "dropped": []}
    kept_states: list[ContainerState] = []
    kept_counts: dict[int, int] = {}
    for c in bsum["containers"]:
        if c["no"] not in keep:
            continue
        reasons = []
        for b in c["blocks"]:
            it = by_idx.get(b["item"])
            if it is None:
                reasons.append(f"SKU idx {b['item']} không còn")
                continue
            if b["orientation"] not in it.allowed_orientations or \
                    oriented_dims(it.dims, b["orientation"]) != (b["dx"], b["dy"], b["dz"]):
                reasons.append(f"{it.customer_sku}: kích thước/hướng đã thay đổi")
        if reasons:
            report["dropped"].append({"no": c["no"], "reasons": sorted(set(reasons))})
            continue
        st = _state_from_summary(c, ctype)
        for b in st.blocks:
            b.stackable = by_idx[b.item].stackable
        kept_states.append(st)
        for b in c["blocks"]:
            if not b["extra"]:
                kept_counts[b["item"]] = kept_counts.get(b["item"], 0) + b["count"]
    # số lượng giảm khiến cont giữ lại xếp vượt yêu cầu => cont đó không còn hợp lệ
    over = {k for k, v in kept_counts.items() if v > by_idx[k].quantity}
    if over:
        for st in list(kept_states):
            if any(b.item in over for b in st.blocks):
                kept_states.remove(st)
                report["dropped"].append({"no": st.no, "reasons": [
                    f"{by_idx[k].customer_sku}: số yêu cầu đã giảm, cont giữ lại đang xếp vượt" for k in over
                    if any(b.item == k for b in st.blocks)]})
        kept_counts = {}
        for st in kept_states:
            for b in st.blocks:
                if not b.extra:
                    kept_counts[b.item] = kept_counts.get(b.item, 0) + b.count
    report["kept"] = [st.no for st in kept_states]

    rest = [replace(it, quantity=it.quantity - kept_counts.get(it.idx, 0)) for it in items
            if it.quantity - kept_counts.get(it.idx, 0) > 0]
    new_states: list[ContainerState] = []
    log = None
    if rest:
        best, _ = solve(rest, ctype, replace(rules, over_allowance_pct=0))
        tl = MODES[mode]["time_limit"]
        sol = best
        if tl > 0:
            sol, log = improve(best, rest, ctype, replace(rules, over_allowance_pct=0), time_limit=tl, seed=seed)
        new_states = sol.containers
    # đánh số: cont giữ lại giữ số cũ, cont mới đánh tiếp
    used = {st.no for st in kept_states}
    nxt = 1
    for st in new_states:
        while nxt in used:
            nxt += 1
        st.no = nxt
        used.add(nxt)
    all_states = sorted(kept_states + new_states, key=lambda s: s.no)
    unplaced = sol.unplaced if rest else {}
    full = Solution(None, all_states, unplaced, 0.0)  # type: ignore[arg-type]
    summary = summarize(full, items, ctype, rules)
    summary["config"] = {"engine_version": ENGINE_VERSION, "mode": mode, "seed": seed,
                         "constructor_best": "partial-recalc", "base_run": base_run_id,
                         "rules": rules.to_dict(), "container_type": ctype.to_dict(),
                         "input_hash": input_hash(items, ctype, rules)}
    summary["partial"] = report
    summary["locked_containers"] = report["kept"]
    summary["improve_log"] = log
    summary["seconds"] = 0
    run_id = _store_run(con, project_id, base["container_type_id"], summary, idmap)
    return run_id, report


# ----------------------------------------------------------------------------- xác nhận vào sổ

def confirm_run(con, project_id: int, run_id: int, replace_existing: bool = False, user: str = "local") -> dict:
    run = con.execute("SELECT * FROM optimization_runs WHERE id=? AND project_id=?", (run_id, project_id)).fetchone()
    if not run:
        raise BusinessError("Không tìm thấy phương án")
    if run["status"] != "draft":
        raise BusinessError(f"Phương án đang ở trạng thái '{run['status']}', không xác nhận lại được")
    if not run["valid"]:
        raise BusinessError("Phương án còn lỗi Validator — không được xác nhận")
    old = confirmed_run(con, project_id)
    if old and not replace_existing:
        raise BusinessError(f"Dự án đã có kế hoạch xác nhận (phương án #{old['id']}). "
                            "Chọn 'Thay thế kế hoạch cũ' nếu muốn ghi đè — hệ thống sẽ ghi giao dịch hoàn trả.")
    ts = db.now()
    if old:
        for r in con.execute("SELECT cargo_line_id, container_no, SUM(delta) q FROM qty_transactions WHERE project_id=?"
                             " AND reason IN ('confirm_load','unload') GROUP BY 1,2 HAVING q <> 0", (project_id,)).fetchall():
            con.execute("INSERT INTO qty_transactions(project_id,cargo_line_id,container_no,run_id,delta,reason,note,"
                        "user_name,created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                        (project_id, r["cargo_line_id"], r["container_no"], old["id"], -r["q"], "unload",
                         f"Hoàn trả khi thay bằng phương án #{run_id}", user, ts))
        con.execute("UPDATE optimization_runs SET status='superseded' WHERE id=?", (old["id"],))
    # hàng dư trong dung sai => tăng số yêu cầu có ghi lý do, trước khi ghi số xếp
    bal = {b["cargo_line_id"]: b for b in db.balance(con, project_id)}
    loads = con.execute("SELECT cargo_line_id, container_no, COUNT(*) n FROM placements WHERE run_id=? GROUP BY 1,2",
                        (run_id,)).fetchall()
    tot: dict[int, int] = {}
    for r in loads:
        tot[r["cargo_line_id"]] = tot.get(r["cargo_line_id"], 0) + r["n"]
    for lid, n in tot.items():
        if n > bal[lid]["required"]:
            con.execute("INSERT INTO qty_transactions(project_id,cargo_line_id,run_id,delta,reason,note,user_name,"
                        "created_at) VALUES (?,?,?,?,?,?,?,?)",
                        (project_id, lid, run_id, n - bal[lid]["required"], "adjust_required",
                         "Xếp dư trong dung sai đã duyệt", user, ts))
    for r in loads:
        con.execute("INSERT INTO qty_transactions(project_id,cargo_line_id,container_no,run_id,delta,reason,note,"
                    "user_name,created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                    (project_id, r["cargo_line_id"], r["container_no"], run_id, r["n"], "confirm_load",
                     "Xác nhận phương án", user, ts))
    problems = db.reconcile_check(con, project_id, run_id)
    if problems:
        raise BusinessError("Đối soát thất bại, đã huỷ xác nhận: " + "; ".join(problems[:5]))
    con.execute("UPDATE optimization_runs SET status='confirmed' WHERE id=?", (run_id,))
    con.execute("UPDATE projects SET status='planning' WHERE id=?", (project_id,))
    db.audit(con, "optimization_run", run_id, "confirm", {"replaced": old["id"] if old else None}, user)
    return {"confirmed": run_id, "replaced": old["id"] if old else None}
