"""API web local (FastAPI). Chạy: python run.py  ->  http://localhost:8000"""
from __future__ import annotations

import json
import os
import shutil
import tempfile

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from clos import db, service
from clos.engine.models import Rules
from clos.engine.run import MODES
from clos.io.exporter import export_run, template_bytes
from clos.io.importer import import_excel

STATIC = os.path.join(os.path.dirname(__file__), "static")
app = FastAPI(title="CLOS by Vincent")
db.init_db()

# Mật khẩu tuỳ chọn (dùng khi chia sẻ trong mạng nội bộ): đặt biến môi trường CLOS_PASSWORD.
# Trình duyệt sẽ hỏi tên đăng nhập (gõ gì cũng được) + mật khẩu.
_PASSWORD = os.environ.get("CLOS_PASSWORD", "")
if _PASSWORD:
    import base64
    import secrets

    @app.middleware("http")
    async def _basic_auth(request, call_next):
        ok = False
        h = request.headers.get("authorization", "")
        if h.lower().startswith("basic "):
            try:
                _, _, pw = base64.b64decode(h[6:]).decode("utf-8").partition(":")
                ok = secrets.compare_digest(pw.encode(), _PASSWORD.encode())
            except Exception:
                ok = False
        if not ok:
            return Response("Cần đăng nhập", status_code=401,
                            headers={"WWW-Authenticate": 'Basic realm="CLOS", charset="UTF-8"'})
        return await call_next(request)


def _err(e: Exception):
    if isinstance(e, service.BusinessError):
        raise HTTPException(400, str(e))
    if "LEDGER" in str(e):
        raise HTTPException(400, str(e))
    raise e


WEB_DIST = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web", "dist")


@app.get("/classic")
def classic_index():
    """Giao diện prototype cũ (vanilla JS) — giữ lại để đối chiếu."""
    return FileResponse(os.path.join(STATIC, "index.html"))


app.mount("/static", StaticFiles(directory=STATIC), name="static")

from clos.web_api import router as web_router  # noqa: E402

app.include_router(web_router)


# ----------------------------------------------------------------------------- danh mục cont

class CTypeIn(BaseModel):
    code: str
    name: str
    length_cm: float
    width_cm: float
    height_cm: float
    max_payload_kg: float | None = None
    note: str | None = None


@app.get("/api/container-types")
def list_ctypes():
    with db.connect() as con:
        return [dict(r) for r in con.execute("SELECT * FROM container_types WHERE active=1 ORDER BY id")]


@app.post("/api/container-types")
def add_ctype(c: CTypeIn):
    if min(c.length_cm, c.width_cm, c.height_cm) <= 0:
        raise HTTPException(400, "Kích thước phải > 0")
    with db.connect() as con:
        try:
            cur = con.execute("INSERT INTO container_types(code,name,length_mm,width_mm,height_mm,max_payload_kg,note)"
                              " VALUES (?,?,?,?,?,?,?)", (c.code, c.name, round(c.length_cm * 10), round(c.width_cm * 10),
                                                          round(c.height_cm * 10), c.max_payload_kg, c.note))
        except Exception as e:  # noqa: BLE001
            raise HTTPException(400, f"Không lưu được: {e}")
        db.audit(con, "container_type", cur.lastrowid, "create", c.model_dump())
        return {"id": cur.lastrowid}


# ----------------------------------------------------------------------------- dự án

@app.get("/api/template.xlsx")
def template():
    return Response(template_bytes(), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": "attachment; filename=CLOS_template.xlsx"})


@app.post("/api/projects/import")
def import_project(file: UploadFile = File(...), name: str = Form(""), customer: str = Form("")):
    suffix = os.path.splitext(file.filename or "x.xlsx")[1] or ".xlsx"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        shutil.copyfileobj(file.file, tmp)
        path = tmp.name
    try:
        imp = import_excel(path)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, f"Không đọc được file Excel: {e}")
    finally:
        os.unlink(path)
    if not imp.items:
        return {"project_id": None, "report": imp.to_dict()}
    with db.connect() as con:
        try:
            pid = service.create_project(con, name or os.path.splitext(file.filename or "Dự án")[0], customer,
                                         file.filename or "", imp)
        except Exception as e:  # noqa: BLE001
            _err(e)
    rep = imp.to_dict()
    rep.pop("items")
    return {"project_id": pid, "report": rep, "n_items": len(imp.items)}


@app.get("/api/projects")
def list_projects():
    with db.connect() as con:
        rows = con.execute("SELECT p.*, (SELECT COUNT(*) FROM cargo_lines l WHERE l.project_id=p.id) n_lines,"
                           " (SELECT COUNT(*) FROM optimization_runs r WHERE r.project_id=p.id) n_runs"
                           " FROM projects p ORDER BY id DESC").fetchall()
        return [{k: r[k] for k in r.keys() if k != "import_report"} for r in rows]


@app.get("/api/projects/{pid}")
def get_project(pid: int):
    with db.connect() as con:
        p = con.execute("SELECT * FROM projects WHERE id=?", (pid,)).fetchone()
        if not p:
            raise HTTPException(404, "Không tìm thấy dự án")
        lines = [dict(r) for r in con.execute("SELECT * FROM cargo_lines WHERE project_id=? ORDER BY idx", (pid,))]
        bal = {b["cargo_line_id"]: b for b in db.balance(con, pid)}
        for ln in lines:
            b = bal[ln["id"]]
            ln.update(required=b["required"], loaded=b["loaded"], remaining=b["remaining"],
                      by_container=b["by_container"])
        runs = [{k: r[k] for k in r.keys() if k != "summary"} for r in con.execute(
            "SELECT * FROM optimization_runs WHERE project_id=? ORDER BY id DESC", (pid,))]
        d = dict(p)
        d["import_report"] = json.loads(p["import_report"] or "{}")
        d["lines"] = lines
        d["runs"] = runs
        return d


class LineChange(BaseModel):
    length_cm: float | None = None
    width_cm: float | None = None
    height_cm: float | None = None
    orientation_code: int | None = None
    stackable: bool | None = None
    required: int | None = None
    note: str | None = None


@app.patch("/api/projects/{pid}/lines/{lid}")
def patch_line(pid: int, lid: int, ch: LineChange):
    changes: dict = {}
    for k in ("length", "width", "height"):
        v = getattr(ch, f"{k}_cm")
        if v is not None:
            changes[f"{k}_mm"] = round(v * 10)
    if ch.orientation_code is not None:
        changes["orientation_code"] = ch.orientation_code
    if ch.stackable is not None:
        changes["stackable"] = int(ch.stackable)
    if ch.required is not None:
        if ch.required < 0:
            raise HTTPException(400, "Số lượng phải ≥ 0")
        changes["required"] = ch.required
        changes["note"] = ch.note
    with db.connect() as con:
        try:
            return service.update_line(con, pid, lid, changes)
        except Exception as e:  # noqa: BLE001
            _err(e)


@app.get("/api/projects/{pid}/audit")
def audit(pid: int):
    with db.connect() as con:
        tx = [dict(r) for r in con.execute(
            "SELECT t.*, l.customer_sku FROM qty_transactions t JOIN cargo_lines l ON l.id=t.cargo_line_id"
            " WHERE t.project_id=? ORDER BY t.id DESC LIMIT 500", (pid,))]
        log = [dict(r) for r in con.execute(
            "SELECT * FROM audit_log WHERE (entity='project' AND entity_id=?) OR (entity='optimization_run' AND "
            "entity_id IN (SELECT id FROM optimization_runs WHERE project_id=?)) OR (entity='cargo_line' AND entity_id IN"
            " (SELECT id FROM cargo_lines WHERE project_id=?)) ORDER BY id DESC LIMIT 300", (pid, pid, pid))]
        return {"transactions": tx, "audit": log}


# ----------------------------------------------------------------------------- tối ưu

class RunIn(BaseModel):
    container_type_id: int
    mode: str = "standard"
    seed: int = 1
    min_support_ratio: float = 0.75
    over_allowance_pct: float = 0.0


class PartialIn(RunIn):
    base_run_id: int
    keep: list[int]


def _rules(r: RunIn) -> Rules:
    if not 0 < r.min_support_ratio <= 1:
        raise HTTPException(400, "Tỉ lệ đỡ đáy phải trong (0, 1]")
    if not 0 <= r.over_allowance_pct <= 50:
        raise HTTPException(400, "Dung sai dư phải trong 0–50%")
    return Rules(min_support_ratio=r.min_support_ratio, over_allowance_pct=r.over_allowance_pct)


@app.get("/api/modes")
def modes():
    return MODES


@app.post("/api/projects/{pid}/runs")
def create_run(pid: int, r: RunIn):
    with db.connect() as con:
        try:
            rid = service.run_optimization(con, pid, r.container_type_id, _rules(r), r.mode, r.seed)
        except Exception as e:  # noqa: BLE001
            _err(e)
    return {"run_id": rid}


@app.post("/api/projects/{pid}/runs/partial")
def create_partial(pid: int, r: PartialIn):
    with db.connect() as con:
        try:
            rid, report = service.run_partial(con, pid, r.base_run_id, r.keep, _rules(r), r.mode, r.seed)
        except Exception as e:  # noqa: BLE001
            _err(e)
    return {"run_id": rid, "report": report}


@app.get("/api/runs/{rid}")
def get_run(rid: int):
    with db.connect() as con:
        r = con.execute("SELECT * FROM optimization_runs WHERE id=?", (rid,)).fetchone()
        if not r:
            raise HTTPException(404, "Không tìm thấy phương án")
        d = {k: r[k] for k in r.keys() if k != "summary"}
        d["summary"] = json.loads(r["summary"])
        d["lines"] = [dict(x) for x in con.execute("SELECT * FROM cargo_lines WHERE project_id=? ORDER BY idx",
                                                    (r["project_id"],))]
        return d


class ConfirmIn(BaseModel):
    replace: bool = False


@app.post("/api/runs/{rid}/confirm")
def confirm(rid: int, c: ConfirmIn):
    with db.connect() as con:
        r = con.execute("SELECT project_id FROM optimization_runs WHERE id=?", (rid,)).fetchone()
        if not r:
            raise HTTPException(404, "Không tìm thấy phương án")
        try:
            return service.confirm_run(con, r["project_id"], rid, c.replace)
        except Exception as e:  # noqa: BLE001
            _err(e)


@app.get("/api/runs/{rid}/export.xlsx")
def export(rid: int):
    with db.connect() as con:
        data = export_run(con, rid)
    return Response(data, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f"attachment; filename=CLOS_phuong_an_{rid}.xlsx"})


# ----------------------------------------------------------------------------- giao diện React (đặt CUỐI để không che /api)

if os.path.isdir(WEB_DIST):
    app.mount("/assets", StaticFiles(directory=os.path.join(WEB_DIST, "assets")), name="web-assets")

    @app.get("/")
    def web_index():
        return FileResponse(os.path.join(WEB_DIST, "index.html"))
else:
    @app.get("/")
    def web_missing():
        return FileResponse(os.path.join(STATIC, "index.html"))
