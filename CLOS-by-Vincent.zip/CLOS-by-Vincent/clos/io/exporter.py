"""Xuất Excel. Số lượng lấy từ bảng placements đã lưu (không tính lại) để khớp dữ liệu dự án."""
from __future__ import annotations

import io
import json

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

HEAD = Font(bold=True, color="FFFFFF")
FILL = PatternFill("solid", fgColor="1F4E79")
WARN = PatternFill("solid", fgColor="FCE4D6")
OKF = PatternFill("solid", fgColor="E2EFDA")


def _header(ws, cols):
    ws.append(cols)
    for c in ws[ws.max_row]:
        c.font, c.fill = HEAD, FILL
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = ws.cell(row=ws.max_row + 1, column=1)


def _widths(ws, widths):
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w


def export_run(con, run_id: int) -> bytes:
    run = con.execute("SELECT r.*, p.name pname, p.customer, c.name cname FROM optimization_runs r "
                      "JOIN projects p ON p.id=r.project_id JOIN container_types c ON c.id=r.container_type_id "
                      "WHERE r.id=?", (run_id,)).fetchone()
    summary = json.loads(run["summary"])
    lines = con.execute("SELECT * FROM cargo_lines WHERE project_id=? ORDER BY idx", (run["project_id"],)).fetchall()
    req = {r["cargo_line_id"]: r["required"] for r in con.execute(
        "SELECT * FROM v_qty_balance WHERE project_id=?", (run["project_id"],))}
    cnt = {}
    for r in con.execute("SELECT cargo_line_id, container_no, COUNT(*) n FROM placements WHERE run_id=? GROUP BY 1,2",
                         (run_id,)):
        cnt[(r["cargo_line_id"], r["container_no"])] = r["n"]
    nos = sorted({k[1] for k in cnt})

    wb = Workbook()
    ws = wb.active
    ws.title = "Tong hop"
    rows = [
        ("Dự án", run["pname"]), ("Khách hàng", run["customer"] or ""), ("Phương án #", run_id),
        ("Trạng thái", run["status"]), ("Loại cont", run["cname"]),
        ("Số cont", run["n_containers"]), ("Cận dưới (thể tích)", run["lower_bound"]),
        ("Khoảng cách tối ưu (gap)", f"{(run['gap'] or 0) * 100:.1f}%"),
        ("Tình trạng lời giải", run["solver_status"]), ("Ghi chú", summary.get("status_note", "")),
        ("Độ đầy thể tích TB", f"{summary['avg_volume_util'] * 100:.1f}%"),
        ("Validator", "ĐẠT" if run["valid"] else "CÓ LỖI"),
        ("Engine", f"{run['engine_version']} · mode {run['mode']} · seed {run['seed']} · input {run['input_hash']}"),
        ("Tạo lúc", run["created_at"]),
    ]
    for k, v in rows:
        ws.append([k, v])
        ws.cell(ws.max_row, 1).font = Font(bold=True)
    ws.append([])
    _header(ws, ["Cont", "Số thùng", "Độ đầy thể tích", "Chiều dài đã dùng (cm)", "Số SKU"])
    for c in summary["containers"]:
        ws.append([c["no"], c["n_boxes"], round(c["volume_util"] * 100, 1), c["used_length"] / 10, len(c["counts"])])
    _widths(ws, [28, 40, 16, 22, 10])

    ws2 = wb.create_sheet("Doi soat so luong")
    _header(ws2, ["Factory SKU", "Customer SKU", "Mô tả", "Yêu cầu"] + [f"Cont {n}" for n in nos]
            + ["Đã xếp", "Còn lại", "Dư", "Tình trạng"])
    for ln in lines:
        per = [cnt.get((ln["id"], n), 0) for n in nos]
        loaded = sum(per)
        r = req.get(ln["id"], ln["base_quantity"])
        status = "khớp" if loaded == r else ("thiếu" if loaded < r else "dư")
        ws2.append([ln["factory_sku"], ln["customer_sku"], ln["description"], r] + [p or None for p in per]
                   + [loaded, max(r - loaded, 0), max(loaded - r, 0), status])
        ws2.cell(ws2.max_row, ws2.max_column).fill = OKF if status == "khớp" else WARN
    tot = ws2.max_row + 1
    ws2.append(["TỔNG", "", "", f"=SUM(D2:D{tot - 1})"] +
               [f"=SUM({get_column_letter(5 + i)}2:{get_column_letter(5 + i)}{tot - 1})" for i in range(len(nos))])
    for c in ws2[tot]:
        c.font = Font(bold=True)
    _widths(ws2, [22, 16, 18, 9] + [7] * len(nos) + [9, 9, 7, 11])

    ws3 = wb.create_sheet("Ke hoach xep")
    _header(ws3, ["Cont", "Bước", "Customer SKU", "Mô tả", "Số thùng", "Bố trí (dọc×ngang×cao)",
                  "Kích thước đặt D×R×C (cm)", "Vị trí từ vách trong (cm)", "Từ trái (cm)", "Từ sàn (cm)", "Hàng dư"])
    by_idx = {ln["idx"]: ln for ln in lines}
    for c in summary["containers"]:
        for b in c["blocks"]:
            ln = by_idx[b["item"]]
            ws3.append([c["no"], b["step"], ln["customer_sku"], ln["description"], b["count"],
                        f"{b['nx']}×{b['ny']}×{b['nz']}", f"{b['dx'] / 10:g}×{b['dy'] / 10:g}×{b['dz'] / 10:g}",
                        b["x0"] / 10, b["y0"] / 10, b["z0"] / 10, "có" if b["extra"] else ""])
    _widths(ws3, [6, 6, 16, 18, 9, 18, 22, 20, 12, 12, 9])

    ws4 = wb.create_sheet("Kiem tra")
    v = summary["validation"]
    ws4.append(["Kết quả", "ĐẠT" if v["ok"] else "CÓ LỖI"])
    ws4.append(["Đã kiểm", ", ".join(v["checked"])])
    for s in v["skipped"]:
        ws4.append(["Chưa kiểm " + s["code"], s["reason"]])
    ws4.append([])
    _header(ws4, ["Mã", "Mức", "Cont", "Nội dung"])
    for x in v["violations"]:
        ws4.append([x["code"], x["level"], x["container"], x["message"]])
    _widths(ws4, [18, 10, 8, 90])

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def template_bytes() -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "Cargo"
    _header(ws, ["Factory SKU", "Customer SKU", "Description", "Length (cm)", "Width (cm)", "Height (cm)",
                 "Weight (kg)", "Quantity", "Stackable", "Orientation (1/2/4/6)", "Pallet (Y/N)"])
    ws.append(["10DGCH0048AWJUL0101", "C00161MA11", "CH0048", 92, 59, 31, None, 1210, "Y", 6, "N"])
    ws.append(["10DGCH0485...", "O00771MA10", "CH0485 P", 192, 159, 212.4, None, 6, "Y", 2, "Y"])
    _widths(ws, [22, 16, 18, 12, 12, 12, 12, 10, 10, 20, 12])
    g = wb.create_sheet("Huong dan")
    for line in [
        "Mỗi dòng = 1 mã hàng. Đơn vị kích thước: cm (cho phép số lẻ .5). Quantity = số carton/pallet.",
        "Orientation theo CargoWiz: 1 = không xoay; 2 = đổi dài/rộng; 4 = mọi hướng trừ dựng chiều dài; 6 = mọi hướng.",
        "Trống Orientation: pallet = 2, carton = 6. Trống Stackable: coi là chồng được (sẽ có cảnh báo).",
        "Thiếu kích thước hoặc số lượng => dòng bị từ chối, hệ thống KHÔNG tự đoán.",
    ]:
        g.append([line])
    g.column_dimensions["A"].width = 120
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
