"""Import dữ liệu hàng từ Excel.

Hỗ trợ 2 dạng:
1. File Excel dạng CargoWiz (sheet "CargoWiz" + sheet kích thước "PKT dien kich thuoc"): dùng chính số liệu
   đang nhập vào CargoWiz, lấy mã nhà máy và cờ Pallet từ sheet PKT.
2. Template CLOS (1 sheet, mỗi dòng 1 SKU) — xem clos/io/template.py.

Nguyên tắc: thiếu hoặc sai dữ liệu thì BÁO LỖI, không tự đoán giá trị.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

import openpyxl

from clos.engine.models import CARGOWIZ_ORIENTATION_CODES, CargoItem

PALETTE = [
    "#4E79A7", "#F28E2B", "#E15759", "#76B7B2", "#59A14F", "#EDC948", "#B07AA1", "#FF9DA7",
    "#9C755F", "#BAB0AC", "#1F77B4", "#FF7F0E", "#2CA02C", "#D62728", "#9467BD", "#8C564B",
    "#E377C2", "#7F7F7F", "#BCBD22", "#17BECF", "#393B79", "#637939", "#8C6D31", "#843C39",
    "#7B4173", "#3182BD", "#E6550D", "#31A354", "#756BB1", "#636363",
]


@dataclass
class ImportResult:
    items: list[CargoItem] = field(default_factory=list)
    errors: list[dict] = field(default_factory=list)    # chặn: dòng không được import
    warnings: list[dict] = field(default_factory=list)  # không chặn, cần người dùng xem
    source_format: str = ""
    cargowiz_result: dict | None = None  # kết quả CargoWiz trích trong file (để benchmark)

    def to_dict(self) -> dict:
        return {
            "items": [i.to_dict() for i in self.items],
            "errors": self.errors,
            "warnings": self.warnings,
            "source_format": self.source_format,
            "cargowiz_result": self.cargowiz_result,
        }


def _cm_to_mm(v: Any) -> int | None:
    if v is None or isinstance(v, bool):
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return int(round(f * 10))


def _last_int(text: Any) -> int | None:
    if text is None:
        return None
    nums = re.findall(r"\d+", str(text))
    return int(nums[-1]) if nums else None


def _norm(s: Any) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


# ----------------------------------------------------------------------------- dạng CargoWiz

def _read_pkt(wb) -> dict[str, dict]:
    out: dict[str, dict] = {}
    if "PKT dien kich thuoc" not in wb.sheetnames:
        return out
    ws = wb["PKT dien kich thuoc"]
    for r in ws.iter_rows(min_row=3, values_only=True):
        if not r or not r[0]:
            continue
        out[str(r[0]).strip()] = {
            "factory_sku": str(r[1]).strip() if r[1] else "",
            "is_pallet": bool(r[16]) if len(r) > 16 and isinstance(r[16], bool) else False,
        }
    return out


def _import_cargowiz(wb) -> ImportResult:
    res = ImportResult(source_format="cargowiz")
    pkt = _read_pkt(wb)
    ws = wb["CargoWiz"]
    rows = list(ws.iter_rows(min_row=1, values_only=True))
    header = [_norm(c) for c in rows[0]]
    if not header or header[0] != "length":
        res.errors.append({"row": 1, "field": "header", "message": "Sheet CargoWiz không đúng định dạng (cột A phải là Length)"})
        return res

    seen: dict[str, CargoItem] = {}
    idx = 0
    end_row = 1
    for i, r in enumerate(rows[1:], start=2):
        if not r or all(c is None for c in r[:7]):
            end_row = i
            break
        L, W, H, qty_in, orient, sku, desc = r[:7]
        loaded = r[8] if len(r) > 8 else None
        remain = r[9] if len(r) > 9 else None
        sku = str(sku).strip() if sku else ""
        row_err = []
        if not sku:
            row_err.append("thiếu mã SKU")
        dims = [_cm_to_mm(L), _cm_to_mm(W), _cm_to_mm(H)]
        for name, d in zip(("Length", "Width", "Height"), dims):
            if d is None:
                row_err.append(f"thiếu {name}")
            elif d <= 0:
                row_err.append(f"{name} phải > 0")
        required = _last_int(desc)
        if required is None:
            row_err.append("không đọc được số lượng yêu cầu ở cột Description")
        try:
            ocode = int(orient)
            if ocode not in CARGOWIZ_ORIENTATION_CODES:
                row_err.append(f"mã hướng xoay {orient} không hợp lệ (chỉ 1, 2, 4, 6)")
        except (TypeError, ValueError):
            ocode = 0
            row_err.append("thiếu mã hướng xoay")
        if row_err:
            res.errors.append({"row": i, "sku": sku, "message": "; ".join(row_err)})
            continue
        # đối chiếu số yêu cầu với công thức trong file (Đã load + Còn lại)
        if isinstance(loaded, (int, float)) and isinstance(remain, (int, float)):
            if int(loaded + remain) != required:
                res.warnings.append({"row": i, "sku": sku,
                                     "message": f"Số yêu cầu ở Description ({required}) khác Đã load + Còn lại ({int(loaded + remain)})"})
        if isinstance(qty_in, (int, float)) and required and qty_in != required:
            res.warnings.append({"row": i, "sku": sku, "code": "inflated_qty",
                                 "message": f"Qty nhập CargoWiz = {int(qty_in)} khác số yêu cầu {required} (×{qty_in / required:.2f}). CLOS dùng số yêu cầu."})
        info = pkt.get(sku, {})
        if not info:
            res.warnings.append({"row": i, "sku": sku, "message": "Không tìm thấy mã trong sheet PKT — thiếu mã nhà máy"})
        item = CargoItem(
            idx=idx, customer_sku=sku, factory_sku=info.get("factory_sku", ""),
            description=str(desc or ""), length=dims[0], width=dims[1], height=dims[2],
            quantity=required, orientation_code=ocode, stackable=True,
            is_pallet=info.get("is_pallet", ocode == 2), color=PALETTE[idx % len(PALETTE)],
        )
        if sku in seen:
            prev = seen[sku]
            if prev.dims != item.dims:
                res.errors.append({"row": i, "sku": sku, "message": "Trùng SKU nhưng KHÁC kích thước — cần kiểm tra"})
            else:
                prev.quantity += item.quantity
                res.warnings.append({"row": i, "sku": sku, "message": "Trùng SKU cùng kích thước — đã cộng dồn số lượng"})
            continue
        seen[sku] = item
        res.items.append(item)
        idx += 1

    res.cargowiz_result = _read_cargowiz_result(rows, end_row)
    res.warnings.append({"row": None, "sku": None, "code": "stackable_assumed",
                         "message": "File không có cột Stackable: tạm coi mọi mã đều chồng được (giống CargoWiz đang làm). Cần xác nhận."})
    return res


def _read_cargowiz_result(rows: list[tuple], start: int) -> dict | None:
    """Phần CargoWiz trích ra bên dưới sheet: SKU | SL | mô tả | L | W | H | Cont n."""
    per: dict[str, dict[str, int]] = {}
    containers: set[int] = set()
    for r in rows[start:]:
        if not r or not r[0] or len(r) < 7 or not r[6]:
            continue
        m = re.match(r"cont\s*(\d+)", str(r[6]).strip(), re.I)
        if not m or not isinstance(r[1], (int, float)):
            continue
        c = int(m.group(1))
        containers.add(c)
        per.setdefault(str(r[0]).strip(), {})
        per[str(r[0]).strip()][str(c)] = per[str(r[0]).strip()].get(str(c), 0) + int(r[1])
    if not containers:
        return None
    return {"n_containers": len(containers), "loaded_by_sku": per}


# ----------------------------------------------------------------------------- template CLOS

TEMPLATE_COLUMNS = {
    "factory_sku": ["factory sku", "mã nhà máy", "ma nha may", "erp"],
    "customer_sku": ["customer sku", "mã khách", "ma khach", "sku"],
    "description": ["description", "mô tả", "mo ta"],
    "length": ["length (cm)", "length", "dài (cm)", "dai (cm)"],
    "width": ["width (cm)", "width", "rộng (cm)", "rong (cm)"],
    "height": ["height (cm)", "height", "cao (cm)"],
    "weight": ["weight (kg)", "weight", "kg"],
    "quantity": ["quantity", "qty", "số lượng", "so luong"],
    "stackable": ["stackable", "chồng được", "chong duoc"],
    "orientation": ["orientation (1/2/4/6)", "orientation", "rotation", "hướng xoay", "huong xoay"],
    "pallet": ["pallet (y/n)", "pallet", "pallet?"],
}

REQUIRED_FIELDS = ["customer_sku", "length", "width", "height", "quantity"]


def _yes(v: Any, default: bool) -> bool:
    if v is None or v == "":
        return default
    if isinstance(v, bool):
        return v
    return _norm(v) in ("y", "yes", "true", "1", "có", "co", "x")


def _import_template(ws) -> ImportResult:
    res = ImportResult(source_format="clos-template")
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        res.errors.append({"row": 1, "message": "Sheet trống"})
        return res
    header = [_norm(c) for c in rows[0]]
    col: dict[str, int] = {}
    for key, names in TEMPLATE_COLUMNS.items():
        for n in names:
            if n in header:
                col[key] = header.index(n)
                break
    missing = [f for f in REQUIRED_FIELDS if f not in col]
    if missing:
        res.errors.append({"row": 1, "message": "Thiếu cột bắt buộc: " + ", ".join(missing)})
        return res
    seen: dict[str, CargoItem] = {}
    idx = 0
    for i, r in enumerate(rows[1:], start=2):
        if not r or all(c is None for c in r):
            continue
        g = lambda k: r[col[k]] if k in col and col[k] < len(r) else None  # noqa: E731
        sku = str(g("customer_sku") or "").strip()
        errs = []
        if not sku:
            errs.append("thiếu Customer SKU")
        dims = [_cm_to_mm(g("length")), _cm_to_mm(g("width")), _cm_to_mm(g("height"))]
        for name, d in zip(("Length", "Width", "Height"), dims):
            if d is None:
                errs.append(f"thiếu {name}")
            elif d <= 0:
                errs.append(f"{name} phải > 0")
        q = g("quantity")
        try:
            qty = int(q)
            if qty < 0 or float(q) != qty:
                errs.append("Quantity phải là số nguyên ≥ 0")
        except (TypeError, ValueError):
            qty = 0
            errs.append("thiếu/sai Quantity")
        is_pallet = _yes(g("pallet"), False)
        o = g("orientation")
        try:
            ocode = int(o) if o not in (None, "") else (2 if is_pallet else 6)
            if ocode not in CARGOWIZ_ORIENTATION_CODES:
                errs.append("Orientation chỉ nhận 1, 2, 4, 6")
        except (TypeError, ValueError):
            ocode = 6
            errs.append("Orientation không hợp lệ")
        w = g("weight")
        try:
            weight = float(w) if w not in (None, "") else None
        except (TypeError, ValueError):
            weight = None
            errs.append("Weight không hợp lệ")
        if errs:
            res.errors.append({"row": i, "sku": sku, "message": "; ".join(errs)})
            continue
        item = CargoItem(idx=idx, customer_sku=sku, factory_sku=str(g("factory_sku") or "").strip(),
                         description=str(g("description") or ""), length=dims[0], width=dims[1], height=dims[2],
                         quantity=qty, orientation_code=ocode, stackable=_yes(g("stackable"), True),
                         is_pallet=is_pallet, weight=weight, color=PALETTE[idx % len(PALETTE)])
        if g("stackable") in (None, ""):
            res.warnings.append({"row": i, "sku": sku, "message": "Trống cột Stackable — tạm coi là chồng được"})
        if sku in seen:
            prev = seen[sku]
            if prev.dims != item.dims:
                res.errors.append({"row": i, "sku": sku, "message": "Trùng SKU nhưng KHÁC kích thước — cần kiểm tra"})
            else:
                prev.quantity += item.quantity
                res.warnings.append({"row": i, "sku": sku, "message": "Trùng SKU cùng kích thước — đã cộng dồn"})
            continue
        seen[sku] = item
        res.items.append(item)
        idx += 1
    return res


def import_excel(path: str) -> ImportResult:
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    try:
        if "CargoWiz" in wb.sheetnames:
            return _import_cargowiz(wb)
        return _import_template(wb.worksheets[0])
    finally:
        wb.close()
