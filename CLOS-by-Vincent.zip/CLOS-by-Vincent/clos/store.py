"""Kho dữ liệu cho giao diện React: SQLite, mỗi lần lưu là 1 bản (revision) mới — không bao giờ ghi đè mất.

Bảng:
  web_projects        bản hiện hành của từng dự án (JSON đúng kiểu LoadingProject của giao diện)
  web_revisions       MỌI bản đã lưu (chỉ thêm, không sửa/xoá — có trigger chặn)
  web_qty_ledger      sổ thay đổi số lượng theo mã hàng (chỉ thêm, không sửa/xoá)
  web_kv / web_kv_history   danh sách loại cont, thư viện mẫu xếp, dự án đang mở
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time

DB_PATH = os.environ.get("CLOS_WEB_DB", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "clos_web.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS web_projects (
  id TEXT PRIMARY KEY, rev INTEGER NOT NULL, doc TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS web_revisions (
  seq INTEGER PRIMARY KEY AUTOINCREMENT, project_id TEXT NOT NULL, rev INTEGER NOT NULL, action TEXT NOT NULL,
  note TEXT, doc TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS web_qty_ledger (
  seq INTEGER PRIMARY KEY AUTOINCREMENT, project_id TEXT NOT NULL, rev INTEGER NOT NULL, sku_id TEXT NOT NULL,
  factory_sku TEXT, required_before INTEGER, required_after INTEGER, loaded_before INTEGER, loaded_after INTEGER,
  note TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS web_kv (k TEXT PRIMARY KEY, v TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS web_kv_history (seq INTEGER PRIMARY KEY AUTOINCREMENT, k TEXT NOT NULL, v TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TRIGGER IF NOT EXISTS trg_rev_no_update BEFORE UPDATE ON web_revisions BEGIN SELECT RAISE(ABORT, 'revisions are append-only'); END;
CREATE TRIGGER IF NOT EXISTS trg_rev_no_delete BEFORE DELETE ON web_revisions BEGIN SELECT RAISE(ABORT, 'revisions are append-only'); END;
CREATE TRIGGER IF NOT EXISTS trg_wql_no_update BEFORE UPDATE ON web_qty_ledger BEGIN SELECT RAISE(ABORT, 'ledger is append-only'); END;
CREATE TRIGGER IF NOT EXISTS trg_wql_no_delete BEFORE DELETE ON web_qty_ledger BEGIN SELECT RAISE(ABORT, 'ledger is append-only'); END;
DROP TRIGGER IF EXISTS trg_wql_guard;
DROP TRIGGER IF EXISTS trg_wql_guard2;
CREATE TRIGGER IF NOT EXISTS trg_wql_guard3 BEFORE INSERT ON web_qty_ledger
  WHEN NEW.loaded_after < 0 OR NEW.required_after < 0
    OR (NEW.loaded_after > NEW.required_after AND NEW.loaded_after > COALESCE(NEW.loaded_before, 0)
        AND COALESCE(NEW.note, '') NOT LIKE 'Lùi lại:%' AND COALESCE(NEW.note, '') NOT LIKE 'Làm lại:%'
        AND COALESCE(NEW.note, '') NOT LIKE 'Khôi phục%')
  BEGIN SELECT RAISE(ABORT, 'quantity invariant violated: cannot load more than required'); END;
"""

_lock = threading.Lock()


class Conflict(Exception):
    """Lưu bị từ chối. current = bản hiện hành trên máy chủ (để giao diện quay lại)."""

    def __init__(self, message: str, current: dict | None = None, rev: int | None = None):
        super().__init__(message)
        self.current = current
        self.rev = rev


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def connect() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    return con


# ----------------------------------------------------------------------------- luật số lượng (chặn cứng)

def loaded_counts(project: dict) -> dict[str, int]:
    out: dict[str, int] = {}
    for c in project.get("containers", []):
        for p in c.get("placements", []):
            out[p["skuId"]] = out.get(p["skuId"], 0) + 1
    return out


def check_project(project: dict, previous: dict | None = None, restoring: bool = False) -> list[str]:
    errs: list[str] = []
    skus = project.get("skus", [])
    ids = [s.get("id") for s in skus]
    by_id = {s["id"]: s for s in skus if s.get("id")}
    if len(set(ids)) != len(ids):
        errs.append("Có 2 mã hàng trùng id.")
    seen_f: set[str] = set()
    for s in skus:
        f = (s.get("factorySku") or "").strip()
        if f and f in seen_f:
            errs.append(f"Mã nhà máy {f} bị trùng.")
        seen_f.add(f)
        q = s.get("requiredQty")
        if not isinstance(q, int) or isinstance(q, bool):
            if isinstance(q, float) and q.is_integer():
                s["requiredQty"] = int(q)
            else:
                errs.append(f"{f}: số yêu cầu phải là số nguyên (đang là {q}).")
                continue
        if s["requiredQty"] < 0:
            errs.append(f"{f}: số yêu cầu âm.")
        for k in ("lengthMm", "widthMm", "heightMm"):
            if not (float(s.get(k) or 0) > 0):
                errs.append(f"{f}: kích thước {k} phải > 0.")
    inst: set[str] = set()
    orphans = 0
    for c in project.get("containers", []):
        for p in c.get("placements", []):
            if p.get("instanceId") in inst:
                errs.append(f"Thùng {p.get('instanceId')} xuất hiện 2 lần.")
            inst.add(p.get("instanceId"))
            if p.get("skuId") not in by_id:
                orphans += 1
    if orphans:
        errs.append(f"{orphans} thùng đang xếp thuộc mã hàng không còn trong danh sách "
                    f"(mã bị xoá hoặc đổi id khi import). Không lưu để tránh số 'đã xếp' bị sai.")
    # Xếp VƯỢT yêu cầu: chỉ chấp nhận khi số đã xếp KHÔNG tăng (tức là người dùng vừa giảm số yêu cầu
    # và sẽ bấm Recalculate để bỏ thùng dư). Validator V9 vẫn báo lỗi đỏ và chặn xuất cho tới khi xử lý.
    prev_load = loaded_counts(previous or {})
    for sid, n in loaded_counts(project).items():
        s = by_id.get(sid)
        if s and isinstance(s.get("requiredQty"), int) and n > s["requiredQty"] and n > prev_load.get(sid, 0) and not restoring:
            errs.append(f"{s.get('factorySku')}: đã xếp {n} > yêu cầu {s['requiredQty']}. "
                        f"Muốn xếp thêm thì tăng số yêu cầu trước (có ghi sổ).")
    return errs


# ----------------------------------------------------------------------------- đọc / ghi

def get_state(con) -> dict:
    projects, revs = [], {}
    for r in con.execute("SELECT * FROM web_projects WHERE deleted=0 ORDER BY updated_at DESC"):
        projects.append(json.loads(r["doc"]))
        revs[r["id"]] = r["rev"]
    kv = {r["k"]: json.loads(r["v"]) for r in con.execute("SELECT * FROM web_kv")}
    return {"projects": projects, "revs": revs, "specs": kv.get("specs"), "templates": kv.get("templates"),
            "activeProjectId": kv.get("activeProjectId")}


def save_project(con, project: dict, base_rev: int | None, note: str = "", action: str = "save") -> int:
    pid = project.get("id")
    if not pid:
        raise Conflict("Thiếu id dự án.")
    with _lock:
        row = con.execute("SELECT * FROM web_projects WHERE id=?", (pid,)).fetchone()
        current = json.loads(row["doc"]) if row else None
        if row and not row["deleted"] and base_rev is not None and row["rev"] != base_rev:
            raise Conflict("Dự án vừa được sửa ở tab/máy khác. Đã tải lại bản mới nhất.", current, row["rev"])
        # Lùi/làm lại từ giao diện = khôi phục trạng thái người dùng từng có -> cho phép vượt tạm (V9 vẫn báo đỏ, vẫn chặn xuất)
        restoring = action == "restore" or note.startswith(("Lùi lại:", "Làm lại:"))
        errs = check_project(project, current, restoring)
        if errs:
            raise Conflict("Không lưu: " + " | ".join(errs[:5]), current, row["rev"] if row else None)
        rev = (row["rev"] + 1) if row else 1
        doc = json.dumps(project, ensure_ascii=False)
        ts = _now()
        # sổ số lượng: ghi mọi thay đổi số yêu cầu / số đã xếp theo mã hàng
        before_req = {s["id"]: s.get("requiredQty", 0) for s in (current or {}).get("skus", [])}
        before_load = loaded_counts(current or {})
        after_load = loaded_counts(project)
        for s in project.get("skus", []):
            sid = s["id"]
            rb, ra = before_req.get(sid), s["requiredQty"]
            lb, la = before_load.get(sid, 0), after_load.get(sid, 0)
            if rb != ra or lb != la:
                con.execute("INSERT INTO web_qty_ledger(project_id,rev,sku_id,factory_sku,required_before,required_after,"
                            "loaded_before,loaded_after,note,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                            (pid, rev, sid, s.get("factorySku"), rb, ra, lb, la, note[:300], ts))
        for sid in set(before_req) - {s["id"] for s in project.get("skus", [])}:
            con.execute("INSERT INTO web_qty_ledger(project_id,rev,sku_id,factory_sku,required_before,required_after,"
                        "loaded_before,loaded_after,note,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (pid, rev, sid, None, before_req[sid], 0, before_load.get(sid, 0), 0, "Xoá mã hàng", ts))
        con.execute("INSERT INTO web_revisions(project_id,rev,action,note,doc,created_at) VALUES (?,?,?,?,?,?)",
                    (pid, rev, action, note[:500], doc, ts))
        con.execute("INSERT INTO web_projects(id,rev,doc,deleted,updated_at) VALUES (?,?,?,0,?) "
                    "ON CONFLICT(id) DO UPDATE SET rev=excluded.rev, doc=excluded.doc, deleted=0, updated_at=excluded.updated_at",
                    (pid, rev, doc, ts))
        con.commit()
        return rev


def delete_project(con, pid: str) -> None:
    with _lock:
        row = con.execute("SELECT * FROM web_projects WHERE id=?", (pid,)).fetchone()
        if not row:
            return
        con.execute("INSERT INTO web_revisions(project_id,rev,action,note,doc,created_at) VALUES (?,?,?,?,?,?)",
                    (pid, row["rev"], "delete", "Xoá dự án (vẫn khôi phục được)", row["doc"], _now()))
        con.execute("UPDATE web_projects SET deleted=1, updated_at=? WHERE id=?", (_now(), pid))
        con.commit()


def put_kv(con, k: str, v) -> None:
    with _lock:
        s = json.dumps(v, ensure_ascii=False)
        old = con.execute("SELECT v FROM web_kv WHERE k=?", (k,)).fetchone()
        if old and old["v"] == s:
            return
        con.execute("INSERT INTO web_kv(k,v,updated_at) VALUES (?,?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v, updated_at=excluded.updated_at",
                    (k, s, _now()))
        if k != "activeProjectId":
            con.execute("INSERT INTO web_kv_history(k,v,created_at) VALUES (?,?,?)", (k, s, _now()))
        con.commit()


def revisions(con, pid: str) -> list[dict]:
    return [dict(seq=r["seq"], rev=r["rev"], action=r["action"], note=r["note"], created_at=r["created_at"])
            for r in con.execute("SELECT seq,rev,action,note,created_at FROM web_revisions WHERE project_id=? ORDER BY seq DESC LIMIT 300", (pid,))]


def restore(con, pid: str, seq: int) -> tuple[dict, int]:
    r = con.execute("SELECT doc FROM web_revisions WHERE project_id=? AND seq=?", (pid, seq)).fetchone()
    if not r:
        raise Conflict("Không tìm thấy bản cần khôi phục.")
    doc = json.loads(r["doc"])
    cur = con.execute("SELECT rev FROM web_projects WHERE id=?", (pid,)).fetchone()
    rev = save_project(con, doc, cur["rev"] if cur else None, f"Khôi phục bản #{seq}", "restore")
    return doc, rev


def ledger(con, pid: str) -> list[dict]:
    return [dict(r) for r in con.execute("SELECT * FROM web_qty_ledger WHERE project_id=? ORDER BY seq DESC LIMIT 1000", (pid,))]
