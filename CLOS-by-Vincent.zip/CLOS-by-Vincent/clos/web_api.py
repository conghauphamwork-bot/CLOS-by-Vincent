"""API cho giao diện React  — tiền tố /api/web."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from clos import bridge, store

router = APIRouter(prefix="/api/web")
con = store.connect()


def _conflict(e: store.Conflict):
    return JSONResponse(status_code=409, content={"detail": str(e), "current": e.current, "rev": e.rev})


@router.get("/state")
def state():
    return store.get_state(con)


class SaveIn(BaseModel):
    project: dict
    baseRev: int | None = None
    note: str = ""
    specs: list[dict] | None = None


@router.put("/projects/{pid}")
def save(pid: str, body: SaveIn):
    if body.project.get("id") != pid:
        raise HTTPException(400, "id không khớp")
    try:
        rev = store.save_project(con, body.project, body.baseRev, body.note)
    except store.Conflict as e:
        return _conflict(e)
    validation = None
    if body.specs:
        try:
            validation = bridge.validate_project(body.project, body.specs)
        except Exception as e:  # kiểm tra không được làm hỏng việc lưu
            validation = {"ok": False, "errors": 0, "warnings": 0, "issues": [], "error": str(e)}
    return {"rev": rev, "validation": validation}


@router.delete("/projects/{pid}")
def delete(pid: str):
    store.delete_project(con, pid)
    return {"ok": True}


@router.get("/projects/{pid}/revisions")
def revisions(pid: str):
    return store.revisions(con, pid)


@router.post("/projects/{pid}/restore/{seq}")
def restore(pid: str, seq: int):
    try:
        doc, rev = store.restore(con, pid, seq)
    except store.Conflict as e:
        return _conflict(e)
    return {"project": doc, "rev": rev}


@router.get("/projects/{pid}/ledger")
def ledger(pid: str):
    return store.ledger(con, pid)


@router.put("/kv/{key}")
def put_kv(key: str, value: dict):
    if key not in ("specs", "templates", "activeProjectId"):
        raise HTTPException(400, "khoá không hợp lệ")
    store.put_kv(con, key, value.get("value"))
    return {"ok": True}


class CalcIn(BaseModel):
    project: dict
    specs: list[dict]
    mode: str = "locked"          # locked | incremental
    seconds: float | None = None  # ghi đè thời gian cải thiện (None = theo thuật toán)


@router.post("/optimize")
async def optimize(body: CalcIn):
    if body.mode not in ("locked", "incremental"):
        raise HTTPException(400, "mode không hợp lệ")
    if not body.project.get("skus"):
        raise HTTPException(400, "Dự án chưa có mã hàng nào.")
    try:
        return await run_in_threadpool(bridge.optimize_project, body.project, body.specs, body.mode, body.seconds)
    except bridge.BridgeError as e:
        raise HTTPException(400, str(e))


class ValIn(BaseModel):
    project: dict
    specs: list[dict]


@router.post("/validate")
async def validate(body: ValIn):
    return await run_in_threadpool(bridge.validate_project, body.project, body.specs)


class BenchIn(ValIn):
    seconds: float = 15.0


@router.post("/benchmark")
async def bench(body: BenchIn):
    if not body.project.get("skus"):
        raise HTTPException(400, "Dự án chưa có mã hàng nào.")
    return await run_in_threadpool(bridge.benchmark, body.project, body.specs, max(0.0, min(body.seconds, 120.0)))
