"""Cầu nối giữa giao diện React (kiểu dữ liệu TypeScript của app AI Studio) và engine Python.

Quy ước toạ độ khác nhau, nên mọi chuyển đổi nằm ở file này:
    React/TS : x = dài cont, y = CAO,  z = NGANG   (PlacedCarton.xMm / yMm / zMm)
    Python   : x = dài cont, y = NGANG, z = CAO    (Placement.x / y / z)
Mọi số đo được làm tròn về mm nguyên trước khi đưa vào engine/validator.
"""
from __future__ import annotations

import math
import time
from dataclasses import replace

from .engine.improve import _rebuild_spaces, consolidate, improve
from .engine.models import ORIENTATIONS, CargoItem, ContainerType, Placement, Rules
from .engine.packer import (DEFAULT_VARIANTS, FFD_BASELINE, Block, ContainerState, Solution,
                            _fill, lower_bound_containers, pack, solve)
from .engine.run import ENGINE_VERSION
from .engine.validator import _orientation_of, validate

ROTATION_TO_CODE = {"all": 6, "four_way": 4, "upright_only": 2, "length_width_only": 2, "none": 1}
RULE_OF_CODE = {"V1": "boundary", "V2": "overlap", "V3": "rotation", "V4": "stacking",
                "V5": "payload", "V7": "support_stability", "V9": "quantity"}
AXIS = "LWH"

# thuật toán chọn trên giao diện -> cách chạy engine Python
ALGO_PLAN = {
    "ffd": {"variants": (FFD_BASELINE,), "seconds": 0, "label": "FFD (baseline tham chiếu)"},
    "bfd": {"variants": DEFAULT_VARIANTS, "seconds": 0, "label": "Danh mục 10 biến thể xếp khối (nhanh)"},
    "extreme_points": {"variants": DEFAULT_VARIANTS, "seconds": 0, "label": "Danh mục 10 biến thể xếp khối (nhanh)"},
    "maximal_spaces": {"variants": DEFAULT_VARIANTS, "seconds": 0, "label": "Danh mục 10 biến thể xếp khối (nhanh)"},
    "hybrid_alns_ep": {"variants": DEFAULT_VARIANTS, "seconds": 30, "label": "Xếp khối + cải thiện phá-sửa (~30 giây)"},
}


class BridgeError(Exception):
    pass


# ----------------------------------------------------------------------------- chuyển đổi đầu vào

def _r(v) -> int:
    return int(round(float(v)))


def build_items(skus: list[dict], config: dict) -> tuple[list[CargoItem], dict[str, int], dict[int, dict]]:
    items: list[CargoItem] = []
    idx_of: dict[str, int] = {}
    sku_of: dict[int, dict] = {}
    for i, s in enumerate(skus, start=1):
        code = ROTATION_TO_CODE.get(s.get("rotationPolicy", "all"), 6)
        if not config.get("respectRotation", True):
            code = 6
        stack = bool(s.get("stackable", True)) or not config.get("respectStacking", True)
        it = CargoItem(idx=i, customer_sku=s.get("customerSku") or s.get("factorySku") or s["id"],
                       factory_sku=s.get("factorySku", ""), description=s.get("description", ""),
                       length=_r(s["lengthMm"]), width=_r(s["widthMm"]), height=_r(s["heightMm"]),
                       quantity=int(s.get("requiredQty", 0)), orientation_code=code, stackable=stack,
                       is_pallet=bool(s.get("palletized")), weight=float(s.get("weightKg") or 0) or None,
                       max_stack_layers=(int(s["maxStackLayers"]) if s.get("maxStackLayers") and 1 < int(s["maxStackLayers"]) < 99 else None),
                       color=s.get("color", "#888888"))
        items.append(it)
        idx_of[s["id"]] = i
        sku_of[i] = s
    return items, idx_of, sku_of


def build_ctype(spec: dict) -> ContainerType:
    return ContainerType(code=spec.get("code", "CONT"), name=spec.get("name", ""),
                         length=_r(spec["internalLengthMm"]), width=_r(spec["internalWidthMm"]),
                         height=_r(spec["internalHeightMm"]),
                         max_payload_kg=float(spec.get("maxPayloadKg") or 0) or None)


def build_rules(config: dict) -> Rules:
    return Rules(min_support_ratio=float(config.get("minSupportRatio", 0.75)),
                 allow_weight_check=bool(config.get("respectPayload", False)))


def ts_to_placement(p: dict, cont_no: int, idx_of: dict[str, int]) -> Placement:
    return Placement(container=cont_no, item=idx_of.get(p["skuId"], -1),
                     x=_r(p["xMm"]), y=_r(p["zMm"]), z=_r(p["yMm"]),
                     dx=_r(p["dimXMm"]), dy=_r(p["dimZMm"]), dz=_r(p["dimYMm"]),
                     orientation=-1, load_seq=0, block=0, ref=p.get("instanceId"))


def _spec_for(container: dict, specs_by_id: dict[str, dict], default_spec: dict) -> dict:
    return specs_by_id.get(container.get("containerSpecId"), default_spec)


# ----------------------------------------------------------------------------- kiểm tra độc lập

def validate_project(project: dict, specs: list[dict]) -> dict:
    """Chạy validator Python cho từng cont (mỗi cont dùng đúng kích thước cont của nó)."""
    specs_by_id = {s["id"]: s for s in specs}
    default_spec = specs_by_id.get(project.get("defaultContainerSpecId")) or (specs[0] if specs else None)
    if default_spec is None:
        raise BridgeError("Chưa có loại container nào")
    config = project.get("optimizationConfig", {})
    items, idx_of, _ = build_items(project.get("skus", []), config)
    rules = build_rules(config)
    issues: list[dict] = []
    checked: set[str] = set()
    skipped: dict[str, str] = {}
    all_pl: list[Placement] = []
    for n, c in enumerate(project.get("containers", []), start=1):
        spec = _spec_for(c, specs_by_id, default_spec)
        pls = [ts_to_placement(p, n, idx_of) for p in c.get("placements", [])]
        all_pl += pls
        rep = validate(pls, items, build_ctype(spec), rules)
        checked.update(rep.checked)
        for s in rep.skipped:
            skipped[s["code"]] = s["reason"]
        for k, v in enumerate(rep.violations):
            issues.append(_issue(v, c, k))
    # đối soát số lượng trên toàn dự án
    qrep = validate(all_pl, items, build_ctype(default_spec), replace(rules, allow_weight_check=False),
                    required={it.idx: it.quantity for it in items})
    for k, v in enumerate(x for x in qrep.violations if x.code == "V9"):
        issues.append(_issue(v, None, k))
    n_err = sum(1 for i in issues if i["severity"] == "error")
    return {"engine": f"Python validator {ENGINE_VERSION}", "checkedAt": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "ok": n_err == 0, "errors": n_err, "warnings": len(issues) - n_err,
            "checked": sorted(checked), "skipped": [{"code": k, "reason": v} for k, v in sorted(skipped.items())],
            "issues": issues[:500]}


def _issue(v, c: dict | None, k: int) -> dict:
    return {"id": f"py-{c['id'] if c else 'qty'}-{v.code}-{k}", "severity": v.level,
            "rule": RULE_OF_CODE.get(v.code, v.code), "code": v.code,
            "containerId": c["id"] if c else "", "containerLabel": c["label"] if c else "Toàn dự án",
            "cartonIds": [x for x in (v.ref or "").split("|") if x], "message": v.message}


# ----------------------------------------------------------------------------- chuyển kết quả engine -> React

def _rotation_label(o: int) -> str:
    ix, iy, iz = ORIENTATIONS[o]
    # theo thứ tự trục của giao diện: dài × cao × ngang
    return f"{AXIS[ix]}×{AXIS[iz]}×{AXIS[iy]}"


def _layer_indexes(pls: list[Placement]) -> dict[int, int]:
    order = sorted(range(len(pls)), key=lambda i: pls[i].z)
    layer: dict[int, int] = {}
    for i in order:
        p = pls[i]
        if p.z == 0:
            layer[i] = 0
            continue
        best = -1
        for j in order:
            q = pls[j]
            if q.z >= p.z:
                break
            if q.z + q.dz == p.z and min(p.x + p.dx, q.x + q.dx) > max(p.x, q.x) \
                    and min(p.y + p.dy, q.y + q.dy) > max(p.y, q.y):
                best = max(best, layer.get(j, 0))
        layer[i] = best + 1 if best >= 0 else 1
    return layer


def state_to_ts(st: ContainerState, cont_id: str, sku_of: dict[int, dict], anchor: str,
                start_block: int = 0) -> list[dict]:
    """Bung khối thành từng thùng. Chỉ lấy các khối từ vị trí start_block (dùng khi lấp thêm vào cont cũ)."""
    W = st.ctype.width
    pls: list[Placement] = []
    for b in st.blocks[start_block:]:
        for ix in range(b.nx):
            for iy in range(b.ny):
                for iz in range(b.nz):
                    pls.append(Placement(st.no, b.item, b.x0 + ix * b.dx, b.y0 + iy * b.dy, b.z0 + iz * b.dz,
                                         b.dx, b.dy, b.dz, b.orientation, 0, 0, b.extra))
    pls.sort(key=lambda p: (p.x, p.z, p.y))
    layers = _layer_indexes(pls)
    out = []
    stamp = format(int(time.time() * 1000), "x")
    for k, p in enumerate(pls):
        y_ts = W - (p.y + p.dy) if anchor == "right" else p.y
        out.append({"instanceId": f"py-{stamp}-{st.no}-{start_block}-{k}", "skuId": sku_of[p.item]["id"],
                    "containerId": cont_id, "xMm": p.x, "yMm": p.z, "zMm": y_ts,
                    "dimXMm": p.dx, "dimYMm": p.dz, "dimZMm": p.dy,
                    "rotationLabel": _rotation_label(p.orientation), "layerIndex": layers[k],
                    "anchorMode": anchor if anchor in ("left", "right") else "left"})
    return out


def ts_container_to_state(c: dict, no: int, ctype: ContainerType, items_by_idx: dict[int, CargoItem],
                          idx_of: dict[str, int], all_items: list[CargoItem]) -> ContainerState:
    st = ContainerState(no, ctype)
    for p in c.get("placements", []):
        pl = ts_to_placement(p, no, idx_of)
        it = items_by_idx.get(pl.item)
        if it is None:
            continue
        ors = _orientation_of(it, pl.dx, pl.dy, pl.dz)
        st.blocks.append(Block(pl.x, pl.y, pl.z, pl.dx, pl.dy, pl.dz, 1, 1, 1, pl.item,
                               min(ors) if ors else 0, it.stackable))
    if all_items:
        _rebuild_spaces(st, all_items)
    return st


# ----------------------------------------------------------------------------- số liệu

def metrics(containers: list[dict], skus: list[dict], spec: dict, specs_by_id: dict[str, dict],
            validation: dict, algorithm: str, seconds: float, plan_label: str, extra_note: str = "",
            weight_lb: bool = False) -> dict:
    items_vol = sum(_r(s["lengthMm"]) * _r(s["widthMm"]) * _r(s["heightMm"]) * int(s["requiredQty"]) for s in skus)
    cvol = _r(spec["internalLengthMm"]) * _r(spec["internalWidthMm"]) * _r(spec["internalHeightMm"])
    lb_vol = math.ceil(items_vol / cvol) if items_vol and cvol else 0
    # cận dưới theo trọng lượng: chỉ tính khi bật kiểm tải và có đủ kg + tải tối đa
    items_kg = sum(float(s.get("weightKg") or 0) * int(s["requiredQty"]) for s in skus)
    max_kg = float(spec.get("maxPayloadKg") or 0)
    lb_kg = math.ceil(items_kg / max_kg) if items_kg and max_kg and weight_lb else 0
    lb = max(lb_vol, lb_kg)
    used = [c for c in containers if c.get("placements")]
    n = len(used)
    vols, pays = [], []
    sku_w = {s["id"]: float(s.get("weightKg") or 0) for s in skus}
    for c in used:
        sp = specs_by_id.get(c["containerSpecId"], spec)
        v = _r(sp["internalLengthMm"]) * _r(sp["internalWidthMm"]) * _r(sp["internalHeightMm"])
        vols.append(sum(p["dimXMm"] * p["dimYMm"] * p["dimZMm"] for p in c["placements"]) / v * 100)
        mp = float(sp.get("maxPayloadKg") or 0)
        pays.append(sum(sku_w.get(p["skuId"], 0) for p in c["placements"]) / mp * 100 if mp else 0)
    placed = sum(len(c["placements"]) for c in used)
    required = sum(int(s["requiredQty"]) for s in skus)
    feasible = validation["errors"] == 0 and placed == required
    gap = (n - lb) / lb * 100 if lb and n else 0.0
    if not feasible:
        status = "Infeasible"
    elif n <= lb:
        status = "Proven Optimal (LB Match)"
    else:
        status = "Feasible Solution"
    expl = (f"Engine Python ({plan_label}) xếp {placed}/{required} thùng vào {n} cont. "
            f"Cận dưới = {lb} cont (thể tích {lb_vol}" + (f", trọng lượng {lb_kg}" if lb_kg else "") + f"), khoảng cách tối ưu = (cont dùng − cận dưới)/cận dưới = {gap:.1f}%. "
            f"Kiểm tra độc lập: {validation['errors']} lỗi, {validation['warnings']} cảnh báo."
            + (" Đã chứng minh tối ưu VỀ SỐ CONT." if status.startswith("Proven") else
               " Phương án hợp lệ do heuristic tìm, CHƯA chứng minh tối ưu." if feasible else "")
            + (f" {extra_note}" if extra_note else ""))
    return {"algorithm": algorithm, "containersUsed": n,
            "volumeUtilizationPct": round(sum(vols) / n, 2) if n else 0,
            "payloadUtilizationPct": round(sum(pays) / n, 2) if n else 0,
            "violationsCount": validation["errors"], "computeTimeMs": max(1, int(seconds * 1000)),
            "feasible": feasible, "lowerBoundContainers": lb, "optimalityGapPct": round(gap, 2),
            "statusLabel": status, "explanation": expl}


# ----------------------------------------------------------------------------- tối ưu

def _new_container(no: int, spec: dict, tag: str) -> dict:
    return {"id": f"cnt-{tag}-{no}", "containerSpecId": spec["id"], "label": f"Container #{no} ({spec['code']})",
            "sequenceNumber": no, "placements": []}


def _solve_rest(rest: list[CargoItem], ctype: ContainerType, rules: Rules, plan: dict, seed: int,
                seconds_override: float | None) -> tuple[Solution | None, dict | None]:
    if not rest:
        return None, None
    best, _ = solve(rest, ctype, rules, plan["variants"])
    secs = plan["seconds"] if seconds_override is None else seconds_override
    if secs > 0:
        return improve(best, rest, ctype, rules, time_limit=secs, seed=seed)
    if plan["variants"] is DEFAULT_VARIANTS and not best.unplaced:
        # chế độ nhanh vẫn chạy "dồn cont lỏng" (nhét hàng cont cuối vào khe các cont trước)
        conts, gains = consolidate(best.containers, rest, ctype, rules, time_limit=8.0)
        best = Solution(best.variant, conts, best.unplaced, best.seconds)
        return best, {"iterations": 0, "start_containers": len(conts), "consolidate_gains": gains}
    return best, None


def _clean_incremental(containers_in, specs_by_id, spec, by_idx, idx_of, sku_of, alpha):
    """Bỏ thùng không còn hợp lệ, theo thứ tự an toàn:
    1) thùng của mã đã xoá / sai kích thước-hướng / vượt lòng cont;
    2) mã bị GIẢM số lượng: bỏ thùng ở cont sau cùng, gần cửa nhất, trên cao nhất trước;
    3) bỏ dây chuyền những thùng mất chỗ đỡ (< α) hoặc đang nằm trên hàng cấm chồng."""
    invalid: dict[str, str] = {}
    kept_ids: list[tuple[int, dict]] = []
    for ci, c in enumerate(containers_in):
        sp = _spec_for(c, specs_by_id, spec)
        for p in c.get("placements", []):
            k = idx_of.get(p["skuId"])
            it = by_idx.get(k) if k else None
            reason = None
            if it is None:
                reason = "Mã hàng đã bị xoá khỏi danh sách"
            else:
                pl = ts_to_placement(p, 0, idx_of)
                ors = _orientation_of(it, pl.dx, pl.dy, pl.dz)
                if not ors or not (ors & set(it.allowed_orientations)):
                    reason = f"Kích thước ({it.length}×{it.width}×{it.height}) hoặc luật xoay đã đổi"
                elif pl.x + pl.dx > _r(sp["internalLengthMm"]) or pl.y + pl.dy > _r(sp["internalWidthMm"]) \
                        or pl.z + pl.dz > _r(sp["internalHeightMm"]):
                    reason = "Thùng vượt lòng cont sau khi đổi thông số cont"
            if reason:
                invalid[p["instanceId"]] = reason
            elif not c.get("locked"):
                kept_ids.append((ci, p))
    # 2) số lượng giảm: tính cả cont khoá (không đụng tới chúng)
    count: dict[int, int] = {}
    for c in containers_in:
        for p in c.get("placements", []):
            if p["instanceId"] not in invalid:
                k = idx_of.get(p["skuId"])
                count[k] = count.get(k, 0) + 1
    for k, it in by_idx.items():
        extra = count.get(k, 0) - it.quantity
        if extra <= 0:
            continue
        cands = sorted([(ci, p) for ci, p in kept_ids if idx_of.get(p["skuId"]) == k],
                       key=lambda t: (t[0], t[1]["xMm"] + t[1]["dimXMm"], t[1]["yMm"]), reverse=True)
        for ci, p in cands[:extra]:
            invalid[p["instanceId"]] = f"Số yêu cầu đã giảm còn {it.quantity}; bỏ thùng dư (ưu tiên thùng gần cửa, trên cùng)"
    # 3) dây chuyền mất chỗ đỡ
    changed = True
    while changed:
        changed = False
        for c in containers_in:
            if c.get("locked"):
                continue
            alive = [p for p in c.get("placements", []) if p["instanceId"] not in invalid]
            for p in alive:
                if _r(p["yMm"]) == 0:
                    continue
                area, forbidden = 0, False
                for q in alive:
                    if q is p or _r(q["yMm"]) + _r(q["dimYMm"]) != _r(p["yMm"]):
                        continue
                    ox = min(p["xMm"] + p["dimXMm"], q["xMm"] + q["dimXMm"]) - max(p["xMm"], q["xMm"])
                    oz = min(p["zMm"] + p["dimZMm"], q["zMm"] + q["dimZMm"]) - max(p["zMm"], q["zMm"])
                    if ox > 0 and oz > 0:
                        area += ox * oz
                        qi = by_idx.get(idx_of.get(q["skuId"]))
                        if qi is not None and not qi.stackable:
                            forbidden = True
                if forbidden or area / (p["dimXMm"] * p["dimZMm"]) + 1e-9 < alpha:
                    invalid[p["instanceId"]] = "Mất chỗ đỡ vì thùng bên dưới bị bỏ — đưa lại vào hàng chờ xếp"
                    changed = True
    kept, invalidated, affected, preserved, running = [], [], set(), set(), {}
    for c in containers_in:
        ok_pl, ch = [], False
        for p in c.get("placements", []):
            if p["instanceId"] in invalid:
                ch = True
                k = idx_of.get(p["skuId"])
                invalidated.append({"containerLabel": c["label"],
                                    "factorySku": sku_of[k]["factorySku"] if k in sku_of else p["skuId"],
                                    "reason": invalid[p["instanceId"]]})
                continue
            k = idx_of.get(p["skuId"])
            running[k] = running.get(k, 0) + 1
            ok_pl.append(p)
        kept.append({**c, "placements": ok_pl})
        (affected if ch else preserved).add(c["id"])
    return kept, invalidated, affected, preserved, running


def optimize_project(project: dict, specs: list[dict], keep_mode: str = "locked",
                     seconds_override: float | None = None, seed: int = 1) -> dict:
    """keep_mode:
        'locked'      : giữ nguyên cont đã khoá, xếp lại toàn bộ phần còn lại (nút Auto-Load / Run).
        'incremental' : giữ mọi thùng còn hợp lệ, lấp chỗ trống, phần dư mới mở cont mới (Recalc preview).
    Không ghi đè gì cả — chỉ trả về phương án đề xuất để người dùng duyệt."""
    t0 = time.perf_counter()
    specs_by_id = {s["id"]: s for s in specs}
    spec = specs_by_id.get(project.get("defaultContainerSpecId")) or specs[0]
    config = project.get("optimizationConfig", {})
    algorithm = config.get("algorithm", "hybrid_alns_ep")
    plan = ALGO_PLAN.get(algorithm, ALGO_PLAN["hybrid_alns_ep"])
    anchor = config.get("anchorMode", "left")
    skus = project.get("skus", [])
    items, idx_of, sku_of = build_items(skus, config)
    by_idx = {it.idx: it for it in items}
    ctype = build_ctype(spec)
    rules = replace(build_rules(config), over_allowance_pct=0)
    tag = format(int(time.time()), "x")

    kept: list[dict] = []          # cont giữ lại (bản TS gốc, có thể đã bỏ bớt thùng không hợp lệ)
    invalidated: list[dict] = []
    affected: set[str] = set()
    preserved: set[str] = set()
    running: dict[int, int] = {}

    containers_in = project.get("containers", [])
    if keep_mode == "locked":
        for c in containers_in:
            if c.get("locked"):
                kept.append(c)
                preserved.add(c["id"])
                for p in c["placements"]:
                    k = idx_of.get(p["skuId"])
                    if k:
                        running[k] = running.get(k, 0) + 1
            else:
                affected.add(c["id"])
    else:
        kept, invalidated, affected, preserved, running = _clean_incremental(
            containers_in, specs_by_id, spec, by_idx, idx_of, sku_of, rules.min_support_ratio)

    rest_qty = {it.idx: it.quantity - running.get(it.idx, 0) for it in items}
    if any(v < 0 for v in rest_qty.values()):
        bad = [by_idx[k].customer_sku for k, v in rest_qty.items() if v < 0]
        raise BridgeError("Cont đã khoá đang xếp vượt số yêu cầu của: " + ", ".join(bad) + ". Mở khoá hoặc sửa số trước.")

    # incremental: lấp chỗ trống trong cont giữ lại (chỉ cont không khoá)
    notes = []
    if keep_mode == "incremental" and any(v > 0 for v in rest_qty.values()):
        live = [it for it in items if rest_qty[it.idx] > 0]
        for n, c in enumerate(kept, start=1):
            if c.get("locked") or not any(v > 0 for v in rest_qty.values()):
                continue
            sp = _spec_for(c, specs_by_id, spec)
            st = ts_container_to_state(c, n, build_ctype(sp), by_idx, idx_of, items)
            before = len(st.blocks)
            got = _fill(st, live, rest_qty, DEFAULT_VARIANTS[0], rules.min_support_ratio)
            if got:
                new_pl = state_to_ts(st, c["id"], sku_of, anchor, start_block=before)
                c["placements"] = c["placements"] + new_pl
                affected.add(c["id"])
                preserved.discard(c["id"])
        notes.append("Đã giữ các thùng còn hợp lệ và lấp vào chỗ trống trước khi mở cont mới.")

    rest = [replace(it, quantity=rest_qty[it.idx]) for it in items if rest_qty[it.idx] > 0]
    sol, log = _solve_rest(rest, ctype, rules, plan, seed, seconds_override)
    new_conts: list[dict] = []
    unplaced = {}
    if sol is not None:
        unplaced = {by_idx[k].customer_sku: v for k, v in sol.unplaced.items()}
        for st in sol.containers:
            nc = _new_container(len(kept) + len(new_conts) + 1, spec, tag)
            nc["placements"] = state_to_ts(st, nc["id"], sku_of, anchor)
            new_conts.append(nc)
            if keep_mode == "incremental":
                affected.add(nc["id"])

    proposed = [c for c in kept if c["placements"] or c.get("locked")] + new_conts
    for i, c in enumerate(proposed, start=1):
        sp = _spec_for(c, specs_by_id, spec)
        c["sequenceNumber"] = i
        c["label"] = f"Container #{i} ({sp['code']})"
        for p in c["placements"]:
            p["containerId"] = c["id"]
    val = validate_project({**project, "containers": proposed}, specs)
    if unplaced:
        notes.append("KHÔNG xếp được: " + ", ".join(f"{k} ×{v}" for k, v in unplaced.items()) + " (thùng lớn hơn cont hoặc luật xoay quá chặt).")
    if log:
        notes.append(f"Vòng cải thiện: {log.get('iterations', 0)} lượt phá–sửa, {log.get('consolidate_gains', 0)} lần dồn cont lỏng, kết quả {len(sol.containers)} cont.")
    met = metrics(proposed, skus, spec, specs_by_id, val, algorithm, time.perf_counter() - t0, plan["label"], " ".join(notes),
                  weight_lb=bool(config.get("respectPayload")))
    if invalidated:
        summary = f"{len(invalidated)} thùng không còn hợp lệ sau khi sửa dữ liệu; giữ nguyên {len(preserved)} cont."
    elif keep_mode == "locked":
        summary = (f"Phương án mới: {met['containersUsed']} cont (cận dưới {met['lowerBoundContainers']}), "
                   f"giữ nguyên {len(preserved)} cont đã khoá. Chưa ghi đè — bấm duyệt để áp dụng.")
    else:
        summary = "Giữ toàn bộ thùng còn hợp lệ; phần còn lại được xếp vào chỗ trống/cont mới."
    return {"affectedContainerIds": sorted(affected), "preservedContainerIds": sorted(preserved),
            "invalidatedCartons": invalidated, "proposedContainers": proposed, "proposedMetrics": met,
            "summary": summary, "validation": val, "engineVersion": ENGINE_VERSION}


# ----------------------------------------------------------------------------- benchmark trên cùng bộ dữ liệu

def benchmark(project: dict, specs: list[dict], improve_seconds: float = 15.0) -> list[dict]:
    specs_by_id = {s["id"]: s for s in specs}
    spec = specs_by_id.get(project.get("defaultContainerSpecId")) or specs[0]
    config = project.get("optimizationConfig", {})
    skus = project.get("skus", [])
    items, _, sku_of = build_items(skus, config)
    ctype = build_ctype(spec)
    rules = replace(build_rules(config), over_allowance_pct=0)
    rows = []

    def row(alg_id, name, cat, sol: Solution, secs, note):
        conts = []
        for st in sol.containers:
            c = _new_container(st.no, spec, "bm")
            c["placements"] = state_to_ts(st, c["id"], sku_of, "left")
            conts.append(c)
        val = validate_project({**project, "containers": conts}, specs)
        m = metrics(conts, skus, spec, specs_by_id, val, alg_id, secs, name)
        vols = [sum(p["dimXMm"] * p["dimYMm"] * p["dimZMm"] for p in c["placements"]) / ctype.volume * 100 for c in conts]
        rows.append({"algorithmId": alg_id, "algorithmName": name, "category": cat,
                     "containersUsed": m["containersUsed"], "avgVolumePct": m["volumeUtilizationPct"],
                     "bestVolumePct": round(max(vols), 2) if vols else 0, "worstVolumePct": round(min(vols), 2) if vols else 0,
                     "payloadPct": m["payloadUtilizationPct"], "violations": m["violationsCount"],
                     "computeTimeMs": m["computeTimeMs"], "feasible": m["feasible"],
                     "optimalityGapPct": m["optimalityGapPct"], "statusLabel": m["statusLabel"], "notes": note})

    t = time.perf_counter()
    ffd = pack(items, ctype, rules, FFD_BASELINE)
    row("ffd", "FFD baseline (Python)", "Tham lam (mốc)", ffd, time.perf_counter() - t,
        "Xếp tham lam theo thể tích giảm dần — mốc so sánh tối thiểu.")
    t = time.perf_counter()
    best, sols = solve(items, ctype, rules)
    row("block_portfolio", f"Xếp khối – biến thể tốt nhất ({best.variant.name})", "Xếp khối (10 biến thể)",
        best, time.perf_counter() - t,
        "Các biến thể: " + ", ".join(f"{s.variant.name}={s.n_containers}" for s in sols))
    if improve_seconds > 0:
        t = time.perf_counter()
        imp, log = improve(best, items, ctype, rules, time_limit=improve_seconds, seed=1)
        row("block_improve", f"Xếp khối + cải thiện phá-sửa ({improve_seconds:.0f} giây)", "Cải thiện phá–sửa",
            imp, time.perf_counter() - t + 0, f"{log.get('iterations', 0)} lượt cải thiện, seed 1 (tái lập được).")
    lb = lower_bound_containers(items, ctype)
    rows.append({"algorithmId": "lower_bound", "algorithmName": "Cận dưới thể tích (không phải phương án)",
                 "category": "Cận dưới", "containersUsed": lb, "avgVolumePct": 0, "bestVolumePct": 0,
                 "worstVolumePct": 0, "payloadPct": 0, "violations": 0, "computeTimeMs": 0, "feasible": True,
                 "optimalityGapPct": 0, "statusLabel": "Lower Bound",
                 "notes": "ceil(tổng thể tích hàng / thể tích 1 cont). Không phương án nào dùng ít cont hơn số này."})
    return rows
