"""Lưu trữ SQLite + sổ số lượng (Quantity Ledger) chỉ-ghi-thêm.

Vì sao SQLite: chạy local không cần cài server, 1 file dữ liệu dễ sao lưu.
Khi lên nhiều người dùng sẽ chuyển sang PostgreSQL/Supabase với cùng cấu trúc bảng.

Quy tắc số lượng (không bao giờ UPDATE con số, chỉ thêm giao dịch):
  required  = số yêu cầu ban đầu + Σ(adjust_required)
  loaded    = Σ(confirm_load) + Σ(unload)       (unload mang dấu âm)
  remaining = required - loaded   — trigger chặn remaining < 0 và loaded < 0
"""
from __future__ import annotations

import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime

DB_PATH = os.environ.get("CLOS_DB", os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "clos.db"))

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS container_types (
  id INTEGER PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  length_mm INTEGER NOT NULL CHECK (length_mm > 0),
  width_mm INTEGER NOT NULL CHECK (width_mm > 0),
  height_mm INTEGER NOT NULL CHECK (height_mm > 0),
  max_payload_kg REAL,
  note TEXT,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  customer TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  source_file TEXT,
  import_report TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cargo_lines (
  id INTEGER PRIMARY KEY,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  idx INTEGER NOT NULL,
  customer_sku TEXT NOT NULL,
  factory_sku TEXT,
  description TEXT,
  length_mm INTEGER NOT NULL CHECK (length_mm > 0),
  width_mm INTEGER NOT NULL CHECK (width_mm > 0),
  height_mm INTEGER NOT NULL CHECK (height_mm > 0),
  base_quantity INTEGER NOT NULL CHECK (base_quantity >= 0),
  orientation_code INTEGER NOT NULL CHECK (orientation_code IN (1,2,4,6)),
  stackable INTEGER NOT NULL DEFAULT 1,
  is_pallet INTEGER NOT NULL DEFAULT 0,
  weight_kg REAL,
  max_stack_layers INTEGER,
  color TEXT,
  UNIQUE (project_id, customer_sku),
  UNIQUE (project_id, idx)
);

CREATE TABLE IF NOT EXISTS optimization_runs (
  id INTEGER PRIMARY KEY,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  container_type_id INTEGER NOT NULL REFERENCES container_types(id),
  mode TEXT, seed INTEGER, input_hash TEXT, engine_version TEXT,
  solver_status TEXT, n_containers INTEGER, lower_bound INTEGER, gap REAL, seconds REAL,
  valid INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',  -- draft | confirmed | superseded
  summary TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS placements (
  id INTEGER PRIMARY KEY,
  run_id INTEGER NOT NULL REFERENCES optimization_runs(id) ON DELETE CASCADE,
  container_no INTEGER NOT NULL,
  cargo_line_id INTEGER NOT NULL REFERENCES cargo_lines(id),
  x INTEGER NOT NULL, y INTEGER NOT NULL, z INTEGER NOT NULL,
  dx INTEGER NOT NULL, dy INTEGER NOT NULL, dz INTEGER NOT NULL,
  orientation INTEGER NOT NULL, load_seq INTEGER, block INTEGER, extra INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_placements_run ON placements(run_id, container_no, cargo_line_id);

CREATE TABLE IF NOT EXISTS qty_transactions (
  id INTEGER PRIMARY KEY,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  cargo_line_id INTEGER NOT NULL REFERENCES cargo_lines(id),
  container_no INTEGER,
  run_id INTEGER REFERENCES optimization_runs(id),
  delta INTEGER NOT NULL,
  reason TEXT NOT NULL CHECK (reason IN ('confirm_load','unload','adjust_required')),
  note TEXT,
  user_name TEXT,
  created_at TEXT NOT NULL
);

CREATE VIEW IF NOT EXISTS v_qty_balance AS
SELECT l.id AS cargo_line_id, l.project_id, l.customer_sku, l.factory_sku, l.description,
       l.base_quantity + COALESCE((SELECT SUM(delta) FROM qty_transactions t
              WHERE t.cargo_line_id = l.id AND t.reason = 'adjust_required'), 0) AS required,
       COALESCE((SELECT SUM(delta) FROM qty_transactions t
              WHERE t.cargo_line_id = l.id AND t.reason IN ('confirm_load','unload')), 0) AS loaded
FROM cargo_lines l;

-- Chặn số âm và nạp vượt yêu cầu ngay trong database (không phụ thuộc code ứng dụng)
CREATE TRIGGER IF NOT EXISTS trg_qty_guard
AFTER INSERT ON qty_transactions
BEGIN
  SELECT CASE
    WHEN (SELECT loaded FROM v_qty_balance WHERE cargo_line_id = NEW.cargo_line_id) < 0
      THEN RAISE(ABORT, 'LEDGER: số đã xếp không được âm')
    WHEN (SELECT loaded FROM v_qty_balance WHERE cargo_line_id = NEW.cargo_line_id)
       > (SELECT required FROM v_qty_balance WHERE cargo_line_id = NEW.cargo_line_id)
      THEN RAISE(ABORT, 'LEDGER: số đã xếp vượt số yêu cầu (remaining < 0)')
    WHEN (SELECT required FROM v_qty_balance WHERE cargo_line_id = NEW.cargo_line_id) < 0
      THEN RAISE(ABORT, 'LEDGER: số yêu cầu không được âm')
  END;
END;

-- Sổ chỉ-ghi-thêm: cấm sửa / xoá giao dịch
CREATE TRIGGER IF NOT EXISTS trg_qty_no_update BEFORE UPDATE ON qty_transactions
BEGIN SELECT RAISE(ABORT, 'LEDGER: giao dịch số lượng không được sửa, hãy ghi giao dịch bù'); END;
CREATE TRIGGER IF NOT EXISTS trg_qty_no_delete BEFORE DELETE ON qty_transactions
BEGIN SELECT RAISE(ABORT, 'LEDGER: giao dịch số lượng không được xoá'); END;

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY,
  entity TEXT NOT NULL, entity_id INTEGER, action TEXT NOT NULL,
  detail TEXT, user_name TEXT, at TEXT NOT NULL
);
"""

DEFAULT_CONTAINERS = [
    ("40HC-CUSTOM", "40' HC tuỳ chỉnh (1199×234×269 cm)", 11990, 2340, 2690, None,
     "Kích thước 'To Use' trong CargoWiz. PDF Cont 44 ghi ngang 232 cm — CHƯA XÁC NHẬN"),
    ("40HC", "40' High Cube (chuẩn)", 12040, 2350, 2700, None, "Danh nghĩa, chưa trừ hao"),
    ("40GP", "40' Std Dry", 12040, 2350, 2380, None, "Danh nghĩa, chưa trừ hao"),
    ("20GP", "20' Dry", 5940, 2350, 2380, None, "Danh nghĩa, chưa trừ hao"),
    ("45HC", "45' High Cube", 13590, 2350, 2700, None, "Danh nghĩa, chưa trừ hao"),
]


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


@contextmanager
def connect(path: str | None = None):
    p = path or DB_PATH
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    con = sqlite3.connect(p)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def init_db(path: str | None = None) -> None:
    with connect(path) as con:
        con.executescript(SCHEMA)
        for code, name, l, w, h, kg, note in DEFAULT_CONTAINERS:
            con.execute("INSERT OR IGNORE INTO container_types(code,name,length_mm,width_mm,height_mm,max_payload_kg,note)"
                        " VALUES (?,?,?,?,?,?,?)", (code, name, l, w, h, kg, note))


def audit(con, entity: str, entity_id: int | None, action: str, detail: dict | None = None, user: str = "local") -> None:
    con.execute("INSERT INTO audit_log(entity,entity_id,action,detail,user_name,at) VALUES (?,?,?,?,?,?)",
                (entity, entity_id, action, json.dumps(detail or {}, ensure_ascii=False), user, now()))


def balance(con, project_id: int) -> list[dict]:
    rows = con.execute("SELECT * FROM v_qty_balance WHERE project_id=? ORDER BY cargo_line_id", (project_id,)).fetchall()
    per = con.execute(
        "SELECT cargo_line_id, container_no, SUM(delta) AS q FROM qty_transactions"
        " WHERE project_id=? AND reason IN ('confirm_load','unload') GROUP BY cargo_line_id, container_no"
        " HAVING q <> 0", (project_id,)).fetchall()
    by: dict[int, dict] = {}
    for r in per:
        by.setdefault(r["cargo_line_id"], {})[str(r["container_no"])] = r["q"]
    out = []
    for r in rows:
        d = dict(r)
        d["remaining"] = d["required"] - d["loaded"]
        d["by_container"] = by.get(r["cargo_line_id"], {})
        out.append(d)
    return out


def reconcile_check(con, project_id: int, run_id: int) -> list[str]:
    """Kiểm tra chéo: số thùng trong placements của phương án đã xác nhận = số trong sổ, từng (SKU, cont)."""
    problems = []
    plc = {(r["cargo_line_id"], r["container_no"]): r["n"] for r in con.execute(
        "SELECT cargo_line_id, container_no, COUNT(*) n FROM placements WHERE run_id=? GROUP BY 1,2", (run_id,))}
    led = {(r["cargo_line_id"], r["container_no"]): r["q"] for r in con.execute(
        "SELECT cargo_line_id, container_no, SUM(delta) q FROM qty_transactions WHERE project_id=?"
        " AND reason IN ('confirm_load','unload') GROUP BY 1,2 HAVING q <> 0", (project_id,))}
    for k in set(plc) | set(led):
        if plc.get(k, 0) != led.get(k, 0):
            problems.append(f"line {k[0]} cont {k[1]}: placements={plc.get(k, 0)} ledger={led.get(k, 0)}")
    for b in balance(con, project_id):
        if b["required"] != b["loaded"] + b["remaining"] or b["remaining"] < 0:
            problems.append(f"{b['customer_sku']}: Required ≠ Loaded + Remaining")
    return problems
