# CLOS by Vincent

Ứng dụng tính xếp container 3D cho hàng thùng carton (nội thất, hàng bán lẻ…). CLOS chạy trên trình duyệt, máy chủ Python tính toán và lưu dữ liệu. Có thể dùng thay CargoWiz cho các lô hàng carton.

![Màn xếp hàng 3D](docs/images/workspace.png)

## Tính năng chính

- **Xếp tự động**: thuật toán xếp khối + cải thiện (Maximal Spaces, Block Building, tìm kiếm cục bộ có seed). Chọn phương án ít cont nhất, kết quả tái lập được, không dùng AI để đoán toạ độ.
- **Kiểm tra độc lập (V1–V9)**: một bộ code riêng dò lại tràn cont, chồng lấn, mã xoay, số lớp chồng, tải trọng, trọng tâm, độ đỡ đáy và số lượng.
- **Đối soát số lượng**: với từng mã, Yêu cầu = Đã xếp + Còn lại. Máy chủ giữ sổ số lượng riêng và chặn xuất file khi phát hiện lệch.
- **Mã xoay 1/2/4/6 giống CargoWiz**, cột *Lớp tối đa*, tỷ lệ đỡ đáy tối thiểu chỉnh được.
- **Dán thẳng từ Excel** (Ctrl+C / Ctrl+V), đọc số kiểu Việt Nam (44,5 · 1.860). Nhập/xuất file Excel.
- **Chỉnh tay trên 3D**: kéo thả, xoay, canh Sát trái / Giữa / Sát phải, thêm số lượng ngay màn 3D. **Tính lại** chỉ xếp lại phần thay đổi và cho duyệt trước khi áp dụng.
- **Khoá nhiều cont**, **lùi/tiến (Ctrl+Z / Ctrl+Y)**, **lịch sử thay đổi** lưu trên máy chủ, xoá mã hàng loạt, tìm kiếm.
- **Thư viện mẫu xếp**: lưu cách xếp một cont để dùng lại.
- **Báo cáo**: Excel, PDF tổng hợp, PDF từng bước 3D (font tiếng Việt, kích thước mm, có ô tick kiểm đếm), In.

| Dữ liệu hàng | Tổng quan |
|---|---|
| ![Dữ liệu hàng](docs/images/cargo.png) | ![Tổng quan](docs/images/dashboard.png) |

## Tải về và dùng (Windows, không cần cài gì)

1. Vào mục **[Releases](../../releases/latest)**, tải file **CLOS-Windows.zip**.
2. Giải nén, mở thư mục `CLOS`, bấm đúp **CLOS.exe**. Trình duyệt tự mở CLOS.
3. Windows có thể báo *"Windows protected your PC"* vì file chưa được ký số. Bấm **More info → Run anyway**.

Dữ liệu lưu trong thư mục `data` cạnh `CLOS.exe`. Muốn sao lưu, chỉ cần copy thư mục này.

### Cả văn phòng dùng chung

Chọn một máy bật suốt giờ làm, bấm đúp **`Chay CLOS cho ca van phong.bat`**. Cửa sổ sẽ hiện địa chỉ dạng `http://192.168.x.x:8000`, người khác cùng mạng mở địa chỉ đó là dùng được.

- Lần đầu chạy, Windows hỏi tường lửa: chọn **Allow** cho mạng Private.
- Nên đặt mật khẩu: sửa file `.bat`, bỏ chữ `REM` ở dòng `set CLOS_PASSWORD=...`.
- Dữ liệu chỉ nằm trên máy đang chạy CLOS. Hãy sao lưu thư mục `data` định kỳ.

## Chạy từ mã nguồn (macOS / Linux / Windows)

Cần Python 3.10 trở lên. Không cần Node vì giao diện đã build sẵn trong `web/dist`.

```bash
./start.sh          # chỉ máy này      (Windows: start.bat)
./start-lan.sh      # cả mạng nội bộ   (Windows: start-lan.bat)
```

Hoặc chạy bằng Docker: `docker compose up -d`, rồi mở http://localhost:8000.

Biến môi trường tuỳ chọn: `CLOS_PORT` (đổi cổng), `CLOS_PASSWORD` (bắt nhập mật khẩu), `CLOS_NO_BROWSER=1` (không tự mở trình duyệt).

## Đưa lên máy chủ (dùng qua Internet)

Xem [deploy/README.md](deploy/README.md). Script chạy CLOS sau Caddy (HTTPS + mật khẩu) và tự sao lưu dữ liệu mỗi ngày.

> CLOS không có hệ thống tài khoản riêng. Khi mở ra Internet, bắt buộc phải đặt sau reverse proxy có mật khẩu hoặc đặt `CLOS_PASSWORD`.

## Phát triển

```bash
# Backend
python -m venv .venv && .venv/bin/pip install -r requirements.txt
.venv/bin/python -m pytest -q          # 46 test

# Giao diện (React 19 + Vite + Three.js)
cd web
npm install --legacy-peer-deps
npm run dev        # http://localhost:3000, gọi API ở cổng 8000
npm run build      # build lại web/dist, máy chủ Python sẽ phục vụ bản này
```

**Phát hành bản Windows:** tạo Release mới trên GitHub, đặt tag dạng `v1.0.0`. GitHub Actions sẽ tự build `CLOS-Windows.zip` (khoảng 5 phút) và đính kèm vào Release đó. Muốn build thử trên máy: `pip install pyinstaller && pyinstaller packaging/clos.spec`.

## Cấu trúc

```
clos/engine/      thuật toán xếp (packer, improve) + validator độc lập
clos/web_api.py   API cho giao diện  (/api/web/…)
clos/store.py     lưu SQLite: dự án, lịch sử phiên bản, sổ số lượng
clos/io/          nhập / xuất Excel
web/src/          giao diện React (màn 3D, dữ liệu hàng, báo cáo, PDF)
web/dist/         giao diện đã build sẵn
deploy/           Docker + Caddy + sao lưu cho máy chủ
packaging/        đóng gói CLOS.exe (PyInstaller) + hướng dẫn kèm bản Windows
.github/workflows tự build bản Windows khi tạo Release
tests/            pytest
benchmark.py      so sánh các thuật toán trên 1 file Excel
```

## Giới hạn hiện tại

- Chỉ hỗ trợ thùng hình hộp. Chưa hỗ trợ pallet, hàng hình trụ hay hàng có hình dạng đặc biệt.
- Kết quả "Hợp lệ, chưa chứng minh tối ưu" nghĩa là phương án đúng luật nhưng chưa chắc ít cont nhất. Hãy so với cận dưới hiển thị trong bảng duyệt.
- Lịch sử lùi/tiến chỉ nằm trong tab trình duyệt đang mở. Muốn quay về bản cũ hơn, dùng Lịch sử thay đổi trên máy chủ.

## Giấy phép

[PolyForm Internal Use 1.0.0](LICENSE.md). Tóm tắt (không thay cho bản giấy phép):

- ✅ Công ty và cá nhân được **dùng miễn phí** cho hoạt động nội bộ, kể cả hoạt động kinh doanh của chính mình.
- ✅ Được **sửa** cho nhu cầu nội bộ.
- ❌ **Không được phân phối lại**, bán lại, hay đóng gói CLOS thành sản phẩm/dịch vụ cho người khác.

Muốn dùng ngoài phạm vi trên (bán lại, cung cấp dịch vụ, hợp tác), hãy liên hệ tác giả.

## Liên hệ

- Email: [conghaupham.work@gmail.com](mailto:conghaupham.work@gmail.com)
- Điện thoại / Zalo: 0349 699 340

Báo lỗi hoặc góp ý: mở mục **Issues** trên GitHub hoặc gửi email.

---

**CLOS by Vincent**
