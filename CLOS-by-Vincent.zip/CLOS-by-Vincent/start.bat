@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist .venv (
  echo Lan dau: dang tao moi truong va cai thu vien...
  python -m venv .venv || (echo Khong tim thay Python. Cai Python 3.11+ va tick "Add python.exe to PATH". & pause & exit /b 1)
  .venv\Scripts\python -m pip install --upgrade pip
  .venv\Scripts\python -m pip install -r requirements.txt || (pause & exit /b 1)
)
echo Dang chay CLOS tai http://localhost:8000  (dong cua so nay de tat)
.venv\Scripts\python run.py
pause
