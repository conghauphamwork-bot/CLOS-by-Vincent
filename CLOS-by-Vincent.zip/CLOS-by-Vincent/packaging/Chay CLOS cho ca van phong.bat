@echo off
chcp 65001 >nul
cd /d "%~dp0"
REM Cho ca van phong cung dung. Muon bat mat khau: bo chu REM o dong duoi va doi mat khau.
REM set CLOS_PASSWORD=doi-mat-khau-o-day
CLOS.exe --lan
pause
