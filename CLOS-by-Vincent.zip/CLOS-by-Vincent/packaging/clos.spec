# PyInstaller: đóng gói CLOS thành thư mục chạy được (CLOS.exe trên Windows).
#   pyinstaller packaging/clos.spec --noconfirm
# Kết quả ở dist/CLOS/. Giao diện React lấy từ web/dist (đã build sẵn trong repo).
import os
from PyInstaller.utils.hooks import collect_submodules

ROOT = os.path.abspath(os.path.join(SPECPATH, ".."))

hidden = (collect_submodules("uvicorn") + collect_submodules("clos")
          + ["multipart", "python_multipart", "openpyxl"])

a = Analysis(
    [os.path.join(ROOT, "run.py")],
    pathex=[ROOT],
    datas=[
        (os.path.join(ROOT, "web", "dist"), os.path.join("web", "dist")),
        (os.path.join(ROOT, "clos", "static"), os.path.join("clos", "static")),
    ],
    hiddenimports=hidden,
    excludes=["pytest", "tkinter", "matplotlib", "numpy", "pandas", "PIL"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="CLOS",
    console=True,          # giữ cửa sổ đen để thấy địa chỉ mạng nội bộ; đóng cửa sổ = tắt CLOS
    icon=None,
)
coll = COLLECT(exe, a.binaries, a.datas, name="CLOS")
