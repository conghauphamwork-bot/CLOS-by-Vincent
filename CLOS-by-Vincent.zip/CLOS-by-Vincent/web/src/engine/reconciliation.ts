import {
  CargoSku,
  ContainerLoad,
  ContainerSpec,
  ContainerStats,
  PlacedCarton,
  ReconciliationRow,
} from '../types/clos';

export function computeContainerStats(
  container: ContainerLoad,
  spec: ContainerSpec,
  skuMap: Map<string, CargoSku>
): ContainerStats {
  const totalVolMm3 =
    spec.internalLengthMm * spec.internalWidthMm * spec.internalHeightMm;
  let usedVolMm3 = 0;
  let totalWeightKg = 0;
  let weightedX = 0;
  let weightedY = 0;
  let weightedZ = 0;
  let maxLayer = 0;

  for (const c of container.placements) {
    const sku = skuMap.get(c.skuId);
    const weight = sku ? sku.weightKg : 0;
    const volMm3 = c.dimXMm * c.dimYMm * c.dimZMm;
    usedVolMm3 += volMm3;
    totalWeightKg += weight;
    weightedX += (c.xMm + c.dimXMm / 2) * weight;
    weightedY += (c.yMm + c.dimYMm / 2) * weight;
    weightedZ += (c.zMm + c.dimZMm / 2) * weight;
    if (c.layerIndex > maxLayer) maxLayer = c.layerIndex;
  }

  const usedVolumeM3 = usedVolMm3 / 1e9;
  const totalVolumeM3 = totalVolMm3 / 1e9;
  const volumeUtilizationPct =
    totalVolMm3 > 0 ? Math.min(100, (usedVolMm3 / totalVolMm3) * 100) : 0;
  const payloadUtilizationPct =
    spec.maxPayloadKg > 0 ? (totalWeightKg / spec.maxPayloadKg) * 100 : 0;

  const cogXMm =
    totalWeightKg > 0 ? weightedX / totalWeightKg : spec.internalLengthMm / 2;
  const cogYMm = totalWeightKg > 0 ? weightedY / totalWeightKg : 0;
  const cogZMm =
    totalWeightKg > 0 ? weightedZ / totalWeightKg : spec.internalWidthMm / 2;

  const cogLongitudinalOffsetPct =
    spec.internalLengthMm > 0
      ? (Math.abs(cogXMm - spec.internalLengthMm / 2) / spec.internalLengthMm) *
        100
      : 0;
  const cogLateralOffsetPct =
    spec.internalWidthMm > 0
      ? (Math.abs(cogZMm - spec.internalWidthMm / 2) / spec.internalWidthMm) *
        100
      : 0;

  const cogBalanceOk =
    cogLongitudinalOffsetPct <= 15 && cogLateralOffsetPct <= 15;

  return {
    usedVolumeM3,
    totalVolumeM3,
    volumeUtilizationPct,
    totalCargoWeightKg: totalWeightKg,
    payloadUtilizationPct,
    cogXMm,
    cogYMm,
    cogZMm,
    cogLongitudinalOffsetPct,
    cogLateralOffsetPct,
    cogBalanceOk,
    totalCartons: container.placements.length,
    layerCount: container.placements.length > 0 ? maxLayer + 1 : 0,
  };
}

export function reconcileProjectQuantities(
  skus: CargoSku[],
  containers: ContainerLoad[]
): {
  rows: ReconciliationRow[];
  totalRequired: number;
  totalLoaded: number;
  totalRemaining: number;
  hasDiscrepancies: boolean;
  duplicateInstanceIds: string[];
} {
  const seenInstances = new Set<string>();
  const duplicateInstanceIds: string[] = [];
  const countsBySku = new Map<string, Record<string, number>>();

  for (const sku of skus) {
    const perContainer: Record<string, number> = {};
    for (const c of containers) {
      perContainer[c.id] = 0;
    }
    countsBySku.set(sku.id, perContainer);
  }

  for (const container of containers) {
    for (const p of container.placements) {
      if (seenInstances.has(p.instanceId)) {
        duplicateInstanceIds.push(p.instanceId);
        continue;
      }
      seenInstances.add(p.instanceId);

      const mapEntry = countsBySku.get(p.skuId);
      if (mapEntry) {
        mapEntry[container.id] = (mapEntry[container.id] ?? 0) + 1;
      }
    }
  }

  let totalRequired = 0;
  let totalLoaded = 0;
  let totalRemaining = 0;
  let hasDiscrepancies = duplicateInstanceIds.length > 0;

  const rows: ReconciliationRow[] = skus.map((sku) => {
    const perContainerQty = countsBySku.get(sku.id) ?? {};
    const loadedQty = Object.values(perContainerQty).reduce(
      (sum, v) => sum + v,
      0
    );
    const remainingQty = sku.requiredQty - loadedQty;
    const reconciled =
      sku.requiredQty === loadedQty + remainingQty &&
      remainingQty >= 0 &&
      duplicateInstanceIds.length === 0;

    let status: ReconciliationRow['status'] = 'partial';
    if (remainingQty < 0) {
      status = 'overallocated';
      hasDiscrepancies = true;
    } else if (loadedQty === 0) {
      status = 'unloaded';
    } else if (remainingQty === 0) {
      status = 'complete';
    } else {
      status = 'partial';
    }

    totalRequired += sku.requiredQty;
    totalLoaded += loadedQty;
    totalRemaining += remainingQty;

    return {
      skuId: sku.id,
      factorySku: sku.factorySku,
      customerSku: sku.customerSku,
      description: sku.description,
      color: sku.color,
      dimensionsLabel: `${sku.lengthMm}×${sku.widthMm}×${sku.heightMm}`,
      requiredQty: sku.requiredQty,
      perContainerQty,
      totalLoadedQty: loadedQty,
      remainingQty,
      reconciled,
      status,
    };
  });

  return {
    rows,
    totalRequired,
    totalLoaded,
    totalRemaining,
    hasDiscrepancies,
    duplicateInstanceIds,
  };
}

export function canAllocateMoreOfSku(
  sku: CargoSku,
  containers: ContainerLoad[],
  additionalQty = 1
): boolean {
  let loaded = 0;
  for (const c of containers) {
    for (const p of c.placements) {
      if (p.skuId === sku.id) loaded++;
    }
  }
  return loaded + additionalQty <= sku.requiredQty;
}

export function computeLayerIndex(
  candidate: Pick<PlacedCarton, 'xMm' | 'yMm' | 'zMm' | 'dimXMm' | 'dimYMm' | 'dimZMm'>,
  existing: PlacedCarton[]
): number {
  if (candidate.yMm <= 1) return 0;
  let maxUnderLayer = -1;
  for (const other of existing) {
    const overlapX =
      Math.min(candidate.xMm + candidate.dimXMm, other.xMm + other.dimXMm) -
      Math.max(candidate.xMm, other.xMm);
    const overlapZ =
      Math.min(candidate.zMm + candidate.dimZMm, other.zMm + other.dimZMm) -
      Math.max(candidate.zMm, other.zMm);
    if (
      overlapX > 5 &&
      overlapZ > 5 &&
      Math.abs(other.yMm + other.dimYMm - candidate.yMm) <= 5
    ) {
      if (other.layerIndex > maxUnderLayer) {
        maxUnderLayer = other.layerIndex;
      }
    }
  }
  return maxUnderLayer >= 0 ? maxUnderLayer + 1 : 1;
}
