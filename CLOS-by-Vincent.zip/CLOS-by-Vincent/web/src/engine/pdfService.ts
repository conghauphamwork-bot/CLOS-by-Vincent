import { PDF_FONT, registerVietFont } from './pdfFont';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import {
  CargoSku,
  ContainerLoad,
  ContainerSpec,
  LoadingProject,
} from '../types/clos';
import {
  computeContainerStats,
  reconcileProjectQuantities,
} from './reconciliation';
import {
  buildInsideToOutsideStepGroups,
  renderContainerIsometricDataUrl,
  renderTopDownPlanDataUrl,
} from './stepPlanRenderer';

// Cắt chữ cho vừa bề rộng (mm) theo font hiện tại — tránh tràn cột khi chữ tiếng Việt dài
function fitText(doc: jsPDF, text: string, maxW: number): string {
  if (doc.getTextWidth(text) <= maxW) return text;
  let t = text;
  while (t.length > 1 && doc.getTextWidth(t + '…') > maxW) t = t.slice(0, -1);
  return t + '…';
}

// Đã nhúng font tiếng Việt nên giữ nguyên dấu; chỉ bỏ ký tự điều khiển
function asciiSafe(input: string): string {
  return input.replace(/[\u0000-\u001f]/g, ' ');
}

function parseHexRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  if (clean.length === 3) {
    return [
      parseInt(clean[0] + clean[0], 16),
      parseInt(clean[1] + clean[1], 16),
      parseInt(clean[2] + clean[2], 16),
    ];
  }
  const n = parseInt(clean.slice(0, 6), 16);
  if (Number.isNaN(n)) return [59, 130, 246];
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function exportProjectToPdf(
  project: LoadingProject,
  specsById: Map<string, ContainerSpec>,
  options?: {
    containerFilterId?: string;
    snapshotDataUrl?: string | null;
  }
) {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  registerVietFont(doc);
  const skuMap = new Map(project.skus.map((s) => [s.id, s]));
  const recon = reconcileProjectQuantities(project.skus, project.containers);

  const targetContainers: ContainerLoad[] = options?.containerFilterId
    ? project.containers.filter((c) => c.id === options.containerFilterId)
    : project.containers;

  // Page 1: Executive Summary & Reconciliation
  doc.setFontSize(16);
  doc.setTextColor(15, 23, 42);
  doc.text(asciiSafe(`CLOS by Vincent – Kế hoạch xếp cont – ${project.code}`), 14, 16);

  doc.setFontSize(9.5);
  doc.setTextColor(71, 85, 105);
  doc.text(
    asciiSafe(
      `Dự án: ${project.name}  | Khách: ${project.customerName}  | Cảng đến: ${project.destinationPort}  | Trạng thái: ${({ draft: 'Nháp', calculated: 'Đã tính', verified: 'Đã kiểm', exported: 'Đã xuất' } as Record<string, string>)[project.status] ?? project.status}`
    ),
    14,
    22
  );

  // Embed 3D snapshot if captured from WebGL viewport
  let nextY = 28;
  if (options?.snapshotDataUrl) {
    try {
      doc.addImage(options.snapshotDataUrl, 'PNG', 14, 26, 130, 68);
      doc.setFontSize(8);
      doc.text('Hình 3D xếp cont (góc nhìn hiện tại)', 14, 98);
      nextY = 104;
    } catch {
      nextY = 28;
    }
  }

  // Container summary table
  const contRows = targetContainers.map((c) => {
    const spec = specsById.get(c.containerSpecId)!;
    const stats = computeContainerStats(c, spec, skuMap);
    return [
      asciiSafe(c.label),
      `${spec.internalLengthMm}x${spec.internalWidthMm}x${spec.internalHeightMm}`,
      String(stats.totalCartons),
      String(stats.layerCount),
      `${stats.volumeUtilizationPct.toFixed(1)}% (${stats.usedVolumeM3.toFixed(2)} m3)`,
      `${stats.totalCargoWeightKg.toFixed(0)} / ${spec.maxPayloadKg} kg (${stats.payloadUtilizationPct.toFixed(1)}%)`,
      stats.cogBalanceOk ? 'Cân bằng' : 'Xem trọng tâm',
    ];
  });

  autoTable(doc, {
    startY: options?.snapshotDataUrl ? 26 : nextY,
    margin: options?.snapshotDataUrl ? { left: 150 } : { left: 14 },
    head: [
      [
        'Cont',
        'Lòng cont mm',
        'Số thùng',
        'Số lớp',
        'Độ đầy',
        'Tải trọng',
        'Trọng tâm',
      ],
    ],
    body: contRows,
    styles: { font: PDF_FONT, fontSize: 8, cellPadding: 2 },
    headStyles: { fillColor: [15, 23, 42], textColor: 255 },
  });

  const afterTopY = Math.max(
    nextY,
    ((doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable
      ?.finalY ?? nextY) + 8
  );

  // SKU Quantity Reconciliation Table
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('Đối soát số lượng (Yêu cầu = Đã xếp + Còn lại)', 14, afterTopY);

  autoTable(doc, {
    startY: afterTopY + 3,
    head: [
      [
        'Mã nhà máy',
        'Mã khách',
        'Thùng DxRxC (mm)',
        'Yêu cầu',
        ...project.containers.map((c) => `C#${c.sequenceNumber}`),
        'Đã xếp',
        'Còn lại',
        'Trạng thái',
      ],
    ],
    body: recon.rows.map((r) => [
      asciiSafe(r.factorySku),
      asciiSafe(r.customerSku),
      r.dimensionsLabel,
      String(r.requiredQty),
      ...project.containers.map((c) => String(r.perContainerQty[c.id] ?? 0)),
      String(r.totalLoadedQty),
      String(r.remainingQty),
      ({ complete: 'ĐỦ', partial: 'THIẾU', unloaded: 'CHƯA XẾP', overallocated: 'VƯỢT' } as Record<string, string>)[r.status] ?? r.status,
    ]),
    styles: { font: PDF_FONT, fontSize: 8, cellPadding: 2 },
    headStyles: { fillColor: [29, 78, 216], textColor: 255 },
  });

  // Subsequent pages: Layer-by-layer instructions per container
  for (const container of targetContainers) {
    doc.addPage();
    const spec = specsById.get(container.containerSpecId)!;
    const stats = computeContainerStats(container, spec, skuMap);

    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text(
      asciiSafe(`${container.label} - Thứ tự xếp theo lớp`),
      14,
      16
    );
    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105);
    doc.text(
      `Số thùng: ${stats.totalCartons}  | Số lớp: ${stats.layerCount}  | Độ đầy: ${stats.volumeUtilizationPct.toFixed(1)}% | Kg: ${stats.totalCargoWeightKg.toFixed(1)} kg`,
      14,
      22
    );

    const sorted = [...container.placements].sort(
      (a, b) => a.layerIndex - b.layerIndex || a.xMm - b.xMm || a.zMm - b.zMm
    );

    autoTable(doc, {
      startY: 26,
      head: [
        [
          '#',
          'Lớp',
          'Mã nhà máy',
          'Mã khách',
          'Vị trí X/Y/Z (mm)',
          'Đặt DxCxR (mm)',
          'Hướng đặt',
          'Canh',
          'Kg',
        ],
      ],
      body: sorted.map((p, idx) => {
        const sku = skuMap.get(p.skuId);
        return [
          String(idx + 1),
          `L${p.layerIndex + 1}`,
          asciiSafe(sku?.factorySku ?? p.skuId),
          asciiSafe(sku?.customerSku ?? ''),
          `${Math.round(p.xMm)}, ${Math.round(p.yMm)}, ${Math.round(p.zMm)}`,
          `${Math.round(p.dimXMm)}x${Math.round(p.dimYMm)}x${Math.round(p.dimZMm)}`,
          p.rotationLabel,
          p.anchorMode === 'right' ? 'Sát phải' : 'Sát trái',
          String(sku?.weightKg ?? 0),
        ];
      }),
      styles: { font: PDF_FONT, fontSize: 7.5, cellPadding: 1.8 },
      headStyles: { fillColor: [15, 23, 42], textColor: 255 },
    });
  }

  const filename = options?.containerFilterId
    ? `${project.code}_${targetContainers[0]?.label.replace(/[^a-zA-Z0-9]/g, '_')}_KeHoachXep_CLOSbyVincent.pdf`
    : `${project.code}_KeHoachXep_TatCaCont_CLOSbyVincent.pdf`;

  doc.save(filename);
}

/**
 * Export a visual "Load Plan Details + 3D Step-By-Step Load Plan" PDF
 * modeled directly after standard warehouse step-by-step loading & QA inspection sheets:
 *  - Cover sheet per container with Top-Down Plan + Dual 3D Isometric views,
 *    metrics summary, and color-coded SKU manifest with inspection checkboxes.
 *  - 4 steps per page showing cutaway 3D progress (prior cargo in white, active step
 *    in SKU color) + SKU Part #, Qty with [ ] checkbox, Size (cm), Layer, & Description.
 */
export function exportStepByStepPdf(
  project: LoadingProject,
  specsById: Map<string, ContainerSpec>,
  options?: {
    containerFilterId?: string;
  }
) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  registerVietFont(doc);
  const skuMap = new Map<string, CargoSku>(project.skus.map((s) => [s.id, s]));
  const recon = reconcileProjectQuantities(project.skus, project.containers);

  const targetContainers: ContainerLoad[] = options?.containerFilterId
    ? project.containers.filter((c) => c.id === options.containerFilterId)
    : project.containers;

  const dateStr = new Date().toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' });
  const nf = (n: number) => Math.round(n).toLocaleString('vi-VN');

  const totalRequiredFleet = project.skus.reduce((s, k) => s + k.requiredQty, 0);
  const totalLoadedFleet = recon.rows.reduce((s, r) => s + r.totalLoadedQty, 0);
  const totalRemainingFleet = recon.rows.reduce((s, r) => s + r.remainingQty, 0);

  targetContainers.forEach((container, contIdx) => {
    if (contIdx > 0) doc.addPage();
    const spec =
      specsById.get(container.containerSpecId) ??
      Array.from(specsById.values())[0];
    const stats = computeContainerStats(container, spec, skuMap);

    // ================= PAGE 1 OF CONTAINER: LOAD PLAN DETAILS =================
    doc.setFont(PDF_FONT, 'bold');
    doc.setFontSize(17);
    doc.setTextColor(15, 23, 42);
    doc.text('Chi tiết kế hoạch xếp', 12, 15);
    const titleW = doc.getTextWidth('Chi tiết kế hoạch xếp');

    doc.setFont(PDF_FONT, 'normal');
    doc.setFontSize(9);
    doc.setTextColor(51, 65, 85);
    doc.text(`Ngày ${dateStr}`, 12 + titleW + 4, 15);

    // Thương hiệu canh phải, đo bề rộng thật để không dính chữ
    doc.setFont(PDF_FONT, 'bold');
    doc.setFontSize(11);
    const brandW = doc.getTextWidth('CLOS by Vincent');
    doc.setTextColor(29, 78, 216);
    doc.text('CLOS by Vincent', 198 - brandW, 14);
    doc.setFontSize(8);
    doc.setFont(PDF_FONT, 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('Thực hiện bởi', 198 - brandW - 2 - doc.getTextWidth('Thực hiện bởi'), 14);

    doc.setFont(PDF_FONT, 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(15, 23, 42);
    doc.text(
      asciiSafe(
        `Cont: # ${container.sequenceNumber}   Mô tả: ${spec.name} (${container.label})`
      ),
      12,
      21
    );
    doc.setFont(PDF_FONT, 'normal');
    doc.setTextColor(71, 85, 105);
    doc.text(
      fitText(
        doc,
        asciiSafe(
          `Dự án: ${project.code} - ${project.name}  | Khách: ${project.customerName}  | Cảng: ${project.destinationPort}`
        ),
        186
      ),
      12,
      25.5
    );

    // 3 Visual Views: Top-Down Plan | Isometric Front-Left | Isometric Opposite
    try {
      const topDownImg = renderTopDownPlanDataUrl({
        spec,
        placements: container.placements,
        skuMap,
      });
      const isoLeftImg = renderContainerIsometricDataUrl({
        spec,
        priorPlacements: [],
        activePlacements: container.placements,
        skuMap,
        angle: 'iso_front_left',
        widthPx: 680,
        heightPx: 420,
      });
      const isoRightImg = renderContainerIsometricDataUrl({
        spec,
        priorPlacements: [],
        activePlacements: container.placements,
        skuMap,
        angle: 'iso_front_right',
        widthPx: 680,
        heightPx: 420,
      });

      doc.addImage(topDownImg, 'PNG', 12, 29, 24, 70);
      doc.addImage(isoLeftImg, 'PNG', 40, 32, 76, 56);
      doc.addImage(isoRightImg, 'PNG', 120, 32, 78, 56);

      doc.setFont(PDF_FONT, 'normal');
      doc.setFontSize(7);
      doc.setTextColor(100, 116, 139);
      doc.text('Hình 3D: trước-trái (cửa -> trong)', 55, 92);
      doc.text('Hình 3D: góc chéo đối diện', 137, 92);
    } catch {
      // Fallback safely if offscreen canvas unavailable
    }

    // Metrics Summary Grid (matching CargoWiz layout in cm & m3 & kg)
    const maxUsedXMm =
      container.placements.length > 0
        ? Math.max(...container.placements.map((p) => p.xMm + p.dimXMm))
        : 0;
    const maxUsedYMm =
      container.placements.length > 0
        ? Math.max(...container.placements.map((p) => p.yMm + p.dimYMm))
        : 0;
    const maxUsedZMm =
      container.placements.length > 0
        ? Math.max(...container.placements.map((p) => p.zMm + p.dimZMm))
        : 0;

    // Bảng chỉ số (mọi kích thước tính bằng mm; thể tích m³, trọng lượng kg)
    const L = spec.internalLengthMm, W = spec.internalWidthMm, H = spec.internalHeightMm;
    const metricsY = 102;
    const metricRows: Array<[string, string, string, string]> = [
      ['Kích thước cont (mm):', `Dài: ${nf(L)}`, `Rộng: ${nf(W)}`, `Cao: ${nf(H)}`],
      ['Số lượng hàng:', `Tổng đơn: ${totalRequiredFleet}`, `Cont này: ${stats.totalCartons} · tất cả cont: ${totalLoadedFleet}`, `Chưa xếp: ${totalRemainingFleet}`],
      ['Chiều dài (mm):', `Đã dùng: ${nf(maxUsedXMm)}`, `Còn trống: ${nf(Math.max(0, L - maxUsedXMm))}`, `Tỷ lệ dùng: ${L ? ((maxUsedXMm / L) * 100).toFixed(1) : '0'}%`],
      ['Thể tích (m³):', `Thể tích cont: ${stats.totalVolumeM3.toFixed(2)}`, `Đã dùng: ${stats.usedVolumeM3.toFixed(2)}`, `Còn trống: ${Math.max(0, stats.totalVolumeM3 - stats.usedVolumeM3).toFixed(2)}`],
      ['Trọng lượng (kg):', `Tải tối đa: ${nf(spec.maxPayloadKg)}`, `Đã xếp: ${stats.totalCargoWeightKg.toFixed(1)}`, `Tải còn lại: ${Math.max(0, spec.maxPayloadKg - stats.totalCargoWeightKg).toFixed(1)}`],
      ['Hiệu suất xếp:', `Độ đầy cont: ${stats.volumeUtilizationPct.toFixed(1)}%`, `Khối hàng (mm): ${nf(maxUsedXMm)} × ${nf(maxUsedZMm)} × ${nf(maxUsedYMm)}`, ''],
      ['Trọng tâm:', `Cách vách trong: ${nf(stats.cogXMm)} mm`, `Lệch ngang: ${stats.cogLateralOffsetPct.toFixed(1)}%`, stats.cogBalanceOk ? 'Cân bằng: ĐẠT' : 'Cân bằng: cần xem'],
    ];

    // cột: nhãn 12–50 | c1 50–96 | c2 96–156 | c3 156–198; chữ dài tự cắt cho vừa cột
    const cols: Array<[number, number]> = [[50, 44], [96, 58], [156, 42]];
    doc.setFontSize(8);
    metricRows.forEach(([label, c1, c2, c3], idx) => {
      const y = metricsY + idx * 4.4;
      doc.setFont(PDF_FONT, 'bold');
      doc.setTextColor(15, 23, 42);
      doc.text(fitText(doc, label, 37), 12, y);
      doc.setFont(PDF_FONT, 'normal');
      doc.setTextColor(30, 41, 59);
      [c1, c2, c3].forEach((t, i) => {
        // ô cuối trống thì cho ô giữa dùng luôn chỗ của nó
        const w = i === 1 && !c3 ? cols[1][1] + cols[2][1] : cols[i][1];
        if (t) doc.text(fitText(doc, t, w), cols[i][0], y);
      });
    });

    const afterMetricsY = metricsY + metricRows.length * 4.4 + 2.5;
    doc.setFont(PDF_FONT, 'italic');
    doc.setFontSize(7.8);
    doc.setTextColor(71, 85, 105);
    doc.text(
      'Hướng xếp: từ trong ra ngoài (vách trong X = 0 mm -> cửa cont). Kiểm từng mã & số lượng khi đóng hàng.',
      12,
      afterMetricsY
    );

    // Per-container SKU Manifest Table with Color Swatch + Check Box
    const qtyBySku = new Map<string, number>();
    for (const p of container.placements) {
      qtyBySku.set(p.skuId, (qtyBySku.get(p.skuId) ?? 0) + 1);
    }

    const skuManifestRows = Array.from(qtyBySku.entries()).map(([skuId, qty]) => {
      const sku = skuMap.get(skuId);
      return {
        skuId,
        color: sku?.color ?? '#3B82F6',
        factorySku: asciiSafe(sku?.factorySku ?? skuId),
        qty,
        description: asciiSafe(
          sku?.description
            ? `${sku.customerSku ? `${sku.customerSku} - ` : ''}${sku.description}`
            : sku?.customerSku ?? ''
        ),
        lCm: sku ? nf(sku.lengthMm) : '-',
        wCm: sku ? nf(sku.widthMm) : '-',
        hCm: sku ? nf(sku.heightMm) : '-',
        wtKg: sku ? (sku.weightKg * qty).toFixed(1) : '0',
      };
    });

    autoTable(doc, {
      startY: afterMetricsY + 4,
      margin: { left: 12, right: 12 },
      head: [
        [
          '',
          'Mã hàng',
          'SL',
          'Kiểm',
          'Mô tả / Mã khách',
          'Dài (mm)',
          'Rộng (mm)',
          'Cao (mm)',
          'Tổng kg',
        ],
      ],
      body: skuManifestRows.map((r) => [
        '',
        r.factorySku,
        String(r.qty),
        '',
        r.description,
        r.lCm,
        r.wCm,
        r.hCm,
        r.wtKg,
      ]),
      styles: {
        font: PDF_FONT,
        fontSize: 8,
        cellPadding: 1.6,
        textColor: [15, 23, 42],
        lineColor: [203, 213, 225],
        lineWidth: 0.2,
      },
      headStyles: {
        fillColor: [248, 250, 252],
        textColor: [15, 23, 42],
        fontStyle: 'bolditalic',
      },
      columnStyles: {
        // tổng 186 mm = bề rộng trang trừ 2 lề
        0: { cellWidth: 9 },
        1: { cellWidth: 38, fontStyle: 'bold' },
        2: { cellWidth: 11, halign: 'right' },
        3: { cellWidth: 11, halign: 'center' },
        4: { cellWidth: 52 },
        5: { cellWidth: 16, halign: 'right' },
        6: { cellWidth: 16, halign: 'right' },
        7: { cellWidth: 16, halign: 'right' },
        8: { cellWidth: 17, halign: 'right' },
      },
      didDrawCell: (data) => {
        if (data.section === 'body') {
          const row = skuManifestRows[data.row.index];
          if (!row) return;
          if (data.column.index === 0) {
            const [r, g, b] = parseHexRgb(row.color);
            doc.setFillColor(r, g, b);
            doc.setDrawColor(30, 41, 59);
            doc.setLineWidth(0.25);
            doc.rect(
              data.cell.x + 1.5,
              data.cell.y + 1.4,
              6,
              Math.max(3, data.cell.height - 2.8),
              'FD'
            );
          } else if (data.column.index === 3) {
            doc.setDrawColor(51, 65, 85);
            doc.setLineWidth(0.25);
            const boxSize = 3.2;
            doc.rect(
              data.cell.x + (data.cell.width - boxSize) / 2,
              data.cell.y + (data.cell.height - boxSize) / 2,
              boxSize,
              boxSize,
              'S'
            );
          }
        }
      },
    });

    // ================= PAGES 2..N OF CONTAINER: 3D STEP-BY-STEP LOAD PLAN =================
    const stepGroups = buildInsideToOutsideStepGroups(container, spec, skuMap);
    const stepsPerPage = 4;

    if (stepGroups.length === 0) {
      doc.addPage();
      doc.setFont(PDF_FONT, 'bolditalic');
      doc.setFontSize(15);
      doc.setTextColor(15, 23, 42);
      doc.text('Xếp từng bước 3D', 12, 15);
      doc.setFont(PDF_FONT, 'normal');
      doc.setFontSize(10);
      doc.text('Cont này chưa có thùng nào.', 12, 30);
    }

    for (let sIdx = 0; sIdx < stepGroups.length; sIdx += stepsPerPage) {
      doc.addPage();
      const pageSteps = stepGroups.slice(sIdx, sIdx + stepsPerPage);

      // Step Page Header
      doc.setFont(PDF_FONT, 'bolditalic');
      doc.setFontSize(16);
      doc.setTextColor(15, 23, 42);
      doc.text('Xếp từng bước 3D', 12, 14);

      doc.setFont(PDF_FONT, 'normal');
      doc.setFontSize(9);
      doc.setTextColor(51, 65, 85);
      doc.text(
        fitText(doc, asciiSafe(`Cont #${container.sequenceNumber} – ${spec.name} · ${spec.code} · Dự án ${project.code}`), 186),
        12,
        19.5
      );

      // chú thích canh phải, cùng dòng tiêu đề
      doc.setFontSize(7.6);
      doc.setTextColor(100, 116, 139);
      const legend = 'Trong (vách) -> Ngoài (cửa) · Trắng = đã xếp · Màu = bước hiện tại';
      doc.text(legend, 198 - doc.getTextWidth(legend), 14);

      // Blue top rule
      doc.setDrawColor(37, 99, 235);
      doc.setLineWidth(0.45);
      doc.line(12, 22, 198, 22);

      const bandHeight = 62;
      pageSteps.forEach((step, slotIdx) => {
        const bandTop = 24 + slotIdx * bandHeight;

        // Step Title & Bay Telemetry
        doc.setFont(PDF_FONT, 'bold');
        doc.setFontSize(9.5);
        doc.setTextColor(15, 23, 42);
        doc.text(`Bước ${step.stepNumber}`, 12, bandTop + 4);

        doc.setFont(PDF_FONT, 'normal');
        doc.setFontSize(7.4);
        doc.setTextColor(71, 85, 105);
        doc.text(
          fitText(
            doc,
            `Sâu X: ${nf(step.minXMm)}–${nf(step.maxXMm)} mm · ${step.layerRangeLabel} · +${step.totalStepCartons} thùng (${step.stepWeightKg.toFixed(1)} kg) · Cộng dồn: ${step.cumulativeWeightKg.toFixed(1)} kg`,
            118
          ),
          80,
          bandTop + 3.8
        );

        // Left: 3D Cutaway Isometric Diagram (Prior in white, Current Step in SKU colors)
        try {
          const stepImg = renderContainerIsometricDataUrl({
            spec,
            priorPlacements: step.priorPlacements,
            activePlacements: step.activePlacements,
            skuMap,
            angle: 'iso_front_left',
            widthPx: 640,
            heightPx: 380,
          });
          doc.addImage(stepImg, 'PNG', 12, bandTop + 5.5, 64, 42);
        } catch {
          // Ignore image errors safely
        }

        if (step.isFinalStep) {
          doc.setFont(PDF_FONT, 'bolditalic');
          doc.setFontSize(8.5);
          doc.setTextColor(29, 78, 216);
          doc.text('Bước cuối', 12, bandTop + 52);
        }

        // Right: Step Inspection Table
        const tblX = 80;
        const tblY = bandTop + 6;
        doc.setFont(PDF_FONT, 'bolditalic');
        doc.setFontSize(7.8);
        doc.setTextColor(15, 23, 42);
        // cột: màu 80 | mã 88.5 (28) | SL 117.5 | D×R×C 131 (28) | lớp 160 (10) | mô tả 171 (27)
        doc.text('Mã hàng', tblX + 8.5, tblY + 3);
        doc.text('SL', tblX + 45.5, tblY + 3);
        doc.text('D×R×C (mm)', tblX + 54, tblY + 3);
        doc.text('Lớp', tblX + 80.5, tblY + 3);
        doc.text('Mô tả / Mã khách', tblX + 91, tblY + 3);

        doc.setDrawColor(203, 213, 225);
        doc.setLineWidth(0.2);
        doc.line(tblX, tblY + 4.4, 198, tblY + 4.4);

        const maxVisibleRows = 6;
        const shownSkus = step.skuSummaries.slice(0, maxVisibleRows);
        shownSkus.forEach((s, rIdx) => {
          const rowY = tblY + 6 + rIdx * 6.8;

          // Swatch
          const [r, g, b] = parseHexRgb(s.color);
          doc.setFillColor(r, g, b);
          doc.setDrawColor(15, 23, 42);
          doc.setLineWidth(0.22);
          doc.rect(tblX, rowY, 6.8, 3.8, 'FD');

          // Part #
          doc.setFont(PDF_FONT, 'bolditalic');
          doc.setFontSize(7.8);
          doc.setTextColor(15, 23, 42);
          doc.text(fitText(doc, asciiSafe(s.factorySku), 33), tblX + 8.5, rowY + 3);

          // Printable Checkbox + Qty
          doc.setDrawColor(51, 65, 85);
          doc.setLineWidth(0.25);
          doc.rect(tblX + 42, rowY + 0.3, 3.2, 3.2, 'S');
          doc.setFont(PDF_FONT, 'bold');
          doc.setFontSize(8);
          doc.text(String(s.qty), tblX + 46, rowY + 3);

          // Size (cm)
          doc.setFont(PDF_FONT, 'italic');
          doc.setFontSize(7.6);
          doc.text(
            fitText(doc, `${nf(s.lengthMm)} × ${nf(s.widthMm)} × ${nf(s.heightMm)}`, 26),
            tblX + 54,
            rowY + 3
          );

          // Layer
          doc.setFont(PDF_FONT, 'normal');
          doc.text(fitText(doc, s.layerLabel, 10), tblX + 80.5, rowY + 3);

          // Description
          doc.setFont(PDF_FONT, 'italic');
          doc.text(fitText(doc, asciiSafe(s.description), 27), tblX + 91, rowY + 3);
        });

        if (step.skuSummaries.length > maxVisibleRows) {
          const extraCount = step.skuSummaries.length - maxVisibleRows;
          doc.setFont(PDF_FONT, 'italic');
          doc.setFontSize(7.2);
          doc.setTextColor(100, 116, 139);
          doc.text(
            `+ ${extraCount} mã khác trong vùng này`,
            tblX + 8.5,
            tblY + 6 + maxVisibleRows * 6.8 + 2
          );
        }

        // Band divider line
        const dividerY = bandTop + bandHeight - 3;
        doc.setDrawColor(37, 99, 235);
        doc.setLineWidth(0.35);
        doc.line(12, dividerY, 198, dividerY);
      });

      // Step Page Footer Branding
      doc.setFont(PDF_FONT, 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(100, 116, 139);
      doc.setFont(PDF_FONT, 'normal');
      doc.text('Thực hiện bởi', 12, 289);
      let fx = 12 + doc.getTextWidth('Thực hiện bởi') + 1.5;
      doc.setFont(PDF_FONT, 'bold');
      doc.setTextColor(29, 78, 216);
      doc.setFontSize(9.5);
      doc.text('CLOS by Vincent', fx, 289);
      fx += doc.getTextWidth('CLOS by Vincent') + 3;
      doc.setFont(PDF_FONT, 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(100, 116, 139);
      doc.text('· Kế hoạch xếp từng bước & kiểm tra · đơn vị kích thước: mm', fx, 289);
    }
  });

  // Stamp consistent Page X of Y on bottom-right of every page
  const pageCount = doc.getNumberOfPages();
  for (let p = 1; p <= pageCount; p++) {
    doc.setPage(p);
    doc.setFont(PDF_FONT, 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text(`Trang ${p} / ${pageCount}`, 182, 289);
  }

  const filename = options?.containerFilterId
    ? `${project.code}_${targetContainers[0]?.label.replace(/[^a-zA-Z0-9]/g, '_')}_XepTungBuoc_CLOSbyVincent.pdf`
    : `${project.code}_XepTungBuoc3D_TatCaCont_CLOSbyVincent.pdf`;

  doc.save(filename);
}

