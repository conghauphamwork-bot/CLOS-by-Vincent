import {
  AnchorMode,
  BenchmarkTrialRow,
  CargoSku,
  ContainerLoad,
  ContainerSpec,
  OptimizationAlgorithm,
  OptimizationConfig,
  OptimizationMetrics,
  PlacedCarton,
  RecalculationPreview,
} from '../types/clos';
import {
  computeContainerStats,
  computeLayerIndex,
} from './reconciliation';
import {
  boxesOverlap3D,
  computeSupportRatio,
  getPermittedOrientations,
  OrientationCandidate,
  validateProject,
} from './validator';

interface CartonItem {
  instanceId: string;
  sku: CargoSku;
  volumeMm3: number;
}

interface CandidatePoint {
  x: number;
  y: number;
  z: number;
}

interface MaximalSpace {
  x: number;
  y: number;
  z: number;
  dx: number;
  dy: number;
  dz: number;
}

const EPS = 0.5;

function createSeededRng(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function expandItems(
  skus: CargoSku[],
  remainingBySku?: Map<string, number>,
  idPrefix = 'ctn'
): CartonItem[] {
  const items: CartonItem[] = [];
  let seq = 1;
  for (const sku of skus) {
    const qty = remainingBySku ? (remainingBySku.get(sku.id) ?? 0) : sku.requiredQty;
    for (let i = 0; i < qty; i++) {
      items.push({
        instanceId: `${idPrefix}-${sku.factorySku.replace(/[^a-zA-Z0-9]/g, '')}-${seq++}-${Math.random().toString(36).slice(2, 6)}`,
        sku,
        volumeMm3: sku.lengthMm * sku.widthMm * sku.heightMm,
      });
    }
  }
  return items;
}

function sortItemsDeterministic(items: CartonItem[], prioritizeHeavyBottom: boolean): CartonItem[] {
  return [...items].sort((a, b) => {
    // Non-stackable items placed later or on top/dedicated floor zones; heavy/large footprint first
    if (prioritizeHeavyBottom) {
      if (a.sku.fragile !== b.sku.fragile) return a.sku.fragile ? 1 : -1;
      if (a.sku.stackable !== b.sku.stackable) return a.sku.stackable ? -1 : 1;
    }
    const volDiff = b.volumeMm3 - a.volumeMm3;
    if (Math.abs(volDiff) > 1000) return volDiff;
    const weightDiff = b.sku.weightKg - a.sku.weightKg;
    if (Math.abs(weightDiff) > 0.1) return weightDiff;
    return a.sku.factorySku.localeCompare(b.sku.factorySku);
  });
}

function canPlaceCandidate(
  candidate: PlacedCarton,
  sku: CargoSku,
  existing: PlacedCarton[],
  currentWeightKg: number,
  spec: ContainerSpec,
  skuMap: Map<string, CargoSku>,
  config: OptimizationConfig
): { ok: boolean; supportRatio: number } {
  // 1. Boundary check
  if (
    candidate.xMm < -EPS ||
    candidate.yMm < -EPS ||
    candidate.zMm < -EPS ||
    candidate.xMm + candidate.dimXMm > spec.internalLengthMm + EPS ||
    candidate.yMm + candidate.dimYMm > spec.internalHeightMm + EPS ||
    candidate.zMm + candidate.dimZMm > spec.internalWidthMm + EPS
  ) {
    return { ok: false, supportRatio: 0 };
  }

  // 2. Payload check
  if (
    config.respectPayload &&
    currentWeightKg + sku.weightKg > spec.maxPayloadKg + EPS
  ) {
    return { ok: false, supportRatio: 0 };
  }

  // 3. Overlap check
  for (const other of existing) {
    if (boxesOverlap3D(candidate, other)) {
      return { ok: false, supportRatio: 0 };
    }
  }

  // 4. Support & Stacking check
  if (candidate.yMm <= EPS) {
    return { ok: true, supportRatio: 1 };
  }

  const { supportRatio, supportingCartons } = computeSupportRatio(
    candidate,
    existing
  );
  if (supportRatio + 1e-9 < config.minSupportRatio) {
    return { ok: false, supportRatio };
  }

  if (config.respectStacking) {
    for (const under of supportingCartons) {
      const underSku = skuMap.get(under.skuId);
      if (underSku) {
        if (!underSku.stackable) return { ok: false, supportRatio };
        if (under.layerIndex + 1 >= underSku.maxStackLayers) {
          return { ok: false, supportRatio };
        }
        if (underSku.fragile && sku.weightKg > underSku.weightKg * 0.85) {
          return { ok: false, supportRatio };
        }
      }
    }
  }

  return { ok: true, supportRatio };
}

function generateZCoordinates(
  zBase: number,
  dimZ: number,
  spec: ContainerSpec,
  anchorMode: AnchorMode
): number[] {
  if (anchorMode === 'right') {
    return [spec.internalWidthMm - zBase - dimZ, zBase];
  }
  if (anchorMode === 'center') {
    const centerLeft = Math.max(0, spec.internalWidthMm / 2 - dimZ / 2);
    return [centerLeft, zBase, spec.internalWidthMm - zBase - dimZ];
  }
  return [zBase];
}

function getExtremePointsForContainer(
  placements: PlacedCarton[],
  spec: ContainerSpec,
  anchorMode: AnchorMode
): CandidatePoint[] {
  const pts: CandidatePoint[] = [];
  if (anchorMode === 'right') {
    pts.push({ x: 0, y: 0, z: spec.internalWidthMm });
  } else if (anchorMode === 'center') {
    pts.push({ x: 0, y: 0, z: spec.internalWidthMm / 2 });
    pts.push({ x: 0, y: 0, z: 0 });
  } else {
    pts.push({ x: 0, y: 0, z: 0 });
  }

  for (const p of placements) {
    // Along X (front of carton)
    pts.push({ x: p.xMm + p.dimXMm, y: p.yMm, z: p.zMm });
    // Along Y (on top of carton)
    pts.push({ x: p.xMm, y: p.yMm + p.dimYMm, z: p.zMm });
    // Along Z (beside carton)
    if (anchorMode === 'right') {
      pts.push({ x: p.xMm, y: p.yMm, z: p.zMm });
    } else {
      pts.push({ x: p.xMm, y: p.yMm, z: p.zMm + p.dimZMm });
    }
  }

  // Deduplicate & sort by loading sequence: Rear->Front (X), Floor->Top (Y), Anchor Z
  const seen = new Set<string>();
  const unique: CandidatePoint[] = [];
  for (const pt of pts) {
    if (
      pt.x < -EPS ||
      pt.y < -EPS ||
      pt.z < -EPS ||
      pt.x >= spec.internalLengthMm - EPS ||
      pt.y >= spec.internalHeightMm - EPS ||
      pt.z > spec.internalWidthMm + EPS
    ) {
      continue;
    }
    const key = `${Math.round(pt.x)}_${Math.round(pt.y)}_${Math.round(pt.z)}`;
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(pt);
    }
  }

  unique.sort((a, b) => {
    if (Math.abs(a.x - b.x) > 5) return a.x - b.x;
    if (Math.abs(a.y - b.y) > 5) return a.y - b.y;
    if (anchorMode === 'right') return b.z - a.z;
    if (anchorMode === 'center') {
      const mid = spec.internalWidthMm / 2;
      return Math.abs(a.z - mid) - Math.abs(b.z - mid);
    }
    return a.z - b.z;
  });

  return unique;
}

function scorePlacement(
  candidate: PlacedCarton,
  spec: ContainerSpec,
  anchorMode: AnchorMode,
  algorithm: OptimizationAlgorithm,
  supportRatio: number
): number {
  const midZ = spec.internalWidthMm / 2;
  const centerZ = candidate.zMm + candidate.dimZMm / 2;
  const anchorPenalty =
    anchorMode === 'right'
      ? (spec.internalWidthMm - (candidate.zMm + candidate.dimZMm)) * 0.5
      : anchorMode === 'center'
        ? Math.abs(centerZ - midZ) * 0.8
        : candidate.zMm * 0.5;

  // Lower X (closer to rear bulkhead) + lower Y (closer to floor) + tighter fit
  const baseScore =
    candidate.xMm * 2.2 +
    candidate.yMm * 1.4 +
    anchorPenalty -
    supportRatio * 80;

  if (algorithm === 'bfd' || algorithm === 'maximal_spaces') {
    const wallGapZ = Math.min(
      candidate.zMm,
      spec.internalWidthMm - (candidate.zMm + candidate.dimZMm)
    );
    return baseScore + wallGapZ * 0.25;
  }
  return baseScore;
}

function tryPlaceWithExtremePoints(
  item: CartonItem,
  container: ContainerLoad,
  currentWeightKg: number,
  spec: ContainerSpec,
  skuMap: Map<string, CargoSku>,
  config: OptimizationConfig,
  algorithm: OptimizationAlgorithm
): PlacedCarton | null {
  const orientations = config.respectRotation
    ? getPermittedOrientations(item.sku)
    : getPermittedOrientations({ ...item.sku, rotationPolicy: 'all' });

  const pts = getExtremePointsForContainer(
    container.placements,
    spec,
    config.anchorMode
  );

  let best: PlacedCarton | null = null;
  let bestScore = Infinity;

  for (const pt of pts) {
    for (const orient of orientations) {
      const zAttempts =
        config.anchorMode === 'right'
          ? [pt.z - orient.dimZMm, pt.z]
          : config.anchorMode === 'center'
            ? [pt.z - orient.dimZMm / 2, pt.z, pt.z - orient.dimZMm]
            : [pt.z];

      for (const zPos of zAttempts) {
        if (zPos < -EPS || zPos + orient.dimZMm > spec.internalWidthMm + EPS) {
          continue;
        }
        const candidate: PlacedCarton = {
          instanceId: item.instanceId,
          skuId: item.sku.id,
          containerId: container.id,
          xMm: Math.max(0, pt.x),
          yMm: Math.max(0, pt.y),
          zMm: Math.max(0, zPos),
          dimXMm: orient.dimXMm,
          dimYMm: orient.dimYMm,
          dimZMm: orient.dimZMm,
          rotationLabel: orient.label,
          layerIndex: 0,
          anchorMode: config.anchorMode,
        };

        const check = canPlaceCandidate(
          candidate,
          item.sku,
          container.placements,
          currentWeightKg,
          spec,
          skuMap,
          config
        );

        if (check.ok) {
          candidate.layerIndex = computeLayerIndex(
            candidate,
            container.placements
          );
          const sc = scorePlacement(
            candidate,
            spec,
            config.anchorMode,
            algorithm,
            check.supportRatio
          );
          if (sc < bestScore) {
            bestScore = sc;
            best = candidate;
          }
          if (algorithm === 'ffd') {
            return best;
          }
        }
      }
    }
  }

  return best;
}

function packWithMaximalSpaces(
  items: CartonItem[],
  initialContainers: ContainerLoad[],
  specsById: Map<string, ContainerSpec>,
  defaultSpec: ContainerSpec,
  skuMap: Map<string, CargoSku>,
  config: OptimizationConfig
): ContainerLoad[] {
  const containers: ContainerLoad[] = initialContainers.map((c) => ({
    ...c,
    placements: [...c.placements],
  }));

  const spacesMap = new Map<string, MaximalSpace[]>();

  const initSpacesForContainer = (c: ContainerLoad, spec: ContainerSpec) => {
    if (c.placements.length === 0) {
      spacesMap.set(c.id, [
        {
          x: 0,
          y: 0,
          z: 0,
          dx: spec.internalLengthMm,
          dy: spec.internalHeightMm,
          dz: spec.internalWidthMm,
        },
      ]);
    } else {
      spacesMap.set(c.id, []);
    }
  };

  for (const c of containers) {
    const spec = specsById.get(c.containerSpecId) ?? defaultSpec;
    initSpacesForContainer(c, spec);
  }

  const getWeight = (c: ContainerLoad) =>
    c.placements.reduce((s, p) => s + (skuMap.get(p.skuId)?.weightKg ?? 0), 0);

  for (const item of items) {
    let placed = false;

    for (const c of containers) {
      if (c.locked) continue;
      const spec = specsById.get(c.containerSpecId) ?? defaultSpec;
      const w = getWeight(c);
      if (config.respectPayload && w + item.sku.weightKg > spec.maxPayloadKg + EPS) {
        continue;
      }

      const spaces = spacesMap.get(c.id) ?? [];
      const orientations = config.respectRotation
        ? getPermittedOrientations(item.sku)
        : getPermittedOrientations({ ...item.sku, rotationPolicy: 'all' });

      let bestChoice: {
        spaceIdx: number;
        orient: OrientationCandidate;
        zPos: number;
        waste: number;
      } | null = null;

      for (let idx = 0; idx < spaces.length; idx++) {
        const sp = spaces[idx];
        for (const o of orientations) {
          if (o.dimXMm <= sp.dx + EPS && o.dimYMm <= sp.dy + EPS && o.dimZMm <= sp.dz + EPS) {
            const zCand =
              config.anchorMode === 'right'
                ? sp.z + sp.dz - o.dimZMm
                : config.anchorMode === 'center'
                  ? sp.z + (sp.dz - o.dimZMm) / 2
                  : sp.z;

            const candidate: PlacedCarton = {
              instanceId: item.instanceId,
              skuId: item.sku.id,
              containerId: c.id,
              xMm: sp.x,
              yMm: sp.y,
              zMm: zCand,
              dimXMm: o.dimXMm,
              dimYMm: o.dimYMm,
              dimZMm: o.dimZMm,
              rotationLabel: o.label,
              layerIndex: 0,
              anchorMode: config.anchorMode,
            };

            const check = canPlaceCandidate(
              candidate,
              item.sku,
              c.placements,
              w,
              spec,
              skuMap,
              config
            );

            if (check.ok) {
              const waste =
                sp.dx * sp.dy * sp.dz - o.dimXMm * o.dimYMm * o.dimZMm + sp.x * 1e6;
              if (!bestChoice || waste < bestChoice.waste) {
                bestChoice = { spaceIdx: idx, orient: o, zPos: zCand, waste };
              }
            }
          }
        }
      }

      if (bestChoice) {
        const sp = spaces[bestChoice.spaceIdx];
        const o = bestChoice.orient;
        const placedBox: PlacedCarton = {
          instanceId: item.instanceId,
          skuId: item.sku.id,
          containerId: c.id,
          xMm: sp.x,
          yMm: sp.y,
          zMm: bestChoice.zPos,
          dimXMm: o.dimXMm,
          dimYMm: o.dimYMm,
          dimZMm: o.dimZMm,
          rotationLabel: o.label,
          layerIndex: 0,
          anchorMode: config.anchorMode,
        };
        placedBox.layerIndex = computeLayerIndex(placedBox, c.placements);
        c.placements.push(placedBox);

        // Guillotine-style maximal space splitting
        spaces.splice(bestChoice.spaceIdx, 1);
        const remX = sp.dx - o.dimXMm;
        const remY = sp.dy - o.dimYMm;
        const remZ = sp.dz - o.dimZMm;

        if (remY > 20) {
          spaces.push({
            x: sp.x,
            y: sp.y + o.dimYMm,
            z: bestChoice.zPos,
            dx: o.dimXMm,
            dy: remY,
            dz: o.dimZMm,
          });
        }
        if (remZ > 20) {
          const zStart =
            config.anchorMode === 'right' ? sp.z : sp.z + o.dimZMm;
          spaces.push({
            x: sp.x,
            y: sp.y,
            z: zStart,
            dx: o.dimXMm,
            dy: sp.dy,
            dz: remZ,
          });
        }
        if (remX > 20) {
          spaces.push({
            x: sp.x + o.dimXMm,
            y: sp.y,
            z: sp.z,
            dx: remX,
            dy: sp.dy,
            dz: sp.dz,
          });
        }

        spaces.sort((a, b) => a.x - b.x || a.y - b.y || a.z - b.z);
        placed = true;
        break;
      }

      // Fallback to Extreme Points if fragmented spaces missed a fit
      const epFit = tryPlaceWithExtremePoints(
        item,
        c,
        w,
        spec,
        skuMap,
        config,
        'extreme_points'
      );
      if (epFit) {
        c.placements.push(epFit);
        placed = true;
        break;
      }
    }

    if (!placed && config.autoAddContainers) {
      const nextNum = containers.length + 1;
      const newContainer: ContainerLoad = {
        id: `cnt-${Date.now().toString(36)}-${nextNum}`,
        containerSpecId: defaultSpec.id,
        label: `Cont #${nextNum} (${defaultSpec.code})`,
        sequenceNumber: nextNum,
        placements: [],
      };
      initSpacesForContainer(newContainer, defaultSpec);
      containers.push(newContainer);

      const spList = spacesMap.get(newContainer.id)!;
      const sp = spList[0];
      const orientations = config.respectRotation
        ? getPermittedOrientations(item.sku)
        : getPermittedOrientations({ ...item.sku, rotationPolicy: 'all' });
      const o = orientations.find(
        (cand) =>
          cand.dimXMm <= defaultSpec.internalLengthMm + EPS &&
          cand.dimYMm <= defaultSpec.internalHeightMm + EPS &&
          cand.dimZMm <= defaultSpec.internalWidthMm + EPS
      );
      if (o) {
        const zPos =
          config.anchorMode === 'right'
            ? defaultSpec.internalWidthMm - o.dimZMm
            : config.anchorMode === 'center'
              ? (defaultSpec.internalWidthMm - o.dimZMm) / 2
              : 0;
        newContainer.placements.push({
          instanceId: item.instanceId,
          skuId: item.sku.id,
          containerId: newContainer.id,
          xMm: 0,
          yMm: 0,
          zMm: zPos,
          dimXMm: o.dimXMm,
          dimYMm: o.dimYMm,
          dimZMm: o.dimZMm,
          rotationLabel: o.label,
          layerIndex: 0,
          anchorMode: config.anchorMode,
        });
        spList.splice(0, 1);
        if (sp.dy - o.dimYMm > 20) {
          spList.push({
            x: 0,
            y: o.dimYMm,
            z: zPos,
            dx: o.dimXMm,
            dy: sp.dy - o.dimYMm,
            dz: o.dimZMm,
          });
        }
        if (sp.dz - o.dimZMm > 20) {
          spList.push({
            x: 0,
            y: 0,
            z: config.anchorMode === 'right' ? 0 : o.dimZMm,
            dx: o.dimXMm,
            dy: sp.dy,
            dz: sp.dz - o.dimZMm,
          });
        }
        if (sp.dx - o.dimXMm > 20) {
          spList.push({
            x: o.dimXMm,
            y: 0,
            z: 0,
            dx: sp.dx - o.dimXMm,
            dy: sp.dy,
            dz: sp.dz,
          });
        }
      }
    }
  }

  return containers.filter((c) => c.placements.length > 0 || c.locked);
}

function packSequenceWithExtremePoints(
  items: CartonItem[],
  initialContainers: ContainerLoad[],
  specsById: Map<string, ContainerSpec>,
  defaultSpec: ContainerSpec,
  skuMap: Map<string, CargoSku>,
  config: OptimizationConfig,
  algorithm: OptimizationAlgorithm
): ContainerLoad[] {
  const containers: ContainerLoad[] = initialContainers.map((c) => ({
    ...c,
    placements: [...c.placements],
  }));

  if (containers.length === 0) {
    containers.push({
      id: `cnt-1-${Date.now().toString(36)}`,
      containerSpecId: defaultSpec.id,
      label: `Cont #1 (${defaultSpec.code})`,
      sequenceNumber: 1,
      placements: [],
    });
  }

  const getWeight = (c: ContainerLoad) =>
    c.placements.reduce((s, p) => s + (skuMap.get(p.skuId)?.weightKg ?? 0), 0);

  for (const item of items) {
    let placed = false;

    // For BFD: evaluate all open containers and pick the one leaving best fit / highest utilization
    if (algorithm === 'bfd') {
      let bestContainerIdx = -1;
      let bestCandidate: PlacedCarton | null = null;
      let bestResidual = Infinity;

      for (let idx = 0; idx < containers.length; idx++) {
        const c = containers[idx];
        if (c.locked) continue;
        const spec = specsById.get(c.containerSpecId) ?? defaultSpec;
        const w = getWeight(c);
        const cand = tryPlaceWithExtremePoints(
          item,
          c,
          w,
          spec,
          skuMap,
          config,
          algorithm
        );
        if (cand) {
          const usedVol = c.placements.reduce(
            (s, p) => s + p.dimXMm * p.dimYMm * p.dimZMm,
            0
          );
          const totalVol =
            spec.internalLengthMm * spec.internalWidthMm * spec.internalHeightMm;
          const residual = totalVol - usedVol - item.volumeMm3;
          if (residual < bestResidual) {
            bestResidual = residual;
            bestContainerIdx = idx;
            bestCandidate = cand;
          }
        }
      }

      if (bestContainerIdx >= 0 && bestCandidate) {
        bestCandidate.containerId = containers[bestContainerIdx].id;
        containers[bestContainerIdx].placements.push(bestCandidate);
        placed = true;
      }
    } else {
      for (const c of containers) {
        if (c.locked) continue;
        const spec = specsById.get(c.containerSpecId) ?? defaultSpec;
        const w = getWeight(c);
        const cand = tryPlaceWithExtremePoints(
          item,
          c,
          w,
          spec,
          skuMap,
          config,
          algorithm
        );
        if (cand) {
          c.placements.push(cand);
          placed = true;
          break;
        }
      }
    }

    if (!placed && config.autoAddContainers) {
      const nextNum = containers.length + 1;
      const newC: ContainerLoad = {
        id: `cnt-${nextNum}-${Math.random().toString(36).slice(2, 6)}`,
        containerSpecId: defaultSpec.id,
        label: `Cont #${nextNum} (${defaultSpec.code})`,
        sequenceNumber: nextNum,
        placements: [],
      };
      const cand = tryPlaceWithExtremePoints(
        item,
        newC,
        0,
        defaultSpec,
        skuMap,
        config,
        algorithm
      );
      if (cand) {
        cand.containerId = newC.id;
        newC.placements.push(cand);
        containers.push(newC);
      }
    }
  }

  return containers.filter((c) => c.placements.length > 0 || c.locked);
}

function computeLowerBoundContainers(
  skus: CargoSku[],
  defaultSpec: ContainerSpec
): number {
  const totalVolMm3 = skus.reduce(
    (s, k) => s + k.lengthMm * k.widthMm * k.heightMm * k.requiredQty,
    0
  );
  const totalWeightKg = skus.reduce((s, k) => s + k.weightKg * k.requiredQty, 0);
  const contVol =
    defaultSpec.internalLengthMm *
    defaultSpec.internalWidthMm *
    defaultSpec.internalHeightMm;
  const volLb = contVol > 0 ? Math.ceil(totalVolMm3 / contVol) : 1;
  const wtLb =
    defaultSpec.maxPayloadKg > 0
      ? Math.ceil(totalWeightKg / defaultSpec.maxPayloadKg)
      : 1;
  return Math.max(1, volLb, wtLb);
}

function evaluateSolutionScore(
  containers: ContainerLoad[],
  specsById: Map<string, ContainerSpec>,
  defaultSpec: ContainerSpec,
  skuMap: Map<string, CargoSku>,
  totalRequestedCartons: number
): {
  containersUsed: number;
  avgVolumePct: number;
  avgPayloadPct: number;
  placedCount: number;
  objective: number;
} {
  let placedCount = 0;
  let volSum = 0;
  let paySum = 0;
  for (const c of containers) {
    const spec = specsById.get(c.containerSpecId) ?? defaultSpec;
    const stats = computeContainerStats(c, spec, skuMap);
    placedCount += stats.totalCartons;
    volSum += stats.volumeUtilizationPct;
    paySum += stats.payloadUtilizationPct;
  }
  const n = Math.max(1, containers.length);
  const avgVolumePct = volSum / n;
  const avgPayloadPct = paySum / n;
  // Primary: place all cartons; Secondary: minimize container count; Tertiary: maximize utilization
  const unplacedPenalty = (totalRequestedCartons - placedCount) * 100000;
  const objective =
    unplacedPenalty + containers.length * 1000 - avgVolumePct * 5;
  return {
    containersUsed: containers.length,
    avgVolumePct,
    avgPayloadPct,
    placedCount,
    objective,
  };
}

export function runOptimization(
  skus: CargoSku[],
  existingContainers: ContainerLoad[],
  specs: ContainerSpec[],
  defaultSpecId: string,
  config: OptimizationConfig,
  options?: {
    preserveLockedOnly?: boolean;
    seed?: number;
    remainingOnly?: boolean;
  }
): {
  containers: ContainerLoad[];
  metrics: OptimizationMetrics;
} {
  const t0 = performance.now();
  const specsById = new Map(specs.map((s) => [s.id, s]));
  const defaultSpec =
    specsById.get(defaultSpecId) ?? specs[0];
  const skuMap = new Map(skus.map((s) => [s.id, s]));

  // Keep locked containers if requested
  const baseContainers = options?.preserveLockedOnly
    ? existingContainers.filter((c) => c.locked)
    : options?.remainingOnly
      ? existingContainers.map((c) => ({
          ...c,
          placements: [...c.placements],
        }))
      : [];

  // Compute remaining qty per SKU after baseContainers
  const allocatedBySku = new Map<string, number>();
  for (const c of baseContainers) {
    for (const p of c.placements) {
      allocatedBySku.set(p.skuId, (allocatedBySku.get(p.skuId) ?? 0) + 1);
    }
  }
  const remainingBySku = new Map<string, number>();
  for (const sku of skus) {
    remainingBySku.set(
      sku.id,
      Math.max(0, sku.requiredQty - (allocatedBySku.get(sku.id) ?? 0))
    );
  }

  const rawItems = expandItems(skus, remainingBySku);
  const sortedItems = sortItemsDeterministic(rawItems, config.prioritizeHeavyBottom);

  let finalContainers: ContainerLoad[];

  if (config.algorithm === 'maximal_spaces') {
    finalContainers = packWithMaximalSpaces(
      sortedItems,
      baseContainers,
      specsById,
      defaultSpec,
      skuMap,
      config
    );
  } else if (config.algorithm === 'hybrid_alns_ep') {
    // Run deterministic baseline + ALNS destroy-and-repair neighborhood trials
    let bestResult = packSequenceWithExtremePoints(
      sortedItems,
      baseContainers,
      specsById,
      defaultSpec,
      skuMap,
      config,
      'extreme_points'
    );
    let bestEval = evaluateSolutionScore(
      bestResult,
      specsById,
      defaultSpec,
      skuMap,
      sortedItems.length +
        baseContainers.reduce((s, c) => s + c.placements.length, 0)
    );

    const rng = createSeededRng(options?.seed ?? 4207);
    const trials = Math.max(3, Math.min(12, config.alnsIterations || 6));

    // Group items by SKU for block-level ALNS neighborhood swaps
    for (let t = 0; t < trials; t++) {
      const candidateOrder = [...sortedItems];
      // Destroy & repair: swap SKU group blocks or shuffle within volume bands
      if (t % 2 === 0 && candidateOrder.length > 4) {
        // Group-by-SKU permutation
        const groups = new Map<string, CartonItem[]>();
        for (const it of candidateOrder) {
          const list = groups.get(it.sku.id) ?? [];
          list.push(it);
          groups.set(it.sku.id, list);
        }
        const keys = Array.from(groups.keys());
        for (let i = keys.length - 1; i > 0; i--) {
          const j = Math.floor(rng() * (i + 1));
          [keys[i], keys[j]] = [keys[j], keys[i]];
        }
        candidateOrder.length = 0;
        for (const k of keys) {
          candidateOrder.push(...(groups.get(k) ?? []));
        }
      } else {
        // Local window perturbation preserving heavy-first bias
        for (let i = 0; i < candidateOrder.length; i++) {
          const span = Math.min(candidateOrder.length - 1, i + 4);
          const j = i + Math.floor(rng() * (span - i + 1));
          [candidateOrder[i], candidateOrder[j]] = [
            candidateOrder[j],
            candidateOrder[i],
          ];
        }
      }

      const trialContainers =
        t % 3 === 1
          ? packWithMaximalSpaces(
              candidateOrder,
              baseContainers,
              specsById,
              defaultSpec,
              skuMap,
              config
            )
          : packSequenceWithExtremePoints(
              candidateOrder,
              baseContainers,
              specsById,
              defaultSpec,
              skuMap,
              config,
              'extreme_points'
            );

      const totalReq =
        sortedItems.length +
        baseContainers.reduce((s, c) => s + c.placements.length, 0);
      const trialEval = evaluateSolutionScore(
        trialContainers,
        specsById,
        defaultSpec,
        skuMap,
        totalReq
      );

      if (trialEval.objective < bestEval.objective) {
        bestEval = trialEval;
        bestResult = trialContainers;
      }
    }

    finalContainers = bestResult;
  } else {
    finalContainers = packSequenceWithExtremePoints(
      sortedItems,
      baseContainers,
      specsById,
      defaultSpec,
      skuMap,
      config,
      config.algorithm
    );
  }

  // Re-number sequences cleanly
  finalContainers = finalContainers.map((c, idx) => {
    const spec = specsById.get(c.containerSpecId) ?? defaultSpec;
    return {
      ...c,
      sequenceNumber: idx + 1,
      label: `Cont #${idx + 1} (${spec.code})`,
    };
  });

  const issues = validateProject(finalContainers, specsById, skus, config);
  const errorCount = issues.filter((i) => i.severity === 'error').length;
  const totalReqAll = skus.reduce((s, k) => s + k.requiredQty, 0);
  const evalSummary = evaluateSolutionScore(
    finalContainers,
    specsById,
    defaultSpec,
    skuMap,
    totalReqAll
  );

  const lb = computeLowerBoundContainers(skus, defaultSpec);
  const gapPct =
    lb > 0 && evalSummary.containersUsed > 0
      ? Math.max(0, ((evalSummary.containersUsed - lb) / lb) * 100)
      : 0;

  const feasible = errorCount === 0 && evalSummary.placedCount === totalReqAll;
  const statusLabel: OptimizationMetrics['statusLabel'] = !feasible
    ? 'Infeasible'
    : evalSummary.containersUsed <= lb
      ? 'Proven Optimal (LB Match)'
      : config.algorithm === 'hybrid_alns_ep'
        ? 'Best-Known Solution'
        : 'Feasible Solution';

  const t1 = performance.now();

  const explanation = `${config.algorithm.toUpperCase().replace(/_/g, ' ')} đã xếp ${evalSummary.placedCount}/${totalReqAll} thùng vào ${evalSummary.containersUsed} cont, canh ${config.anchorMode}. Cận dưới là ${lb} cont (khoảng cách tối ưu ${gapPct.toFixed(1)}%). ${errorCount === 0 ? 'Mọi ràng buộc cứng đều đạt.' : `${errorCount} lỗi ràng buộc.`}`;

  return {
    containers: finalContainers,
    metrics: {
      algorithm: config.algorithm,
      containersUsed: evalSummary.containersUsed,
      volumeUtilizationPct: evalSummary.avgVolumePct,
      payloadUtilizationPct: evalSummary.avgPayloadPct,
      violationsCount: errorCount,
      computeTimeMs: Math.max(1, Math.round(t1 - t0)),
      feasible,
      lowerBoundContainers: lb,
      optimalityGapPct: gapPct,
      statusLabel,
      explanation,
    },
  };
}

export function buildRecalculationPreview(
  skus: CargoSku[],
  existingContainers: ContainerLoad[],
  specs: ContainerSpec[],
  defaultSpecId: string,
  config: OptimizationConfig
): RecalculationPreview {
  const skuMap = new Map(skus.map((s) => [s.id, s]));
  const specsById = new Map(specs.map((s) => [s.id, s]));

  const affectedIds = new Set<string>();
  const preservedIds = new Set<string>();
  const invalidatedCartons: RecalculationPreview['invalidatedCartons'] = [];

  // Track cumulative allocations to detect over-allocated SKUs after qty reduction
  const runningQty = new Map<string, number>();

  const cleanedContainers: ContainerLoad[] = existingContainers.map((c) => {
    const spec = specsById.get(c.containerSpecId) ?? specs[0];
    const validPlacements: PlacedCarton[] = [];
    let containerAffected = false;

    for (const p of c.placements) {
      const sku = skuMap.get(p.skuId);
      if (!sku) {
        containerAffected = true;
        invalidatedCartons.push({
          containerLabel: c.label,
          factorySku: p.skuId,
          reason: 'Mã hàng đã bị xoá',
        });
        continue;
      }

      const currentCount = runningQty.get(sku.id) ?? 0;
      if (currentCount + 1 > sku.requiredQty) {
        containerAffected = true;
        invalidatedCartons.push({
          containerLabel: c.label,
          factorySku: sku.factorySku,
          reason: `Số yêu cầu giảm còn ${sku.requiredQty}; bỏ thùng dư`,
        });
        continue;
      }

      // Check if carton dimensions match any valid orientation of current SKU
      const validOrient = getPermittedOrientations(sku).some(
        (o) =>
          Math.abs(o.dimXMm - p.dimXMm) <= EPS &&
          Math.abs(o.dimYMm - p.dimYMm) <= EPS &&
          Math.abs(o.dimZMm - p.dimZMm) <= EPS
      );

      if (!validOrient) {
        containerAffected = true;
        invalidatedCartons.push({
          containerLabel: c.label,
          factorySku: sku.factorySku,
          reason: `Kích thước mã (${sku.lengthMm}×${sku.widthMm}×${sku.heightMm}) hoặc mã xoay đã đổi`,
        });
        continue;
      }

      // Check bounds
      if (
        p.xMm + p.dimXMm > spec.internalLengthMm + EPS ||
        p.yMm + p.dimYMm > spec.internalHeightMm + EPS ||
        p.zMm + p.dimZMm > spec.internalWidthMm + EPS
      ) {
        containerAffected = true;
        invalidatedCartons.push({
          containerLabel: c.label,
          factorySku: sku.factorySku,
          reason: 'Thùng vượt lòng cont sau khi đổi thông số cont',
        });
        continue;
      }

      runningQty.set(sku.id, currentCount + 1);
      validPlacements.push(p);
    }

    if (containerAffected) {
      affectedIds.add(c.id);
    } else {
      preservedIds.add(c.id);
    }

    return {
      ...c,
      placements: validPlacements,
    };
  });

  // Pack remaining unallocated items into open space of cleanedContainers + new containers if needed
  const { containers: proposedContainers, metrics: proposedMetrics } =
    runOptimization(skus, cleanedContainers, specs, defaultSpecId, config, {
      remainingOnly: true,
    });

  // Check if new cartons were added to any previously clean container
  for (let i = 0; i < proposedContainers.length; i++) {
    const prop = proposedContainers[i];
    const orig = existingContainers.find((e) => e.id === prop.id);
    if (!orig || prop.placements.length !== orig.placements.length) {
      affectedIds.add(prop.id);
      preservedIds.delete(prop.id);
    }
  }

  return {
    affectedContainerIds: Array.from(affectedIds),
    preservedContainerIds: Array.from(preservedIds),
    invalidatedCartons,
    proposedContainers,
    proposedMetrics,
    summary:
      invalidatedCartons.length > 0
        ? `${invalidatedCartons.length} thùng không còn hợp lệ do sửa mã hàng; ${preservedIds.size} cont giữ nguyên.`
        : `Giữ mọi thùng còn hợp lệ; phần còn lại xếp vào chỗ trống.`,
  };
}

export function realignContainerAnchor(
  container: ContainerLoad,
  spec: ContainerSpec,
  anchor: 'left' | 'right' | 'center'
): ContainerLoad {
  if (container.placements.length === 0) return container;

  // Group by X-slices / rows or shift bounding group cleanly while preserving relative spacing
  const minZ = Math.min(...container.placements.map((p) => p.zMm));
  const maxZ = Math.max(...container.placements.map((p) => p.zMm + p.dimZMm));
  const spanZ = maxZ - minZ;

  let shiftZ = 0;
  if (anchor === 'left') {
    shiftZ = -minZ;
  } else if (anchor === 'right') {
    shiftZ = spec.internalWidthMm - maxZ;
  } else {
    shiftZ = (spec.internalWidthMm - spanZ) / 2 - minZ;
  }

  return {
    ...container,
    placements: container.placements.map((p) => ({
      ...p,
      zMm: Math.max(0, Math.min(spec.internalWidthMm - p.dimZMm, p.zMm + shiftZ)),
      anchorMode: anchor,
    })),
  };
}

export function runBenchmarkSuite(
  skus: CargoSku[],
  specs: ContainerSpec[],
  defaultSpecId: string,
  baseConfig: OptimizationConfig
): BenchmarkTrialRow[] {
  const results: BenchmarkTrialRow[] = [];

  const deterministicAlgos: Array<{
    id: OptimizationAlgorithm;
    name: string;
    category: string;
    notes: string;
  }> = [
    {
      id: 'ffd',
      name: 'First Fit Decreasing (FFD)',
      category: 'Greedy Baseline',
      notes: 'Fastest O(n log n) greedy constructive baseline; first valid extreme point.',
    },
    {
      id: 'bfd',
      name: 'Best Fit Decreasing (BFD)',
      category: 'Greedy Constructive',
      notes: 'Selects container with minimal residual volume; tighter multi-container consolidation.',
    },
    {
      id: 'extreme_points',
      name: 'Extreme Points (3D-EP)',
      category: 'Spatial Heuristic',
      notes: 'Maintains 3D corner anchor coordinates with base support area scoring.',
    },
    {
      id: 'maximal_spaces',
      name: 'Maximal Spaces (Guillotine)',
      category: 'Space Partitioning',
      notes: 'Tracks maximal empty cuboids; strong for uniform furniture flat-packs.',
    },
  ];

  for (const alg of deterministicAlgos) {
    const res = runOptimization(skus, [], specs, defaultSpecId, {
      ...baseConfig,
      algorithm: alg.id,
    });
    results.push({
      algorithmId: alg.id,
      algorithmName: alg.name,
      category: alg.category,
      containersUsed: res.metrics.containersUsed,
      avgVolumePct: res.metrics.volumeUtilizationPct,
      bestVolumePct: res.metrics.volumeUtilizationPct,
      worstVolumePct: res.metrics.volumeUtilizationPct,
      payloadPct: res.metrics.payloadUtilizationPct,
      violations: res.metrics.violationsCount,
      computeTimeMs: res.metrics.computeTimeMs,
      feasible: res.metrics.feasible,
      optimalityGapPct: res.metrics.optimalityGapPct,
      statusLabel: res.metrics.statusLabel,
      notes: alg.notes,
    });
  }

  // Hybrid ALNS + EP multi-trial evaluation (5 seeded trials)
  const seeds = [101, 202, 303, 404, 505];
  const trialVols: number[] = [];
  const trialTimes: number[] = [];
  let bestTrial = runOptimization(skus, [], specs, defaultSpecId, {
    ...baseConfig,
    algorithm: 'hybrid_alns_ep',
  }, { seed: seeds[0] });
  trialVols.push(bestTrial.metrics.volumeUtilizationPct);
  trialTimes.push(bestTrial.metrics.computeTimeMs);

  for (let i = 1; i < seeds.length; i++) {
    const tr = runOptimization(
      skus,
      [],
      specs,
      defaultSpecId,
      { ...baseConfig, algorithm: 'hybrid_alns_ep' },
      { seed: seeds[i] }
    );
    trialVols.push(tr.metrics.volumeUtilizationPct);
    trialTimes.push(tr.metrics.computeTimeMs);
    if (
      tr.metrics.containersUsed < bestTrial.metrics.containersUsed ||
      (tr.metrics.containersUsed === bestTrial.metrics.containersUsed &&
        tr.metrics.volumeUtilizationPct > bestTrial.metrics.volumeUtilizationPct)
    ) {
      bestTrial = tr;
    }
  }

  const avgVol = trialVols.reduce((a, b) => a + b, 0) / trialVols.length;
  const avgTime = Math.round(
    trialTimes.reduce((a, b) => a + b, 0) / trialTimes.length
  );

  results.push({
    algorithmId: 'hybrid_alns_ep',
    algorithmName: 'Hybrid ALNS + Extreme Points (5 Trials)',
    category: 'Metaheuristic + Exact Bounds',
    containersUsed: bestTrial.metrics.containersUsed,
    avgVolumePct: avgVol,
    bestVolumePct: Math.max(...trialVols),
    worstVolumePct: Math.min(...trialVols),
    payloadPct: bestTrial.metrics.payloadUtilizationPct,
    violations: bestTrial.metrics.violationsCount,
    computeTimeMs: avgTime,
    feasible: bestTrial.metrics.feasible,
    optimalityGapPct: bestTrial.metrics.optimalityGapPct,
    statusLabel: bestTrial.metrics.statusLabel,
    notes:
      'Destroy-and-repair SKU group ordering paired with Extreme Points & Lower Bound verification.',
  });

  // ĐÃ BỎ: dòng "CargoWiz Legacy Baseline" là số mô phỏng (FFD trừ 2,4%/4,1%), không phải CargoWiz thật.

  return results;
}
