import { policyToCode } from '../lib/rotation';
import {
  CargoSku,
  ContainerLoad,
  ContainerSpec,
  OptimizationConfig,
  PlacedCarton,
  ValidationIssue,
} from '../types/clos';
import { computeContainerStats } from './reconciliation';

const EPS = 0.5;

export interface OrientationCandidate {
  dimXMm: number;
  dimYMm: number;
  dimZMm: number;
  label: string;
}

export function getPermittedOrientations(sku: CargoSku): OrientationCandidate[] {
  const L = sku.lengthMm;
  const W = sku.widthMm;
  const H = sku.heightMm;

  const all: OrientationCandidate[] = [
    { dimXMm: L, dimYMm: H, dimZMm: W, label: 'D×C×R (chuẩn)' },
    { dimXMm: W, dimYMm: H, dimZMm: L, label: 'R×C×D (xoay ngang 90°)' },
    { dimXMm: L, dimYMm: W, dimZMm: H, label: 'D×R×C (nằm nghiêng)' },
    { dimXMm: W, dimYMm: L, dimZMm: H, label: 'R×D×C (nghiêng, xoay)' },
    { dimXMm: H, dimYMm: L, dimZMm: W, label: 'C×D×R (dựng Dài)' },
    { dimXMm: H, dimYMm: W, dimZMm: L, label: 'C×R×D (dựng Dài, xoay)' },
  ];

  let filtered: OrientationCandidate[];
  switch (sku.rotationPolicy) {
    case 'none':
      filtered = [all[0]];
      break;
    case 'upright_only':
    case 'length_width_only':
      filtered = [all[0], all[1]];
      break;
    case 'four_way':
      // CargoWiz 4: mọi hướng trừ dựng cạnh Dài (L) lên làm chiều cao
      filtered = [all[0], all[1], all[2], all[5]];
      break;
    case 'all':
    default:
      filtered = all;
      break;
  }

  // Deduplicate identical dimension triples
  const seen = new Set<string>();
  return filtered.filter((o) => {
    const key = `${o.dimXMm}x${o.dimYMm}x${o.dimZMm}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

export function boxesOverlap3D(a: PlacedCarton, b: PlacedCarton): boolean {
  const ox =
    a.xMm < b.xMm + b.dimXMm - EPS && a.xMm + a.dimXMm > b.xMm + EPS;
  const oy =
    a.yMm < b.yMm + b.dimYMm - EPS && a.yMm + a.dimYMm > b.yMm + EPS;
  const oz =
    a.zMm < b.zMm + b.dimZMm - EPS && a.zMm + a.dimZMm > b.zMm + EPS;
  return ox && oy && oz;
}

export function computeSupportRatio(
  carton: PlacedCarton,
  placements: PlacedCarton[]
): { supportRatio: number; supportingCartons: PlacedCarton[] } {
  if (carton.yMm <= EPS) {
    return { supportRatio: 1, supportingCartons: [] };
  }

  const baseArea = carton.dimXMm * carton.dimZMm;
  if (baseArea <= 0) return { supportRatio: 0, supportingCartons: [] };

  let supportedArea = 0;
  const supportingCartons: PlacedCarton[] = [];

  for (const other of placements) {
    if (other.instanceId === carton.instanceId) continue;
    const topY = other.yMm + other.dimYMm;
    if (Math.abs(topY - carton.yMm) > 2.0) continue;

    const overlapX = Math.max(
      0,
      Math.min(carton.xMm + carton.dimXMm, other.xMm + other.dimXMm) -
        Math.max(carton.xMm, other.xMm)
    );
    const overlapZ = Math.max(
      0,
      Math.min(carton.zMm + carton.dimZMm, other.zMm + other.dimZMm) -
        Math.max(carton.zMm, other.zMm)
    );

    if (overlapX > EPS && overlapZ > EPS) {
      supportedArea += overlapX * overlapZ;
      supportingCartons.push(other);
    }
  }

  return {
    supportRatio: Math.min(1, supportedArea / baseArea),
    supportingCartons,
  };
}

export function validateContainerLoad(
  container: ContainerLoad,
  spec: ContainerSpec,
  skuMap: Map<string, CargoSku>,
  config: OptimizationConfig
): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const placements = container.placements;

  // 1. Boundary & Rotation checks
  for (const c of placements) {
    const sku = skuMap.get(c.skuId);
    if (
      c.xMm < -EPS ||
      c.yMm < -EPS ||
      c.zMm < -EPS ||
      c.xMm + c.dimXMm > spec.internalLengthMm + EPS ||
      c.yMm + c.dimYMm > spec.internalHeightMm + EPS ||
      c.zMm + c.dimZMm > spec.internalWidthMm + EPS
    ) {
      issues.push({
        id: `bnd-${c.instanceId}`,
        severity: 'error',
        rule: 'boundary',
        containerId: container.id,
        containerLabel: container.label,
        cartonIds: [c.instanceId],
        message: `${sku?.factorySku ?? c.skuId} vượt ${spec.name} lòng cont (${Math.round(c.xMm + c.dimXMm)}/${spec.internalLengthMm}L, ${Math.round(c.yMm + c.dimYMm)}/${spec.internalHeightMm}H, ${Math.round(c.zMm + c.dimZMm)}/${spec.internalWidthMm}W).`,
      });
    }

    if (sku && config.respectRotation) {
      const permitted = getPermittedOrientations(sku);
      const validOrient = permitted.some(
        (o) =>
          Math.abs(o.dimXMm - c.dimXMm) <= EPS &&
          Math.abs(o.dimYMm - c.dimYMm) <= EPS &&
          Math.abs(o.dimZMm - c.dimZMm) <= EPS
      );
      if (!validOrient) {
        issues.push({
          id: `rot-${c.instanceId}`,
          severity: 'error',
          rule: 'rotation',
          containerId: container.id,
          containerLabel: container.label,
          cartonIds: [c.instanceId],
          message: `${sku.factorySku} sai luật xoay (mã ${policyToCode(sku.rotationPolicy)}).`,
        });
      }
    }
  }

  // 2. Overlap checks
  for (let i = 0; i < placements.length; i++) {
    for (let j = i + 1; j < placements.length; j++) {
      if (boxesOverlap3D(placements[i], placements[j])) {
        const skuA = skuMap.get(placements[i].skuId)?.factorySku ?? placements[i].skuId;
        const skuB = skuMap.get(placements[j].skuId)?.factorySku ?? placements[j].skuId;
        issues.push({
          id: `ovl-${placements[i].instanceId}-${placements[j].instanceId}`,
          severity: 'error',
          rule: 'overlap',
          containerId: container.id,
          containerLabel: container.label,
          cartonIds: [placements[i].instanceId, placements[j].instanceId],
          message: `Chồng lấn giữa ${skuA} và ${skuB}.`,
        });
      }
    }
  }

  // 3. Support, Stability, Stacking & Fragility checks
  for (const c of placements) {
    const sku = skuMap.get(c.skuId);
    const { supportRatio, supportingCartons } = computeSupportRatio(c, placements);

    if (c.yMm > EPS && supportRatio + 1e-9 < config.minSupportRatio) {
      issues.push({
        id: `sup-${c.instanceId}`,
        severity: 'error',
        rule: 'support_stability',
        containerId: container.id,
        containerLabel: container.label,
        cartonIds: [c.instanceId],
        message: `${sku?.factorySku ?? c.skuId} không được đỡ đủ (${Math.round(supportRatio * 100)}% < ${Math.round(config.minSupportRatio * 100)}% yêu cầu).`,
      });
    }

    if (config.respectStacking) {
      for (const under of supportingCartons) {
        const underSku = skuMap.get(under.skuId);
        if (underSku && !underSku.stackable) {
          issues.push({
            id: `stk-${under.instanceId}-${c.instanceId}`,
            severity: 'error',
            rule: 'stacking',
            containerId: container.id,
            containerLabel: container.label,
            cartonIds: [under.instanceId, c.instanceId],
            message: `${sku?.factorySku ?? c.skuId} đang đặt trên mã cấm chồng ${underSku.factorySku}.`,
          });
        }
        if (underSku && underSku.fragile && sku && sku.weightKg > underSku.weightKg * 0.8) {
          issues.push({
            id: `frg-${under.instanceId}-${c.instanceId}`,
            severity: 'warning',
            rule: 'accessibility',
            containerId: container.id,
            containerLabel: container.label,
            cartonIds: [under.instanceId, c.instanceId],
            message: `Thùng nặng ${sku.factorySku} (${sku.weightKg}kg) đè lên hàng dễ vỡ ${underSku.factorySku}.`,
          });
        }
      }
    }
  }

  // 4. Payload & CoG balance checks
  const stats = computeContainerStats(container, spec, skuMap);
  if (config.respectPayload && stats.totalCargoWeightKg > spec.maxPayloadKg + EPS) {
    issues.push({
      id: `pay-${container.id}`,
      severity: 'error',
      rule: 'payload',
      containerId: container.id,
      containerLabel: container.label,
      cartonIds: [],
      message: `Tải trọng cont (${stats.totalCargoWeightKg.toFixed(1)} kg) vượt giới hạn (${spec.maxPayloadKg} kg).`,
    });
  }

  if (
    placements.length > 0 &&
    (stats.cogLongitudinalOffsetPct > config.maxCogOffsetPct ||
      stats.cogLateralOffsetPct > config.maxCogOffsetPct)
  ) {
    issues.push({
      id: `cog-${container.id}`,
      severity: 'warning',
      rule: 'cog_balance',
      containerId: container.id,
      containerLabel: container.label,
      cartonIds: [],
      message: `Trọng tâm lệch quá ${config.maxCogOffsetPct}% cho phép (Dọc: ${stats.cogLongitudinalOffsetPct.toFixed(1)}%, W: ${stats.cogLateralOffsetPct.toFixed(1)}%).`,
    });
  }

  return issues;
}

export function validateProject(
  containers: ContainerLoad[],
  specsById: Map<string, ContainerSpec>,
  skus: CargoSku[],
  config: OptimizationConfig
): ValidationIssue[] {
  const skuMap = new Map(skus.map((s) => [s.id, s]));
  const allIssues: ValidationIssue[] = [];
  for (const container of containers) {
    const spec = specsById.get(container.containerSpecId);
    if (!spec) continue;
    allIssues.push(...validateContainerLoad(container, spec, skuMap, config));
  }
  return allIssues;
}
