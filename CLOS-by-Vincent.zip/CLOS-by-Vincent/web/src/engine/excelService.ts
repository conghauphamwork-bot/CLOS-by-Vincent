import { parseRotation } from '../lib/rotation';
import * as XLSX from 'xlsx';
import {
  CargoSku,
  ContainerLoad,
  ContainerSpec,
  ExcelImportResult,
  ExcelImportRowError,
  LoadingProject,
  PlacedCarton,
  RotationPolicy,
} from '../types/clos';
import {
  computeContainerStats,
  reconcileProjectQuantities,
} from './reconciliation';

const SKU_PALETTE = [
  '#2563EB',
  '#0D9488',
  '#D97706',
  '#7C3AED',
  '#059669',
  '#DC2626',
  '#0284C7',
  '#9333EA',
  '#EA580C',
  '#4F46E5',
];

function parseBooleanFlag(raw: unknown, defaultVal = true): boolean {
  if (raw === undefined || raw === null || raw === '') return defaultVal;
  const s = String(raw).trim().toLowerCase();
  if (['no', 'false', '0', 'n'].includes(s)) return false;
  if (['yes', 'true', '1', 'y'].includes(s)) return true;
  return defaultVal;
}

function parseRotationPolicy(raw: unknown): RotationPolicy | null {
  // Ô trống = mã 2 (giữ như bản gốc); nhận 1/2/4/6 theo CargoWiz
  if (raw === undefined || raw === null || String(raw).trim() === '') return 'upright_only';
  return parseRotation(raw);
}

export function downloadCargoImportTemplate() {
  const rows = [
    {
      'Factory SKU': 'FAC-OAK-TBL-01',
      'Customer SKU': 'NORD-DT-180',
      Description: 'Solid Oak Dining Table 180cm KD',
      Length: 1860,
      Width: 960,
      Height: 165,
      Weight: 42.5,
      Quantity: 28,
      Stackable: 'Yes',
      Rotation: 'upright_only',
      Fragile: 'No',
    },
    {
      'Factory SKU': 'FAC-CHR-UPH-04',
      'Customer SKU': 'NORD-LC-04',
      Description: 'Upholstered Lounge Chair Boxed',
      Length: 780,
      Width: 740,
      Height: 820,
      Weight: 18.2,
      Quantity: 40,
      Stackable: 'Yes',
      Rotation: 'upright_only',
      Fragile: 'No',
    },
    {
      'Factory SKU': 'FAC-MIR-CAB-09',
      'Customer SKU': 'NORD-MC-09',
      Description: 'Glass Front Display Cabinet',
      Length: 1220,
      Width: 480,
      Height: 1750,
      Weight: 54.0,
      Quantity: 10,
      Stackable: 'No',
      Rotation: 'none',
      Fragile: 'Yes',
    },
  ];

  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Cargo_Import');
  XLSX.writeFile(wb, 'CLOS_Cargo_Import_Template.xlsx');
}

export async function parseCargoExcelFile(
  file: File
): Promise<ExcelImportResult> {
  const buffer = await file.arrayBuffer();
  const wb = XLSX.read(buffer, { type: 'array' });
  const firstSheetName = wb.SheetNames[0];
  const sheet = wb.Sheets[firstSheetName];
  const rawRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
    defval: '',
  });

  return validateCargoRows(rawRows);
}

export function validateCargoRows(
  rawRows: Array<Record<string, unknown>>
): ExcelImportResult {
  const validSkus: CargoSku[] = [];
  const errors: ExcelImportRowError[] = [];
  const duplicateSkus: string[] = [];
  const seenFactorySkus = new Set<string>();

  rawRows.forEach((row, index) => {
    const rowNum = index + 2; // Excel row accounting for header
    const getCol = (keys: string[]) => {
      for (const k of keys) {
        for (const rowKey of Object.keys(row)) {
          if (rowKey.trim().toLowerCase() === k.toLowerCase()) {
            return row[rowKey];
          }
        }
      }
      return '';
    };

    const factorySku = String(
      getCol(['Factory SKU', 'FactorySKU', 'factory_sku', 'SKU', 'Mã nhà máy', 'Ma nha may', 'Mã NM'])
    ).trim();
    const customerSku = String(
      getCol(['Customer SKU', 'CustomerSKU', 'customer_sku', 'Mã khách', 'Ma khach', 'Mã KH'])
    ).trim();
    const description = String(
      getCol(['Description', 'Product Name', 'Name', 'Desc', 'Mô tả', 'Mo ta', 'Tên hàng'])
    ).trim();

    const rawL = getCol(['Length', 'Length (mm)', 'L', 'lengthMm', 'Dài', 'Dài (mm)', 'D']);
    const rawW = getCol(['Width', 'Width (mm)', 'W', 'widthMm', 'Rộng', 'Rộng (mm)', 'R']);
    const rawH = getCol(['Height', 'Height (mm)', 'H', 'heightMm', 'Cao', 'Cao (mm)', 'C']);
    const rawWt = getCol(['Weight', 'Weight (kg)', 'Wt', 'weightKg', 'Kg', 'Kg/thùng', 'Trọng lượng']);
    const rawQty = getCol(['Quantity', 'Qty', 'Required Qty', 'requiredQty', 'Số lượng', 'SL', 'Số yêu cầu']);
    const rawStack = getCol(['Stackable', 'stackable', 'Chồng được', 'Chồng']);
    const rawRot = getCol(['Rotation', 'rotation', 'Rotation Policy', 'Xoay', 'Mã xoay', 'Orientation']);
    const rawFragile = getCol(['Fragile', 'fragile']);

    const rowErrors: ExcelImportRowError[] = [];

    if (!factorySku) {
      rowErrors.push({
        rowNumber: rowNum,
        factorySku: '(Thiếu)',
        field: 'Factory SKU',
        message: 'Bắt buộc có Mã nhà máy.',
      });
    } else if (seenFactorySkus.has(factorySku)) {
      duplicateSkus.push(factorySku);
      rowErrors.push({
        rowNumber: rowNum,
        factorySku,
        field: 'Factory SKU',
        message: `Trùng Mã nhà máy "${factorySku}" trong file.`,
      });
    }

    if (!customerSku) {
      rowErrors.push({
        rowNumber: rowNum,
        factorySku: factorySku || `Dòng ${rowNum}`,
        field: 'Customer SKU',
        message: 'Bắt buộc có Mã khách.',
      });
    }

    const lengthMm = Number(rawL);
    const widthMm = Number(rawW);
    const heightMm = Number(rawH);
    const weightKg = Number(rawWt);
    const requiredQty = Number(rawQty);

    if (rawL === '' || !Number.isFinite(lengthMm) || lengthMm <= 0) {
      rowErrors.push({
        rowNumber: rowNum,
        factorySku: factorySku || `Dòng ${rowNum}`,
        field: 'Length',
        message: 'Thiếu hoặc sai chiều Dài thùng (phải > 0 mm). Hỏi Phòng Kỹ thuật nếu chưa có.',
      });
    }
    if (rawW === '' || !Number.isFinite(widthMm) || widthMm <= 0) {
      rowErrors.push({
        rowNumber: rowNum,
        factorySku: factorySku || `Dòng ${rowNum}`,
        field: 'Width',
        message: 'Thiếu hoặc sai chiều Rộng thùng (phải > 0 mm).',
      });
    }
    if (rawH === '' || !Number.isFinite(heightMm) || heightMm <= 0) {
      rowErrors.push({
        rowNumber: rowNum,
        factorySku: factorySku || `Dòng ${rowNum}`,
        field: 'Height',
        message: 'Thiếu hoặc sai chiều Cao thùng (phải > 0 mm).',
      });
    }
    if (rawWt === '' || !Number.isFinite(weightKg) || weightKg <= 0) {
      rowErrors.push({
        rowNumber: rowNum,
        factorySku: factorySku || `Dòng ${rowNum}`,
        field: 'Weight',
        message: 'Thiếu hoặc sai Kg thùng (phải > 0 kg).',
      });
    }
    if (
      rawQty === '' ||
      !Number.isInteger(requiredQty) ||
      requiredQty <= 0
    ) {
      rowErrors.push({
        rowNumber: rowNum,
        factorySku: factorySku || `Dòng ${rowNum}`,
        field: 'Quantity',
        message: 'Số lượng phải là số nguyên dương.',
      });
    }

    const rotationPolicy = parseRotationPolicy(rawRot);
    if (!rotationPolicy) {
      rowErrors.push({
        rowNumber: rowNum,
        factorySku: factorySku || `Dòng ${rowNum}`,
        field: 'Rotation',
        message: `Không hiểu mã xoay "${String(rawRot)}". Dùng 1, 2, 4 hoặc 6 (như CargoWiz).`,
      });
    }

    if (rowErrors.length > 0) {
      errors.push(...rowErrors);
      return;
    }

    seenFactorySkus.add(factorySku);
    const stackable = parseBooleanFlag(rawStack, true);
    const fragile = parseBooleanFlag(rawFragile, false);

    validSkus.push({
      id: `sku-${factorySku.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
      factorySku,
      customerSku,
      description: description || `${factorySku} Thùng xuất khẩu`,
      lengthMm,
      widthMm,
      heightMm,
      weightKg,
      requiredQty,
      stackable,
      maxStackLayers: stackable ? 99 : 1, // 99 = không giới hạn (luật số lớp chưa được xác nhận — không tự đặt)
      maxStackWeightKg: stackable ? (fragile ? 35 : 220) : 0,
      rotationPolicy: rotationPolicy ?? 'upright_only',
      fragile,
      palletized: false,
      color: SKU_PALETTE[validSkus.length % SKU_PALETTE.length],
    });
  });

  return {
    validSkus,
    errors,
    duplicateSkus,
    totalRowsRead: rawRows.length,
  };
}

export function exportProjectToExcel(
  project: LoadingProject,
  specsById: Map<string, ContainerSpec>,
  containerFilterId?: string
) {
  const wb = XLSX.utils.book_new();
  const skuMap = new Map(project.skus.map((s) => [s.id, s]));
  const recon = reconcileProjectQuantities(project.skus, project.containers);

  const targetContainers: ContainerLoad[] = containerFilterId
    ? project.containers.filter((c) => c.id === containerFilterId)
    : project.containers;

  // Sheet 1: Project & Container Summary
  const summaryRows = targetContainers.map((c) => {
    const spec = specsById.get(c.containerSpecId)!;
    const stats = computeContainerStats(c, spec, skuMap);
    return {
      'Mã dự án': project.code,
      'Tên dự án': project.name,
      'Khách hàng': project.customerName,
      'Cảng đến': project.destinationPort,
      'Cont': c.label,
      'Lòng cont DxRxC (mm)': `${spec.internalLengthMm} x ${spec.internalWidthMm} x ${spec.internalHeightMm}`,
      'Số thùng': stats.totalCartons,
      'Số lớp': stats.layerCount,
      'Thể tích dùng (m3)': Number(stats.usedVolumeM3.toFixed(3)),
      'Độ đầy (%)': Number(stats.volumeUtilizationPct.toFixed(2)),
      'Trọng lượng hàng (kg)': Number(stats.totalCargoWeightKg.toFixed(1)),
      'Tải tối đa (kg)': spec.maxPayloadKg,
      'Tỷ lệ tải (%)': Number(stats.payloadUtilizationPct.toFixed(2)),
      'Lệch trọng tâm Dọc/Ngang (%)': `${stats.cogLongitudinalOffsetPct.toFixed(1)}% / ${stats.cogLateralOffsetPct.toFixed(1)}%`,
      'Trọng tâm': stats.cogBalanceOk ? 'Cân bằng' : 'Cần xem',
    };
  });
  const summarySheet = XLSX.utils.json_to_sheet(
    summaryRows.length > 0 ? summaryRows : [{ 'Ghi chú': 'Chưa có cont' }]
  );
  XLSX.utils.book_append_sheet(wb, summarySheet, 'Tong hop');

  // Sheet 2: Quantity Reconciliation
  const reconRows = recon.rows.map((r) => {
    const rowObj: Record<string, string | number> = {
      'Mã nhà máy': r.factorySku,
      'Mã khách': r.customerSku,
      'Mô tả': r.description,
      'Thùng DxRxC (mm)': r.dimensionsLabel,
      'Số yêu cầu': r.requiredQty,
    };
    for (const c of project.containers) {
      rowObj[c.label] = r.perContainerQty[c.id] ?? 0;
    }
    rowObj['Đã xếp'] = r.totalLoadedQty;
    rowObj['Còn lại'] = r.remainingQty;
    rowObj['Kiểm tra (Yêu cầu = Đã xếp + Còn lại)'] = r.reconciled ? 'ĐẠT' : 'LỆCH';
    return rowObj;
  });
  const reconSheet = XLSX.utils.json_to_sheet(reconRows);
  XLSX.utils.book_append_sheet(wb, reconSheet, 'Doi soat so luong');

  // Sheet 3+: Layer-by-Layer Loading Plan per container
  targetContainers.forEach((c, idx) => {
    const sorted = [...c.placements].sort(
      (a, b) => a.layerIndex - b.layerIndex || a.xMm - b.xMm || a.zMm - b.zMm
    );
    const planRows = sorted.map((p, seq) => {
      const sku = skuMap.get(p.skuId);
      return {
        'TT xếp': seq + 1,
        'Lớp': p.layerIndex + 1,
        'Mã nhà máy': sku?.factorySku ?? p.skuId,
        'Mã khách': sku?.customerSku ?? '',
        'Mô tả': sku?.description ?? '',
        'X (mm từ vách trong)': Math.round(p.xMm),
        'Y (mm từ sàn)': Math.round(p.yMm),
        'Z (mm từ vách trái)': Math.round(p.zMm),
        'Kích thước đặt DxCxR (mm)': `${Math.round(p.dimXMm)} x ${Math.round(p.dimYMm)} x ${Math.round(p.dimZMm)}`,
        'Hướng đặt': p.rotationLabel,
        'Canh': p.anchorMode === 'right' ? 'Sát phải' : 'Sát trái',
        'Kg': sku?.weightKg ?? 0,
      };
    });
    const sheetName = `C${idx + 1}_TheoLop`.slice(0, 31);
    const sheet = XLSX.utils.json_to_sheet(
      planRows.length > 0 ? planRows : [{ 'Ghi chú': 'Cont trống' }]
    );
    XLSX.utils.book_append_sheet(wb, sheet, sheetName);
  });

  const filename = containerFilterId
    ? `${project.code}_${targetContainers[0]?.label.replace(/[^a-zA-Z0-9]/g, '_')}_KeHoachXep_CLOSbyVincent.xlsx`
    : `${project.code}_KeHoachXep_TatCaCont_CLOSbyVincent.xlsx`;

  XLSX.writeFile(wb, filename);
}

export interface StepByStepCartonEntry {
  stepNumber: number;
  zoneLabel: string;
  placement: PlacedCarton;
  sku?: CargoSku;
  cumulativeWeightKg: number;
}

export function computeInsideToOutsideSteps(
  container: ContainerLoad,
  spec: ContainerSpec,
  skuMap: Map<string, CargoSku>
): StepByStepCartonEntry[] {
  const remaining = [...container.placements];
  const ordered: PlacedCarton[] = [];
  const placedIds = new Set<string>();
  const EPS = 2.0;

  // Topological sort: a carton is ready once all cartons directly supporting it from below are placed
  const hasUnplacedSupport = (target: PlacedCarton): boolean => {
    if (target.yMm <= EPS) return false;
    for (const cand of remaining) {
      if (placedIds.has(cand.instanceId) || cand.instanceId === target.instanceId) {
        continue;
      }
      const topY = cand.yMm + cand.dimYMm;
      if (Math.abs(topY - target.yMm) > 3.0) continue;
      const ox =
        Math.min(target.xMm + target.dimXMm, cand.xMm + cand.dimXMm) -
        Math.max(target.xMm, cand.xMm);
      const oz =
        Math.min(target.zMm + target.dimZMm, cand.zMm + cand.dimZMm) -
        Math.max(target.zMm, cand.zMm);
      if (ox > 5 && oz > 5) return true;
    }
    return false;
  };

  while (ordered.length < container.placements.length) {
    const ready = remaining.filter(
      (p) => !placedIds.has(p.instanceId) && !hasUnplacedSupport(p)
    );
    const pool =
      ready.length > 0
        ? ready
        : remaining.filter((p) => !placedIds.has(p.instanceId));

    // Inside-to-outside priority: deepest X (closest to rear wall), then floor-to-top Y, then Left-to-Right Z
    pool.sort((a, b) => {
      if (Math.abs(a.xMm - b.xMm) > 25) return a.xMm - b.xMm;
      if (Math.abs(a.yMm - b.yMm) > 10) return a.yMm - b.yMm;
      if (Math.abs(a.zMm - b.zMm) > 10) return a.zMm - b.zMm;
      return a.xMm - b.xMm;
    });

    const chosen = pool[0];
    placedIds.add(chosen.instanceId);
    ordered.push(chosen);
  }

  const zoneSizeMm = Math.max(1500, Math.ceil(spec.internalLengthMm / 5));
  let cumWeight = 0;

  return ordered.map((p, idx) => {
    const sku = skuMap.get(p.skuId);
    cumWeight += sku?.weightKg ?? 0;
    const zoneIdx = Math.min(
      4,
      Math.floor(p.xMm / zoneSizeMm)
    );
    const zoneStartM = ((zoneIdx * zoneSizeMm) / 1000).toFixed(1);
    const zoneEndM = (
      Math.min(spec.internalLengthMm, (zoneIdx + 1) * zoneSizeMm) / 1000
    ).toFixed(1);
    const zoneTag =
      zoneIdx === 0
        ? `Vùng 1 - Sát vách trong (${zoneStartM}-${zoneEndM}m)`
        : zoneIdx === 4 || (zoneIdx + 1) * zoneSizeMm >= spec.internalLengthMm
          ? `Vùng ${zoneIdx + 1} - Sát cửa cont (${zoneStartM}-${zoneEndM}m)`
          : `Vùng ${zoneIdx + 1} - Giữa cont (${zoneStartM}-${zoneEndM}m)`;

    return {
      stepNumber: idx + 1,
      zoneLabel: zoneTag,
      placement: p,
      sku,
      cumulativeWeightKg: cumWeight,
    };
  });
}

export function exportStepByStepExcel(
  project: LoadingProject,
  specsById: Map<string, ContainerSpec>,
  containerFilterId?: string
) {
  const wb = XLSX.utils.book_new();
  const skuMap = new Map(project.skus.map((s) => [s.id, s]));

  const targetContainers: ContainerLoad[] = containerFilterId
    ? project.containers.filter((c) => c.id === containerFilterId)
    : project.containers;

  // Sheet 1: Warehouse Loading SOP Overview
  const overviewRows = targetContainers.map((c) => {
    const spec = specsById.get(c.containerSpecId)!;
    const stats = computeContainerStats(c, spec, skuMap);
    return {
      'Mã dự án': project.code,
      'Tên dự án': project.name,
      'Cont': c.label,
      'Hướng xếp': 'TRONG (vách X=0mm) -> NGOÀI (cửa)',
      'Lòng cont DxRxC (mm)': `${spec.internalLengthMm} x ${spec.internalWidthMm} x ${spec.internalHeightMm}`,
      'Tổng số bước': stats.totalCartons,
      'Tổng số lớp': stats.layerCount,
      'Độ đầy (%)': Number(stats.volumeUtilizationPct.toFixed(2)),
      'Tổng kg hàng': Number(stats.totalCargoWeightKg.toFixed(1)),
      'Trọng tâm': stats.cogBalanceOk ? 'CÂN BẰNG' : 'CẦN XEM',
    };
  });

  const overviewSheet = XLSX.utils.json_to_sheet(
    overviewRows.length > 0
      ? overviewRows
      : [{ 'Ghi chú': 'Dự án chưa có cont' }]
  );
  XLSX.utils.book_append_sheet(wb, overviewSheet, 'Tong quan');

  // For each container: Grouped Step-by-Step Guide + Detailed Carton Sequence
  targetContainers.forEach((c, idx) => {
    const spec = specsById.get(c.containerSpecId)!;
    const steps = computeInsideToOutsideSteps(c, spec, skuMap);

    // Group consecutive steps sharing same Zone, Layer, SKU, and Orientation for fast floor execution
    const groupedRows: Array<Record<string, string | number>> = [];
    let groupSeq = 1;
    let i = 0;
    while (i < steps.length) {
      const start = steps[i];
      let j = i + 1;
      while (
        j < steps.length &&
        steps[j].placement.skuId === start.placement.skuId &&
        steps[j].placement.layerIndex === start.placement.layerIndex &&
        steps[j].zoneLabel === start.zoneLabel &&
        steps[j].placement.rotationLabel === start.placement.rotationLabel
      ) {
        j++;
      }
      const batch = steps.slice(i, j);
      const minX = Math.min(...batch.map((b) => b.placement.xMm));
      const maxX = Math.max(
        ...batch.map((b) => b.placement.xMm + b.placement.dimXMm)
      );
      const minZ = Math.min(...batch.map((b) => b.placement.zMm));
      const maxZ = Math.max(
        ...batch.map((b) => b.placement.zMm + b.placement.dimZMm)
      );
      const batchWeight = batch.reduce(
        (s, b) => s + (b.sku?.weightKg ?? 0),
        0
      );
      const yBase = Math.round(start.placement.yMm);

      groupedRows.push({
        'Bước': groupSeq++,
        'Thùng số':
          batch.length === 1
            ? `#${start.stepNumber}`
            : `#${start.stepNumber} - #${batch[batch.length - 1].stepNumber}`,
        'Vùng (trong -> ngoài)': start.zoneLabel,
        'Lớp': `Lớp ${start.placement.layerIndex + 1} (Y=${yBase}mm)`,
        'Mã nhà máy': start.sku?.factorySku ?? start.placement.skuId,
        'Mã khách': start.sku?.customerSku ?? '',
        'SL cần xếp': batch.length,
        'Hướng đặt': start.placement.rotationLabel,
        'Khoảng sâu X (trong->cửa, mm)': `${Math.round(minX)} -> ${Math.round(maxX)}`,
        'Khoảng ngang Z (trái->phải, mm)': `${Math.round(minZ)} -> ${Math.round(maxZ)}`,
        'Kg của bước': Number(batchWeight.toFixed(1)),
        'Hướng dẫn cho tổ xếp': `Xếp ${batch.length}x ${start.sku?.factorySku ?? start.placement.skuId} ở lớp ${start.placement.layerIndex + 1} (Y=${yBase}mm) từ X=${Math.round(minX)}mm ra ngoài (${start.placement.rotationLabel})`,
        'Kiểm tra': '[   ]',
      });
      i = j;
    }

    const guideSheetName = `C${idx + 1}_TungBuoc`.slice(0, 31);
    const guideSheet = XLSX.utils.json_to_sheet(
      groupedRows.length > 0 ? groupedRows : [{ 'Ghi chú': 'Cont trống' }]
    );
    XLSX.utils.book_append_sheet(wb, guideSheet, guideSheetName);

    // Exact 1-by-1 Carton Sequence Sheet
    const detailRows = steps.map((s) => ({
      'Bước': s.stepNumber,
      'Vùng (trong -> ngoài)': s.zoneLabel,
      'Lớp': `L${s.placement.layerIndex + 1}`,
      'Mã nhà máy': s.sku?.factorySku ?? s.placement.skuId,
      'Mã khách': s.sku?.customerSku ?? '',
      'Mô tả': s.sku?.description ?? '',
      'Cách vách trong X (mm)': Math.round(s.placement.xMm),
      'Cách sàn Y (mm)': Math.round(s.placement.yMm),
      'Cách vách trái Z (mm)': Math.round(s.placement.zMm),
      'Đặt DxCxR (mm)': `${Math.round(s.placement.dimXMm)} x ${Math.round(s.placement.dimYMm)} x ${Math.round(s.placement.dimZMm)}`,
      'Hướng đặt': s.placement.rotationLabel,
      'Kg thùng': s.sku?.weightKg ?? 0,
      'Kg cộng dồn': Number(s.cumulativeWeightKg.toFixed(1)),
      'Đã xếp [x]': '[   ]',
    }));

    const detailSheetName = `C${idx + 1}_ThuTuThung`.slice(0, 31);
    const detailSheet = XLSX.utils.json_to_sheet(
      detailRows.length > 0 ? detailRows : [{ 'Ghi chú': 'Cont trống' }]
    );
    XLSX.utils.book_append_sheet(wb, detailSheet, detailSheetName);
  });

  const filename = containerFilterId
    ? `${project.code}_${targetContainers[0]?.label.replace(/[^a-zA-Z0-9]/g, '_')}_XepTungBuoc_CLOSbyVincent.xlsx`
    : `${project.code}_XepTungBuoc_TatCaCont_CLOSbyVincent.xlsx`;

  XLSX.writeFile(wb, filename);
}

