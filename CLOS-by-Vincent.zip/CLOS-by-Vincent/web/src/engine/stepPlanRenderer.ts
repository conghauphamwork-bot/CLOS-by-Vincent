import {
  CargoSku,
  ContainerLoad,
  ContainerSpec,
  PlacedCarton,
} from '../types/clos';
import {
  computeInsideToOutsideSteps,
  StepByStepCartonEntry,
} from './excelService';

export interface LoadingStepSkuSummary {
  skuId: string;
  factorySku: string;
  customerSku: string;
  description: string;
  color: string;
  qty: number;
  lengthCm: number;
  lengthMm: number;
  widthMm: number;
  heightMm: number;
  widthCm: number;
  heightCm: number;
  weightKg: number;
  layerLabel: string;
  zoneLabel: string;
}

export interface LoadingStepGroup {
  stepNumber: number;
  isFinalStep: boolean;
  entries: StepByStepCartonEntry[];
  priorPlacements: PlacedCarton[];
  activePlacements: PlacedCarton[];
  skuSummaries: LoadingStepSkuSummary[];
  totalStepCartons: number;
  stepWeightKg: number;
  cumulativeWeightKg: number;
  minXCm: number;
  minXMm: number;
  maxXMm: number;
  maxXCm: number;
  layerRangeLabel: string;
}

/**
 * Partition the topological inside-to-outside sequence into clear, warehouse-executable
 * loading steps (typically 6-18 steps per container) so every step represents a cohesive
 * longitudinal bay/wall slice progressing from the rear bulkhead (X=0) to the doors (X=L).
 */
export function buildInsideToOutsideStepGroups(
  container: ContainerLoad,
  spec: ContainerSpec,
  skuMap: Map<string, CargoSku>
): LoadingStepGroup[] {
  const ordered = computeInsideToOutsideSteps(container, spec, skuMap);
  if (ordered.length === 0) return [];

  const maxBayDepthMm = Math.max(900, Math.round(spec.internalLengthMm / 10));
  const rawGroups: StepByStepCartonEntry[][] = [];

  let current: StepByStepCartonEntry[] = [];
  let groupMinX = 0;
  let groupMaxX = 0;
  let groupSkus = new Set<string>();

  for (let i = 0; i < ordered.length; i++) {
    const entry = ordered[i];
    const p = entry.placement;

    if (current.length === 0) {
      current = [entry];
      groupMinX = p.xMm;
      groupMaxX = p.xMm + p.dimXMm;
      groupSkus = new Set([p.skuId]);
      continue;
    }

    const prev = current[current.length - 1].placement;
    const nextMinX = Math.min(groupMinX, p.xMm);
    const nextMaxX = Math.max(groupMaxX, p.xMm + p.dimXMm);
    const nextDepthSpan = nextMaxX - nextMinX;

    const movedPastFrontWall = p.xMm >= groupMaxX - 30;
    const newFloorColumn =
      p.yMm <= 25 &&
      p.xMm > groupMinX + 160 &&
      (current.length >= 2 || prev.yMm > 25);
    const exceededBayDepth =
      nextDepthSpan > maxBayDepthMm && current.length >= 3;
    const tooManySkus =
      groupSkus.size >= 4 && !groupSkus.has(p.skuId);
    const tooManyCartons = current.length >= 24;

    if (
      movedPastFrontWall ||
      newFloorColumn ||
      exceededBayDepth ||
      tooManySkus ||
      tooManyCartons
    ) {
      rawGroups.push(current);
      current = [entry];
      groupMinX = p.xMm;
      groupMaxX = p.xMm + p.dimXMm;
      groupSkus = new Set([p.skuId]);
    } else {
      current.push(entry);
      groupMinX = nextMinX;
      groupMaxX = nextMaxX;
      groupSkus.add(p.skuId);
    }
  }
  if (current.length > 0) {
    rawGroups.push(current);
  }

  // Merge tiny consecutive single-carton/small slices that sit in the same depth band
  // so 100+ small cartons don't create 40 tiny 1-box steps.
  const mergedGroups: StepByStepCartonEntry[][] = [];
  for (const grp of rawGroups) {
    if (mergedGroups.length === 0) {
      mergedGroups.push(grp);
      continue;
    }
    const prevGrp = mergedGroups[mergedGroups.length - 1];
    const combined = [...prevGrp, ...grp];
    const minX = Math.min(...combined.map((e) => e.placement.xMm));
    const maxX = Math.max(
      ...combined.map((e) => e.placement.xMm + e.placement.dimXMm)
    );
    const distinctSkus = new Set(combined.map((e) => e.placement.skuId));

    const shouldMergeTiny =
      prevGrp.length <= 2 &&
      grp.length <= 2 &&
      combined.length <= 12 &&
      distinctSkus.size <= 3 &&
      maxX - minX <= Math.max(1200, Math.round(spec.internalLengthMm / 8));

    if (shouldMergeTiny) {
      mergedGroups[mergedGroups.length - 1] = combined;
    } else {
      mergedGroups.push(grp);
    }
  }

  // If still > 24 steps (e.g. massive LCL mixed container), coalesce adjacent smallest pairs
  while (mergedGroups.length > 24) {
    let bestIdx = 0;
    let bestScore = Infinity;
    for (let i = 0; i < mergedGroups.length - 1; i++) {
      const a = mergedGroups[i];
      const b = mergedGroups[i + 1];
      const skus = new Set([
        ...a.map((e) => e.placement.skuId),
        ...b.map((e) => e.placement.skuId),
      ]);
      const score = a.length + b.length + skus.size * 4;
      if (score < bestScore) {
        bestScore = score;
        bestIdx = i;
      }
    }
    mergedGroups.splice(bestIdx, 2, [
      ...mergedGroups[bestIdx],
      ...mergedGroups[bestIdx + 1],
    ]);
  }

  // Build final LoadingStepGroup objects with cumulative prior placements
  const priorAccum: PlacedCarton[] = [];
  return mergedGroups.map((entries, idx) => {
    const priorSnapshot = [...priorAccum];
    const activePlacements = entries.map((e) => e.placement);
    priorAccum.push(...activePlacements);

    const bySku = new Map<string, StepByStepCartonEntry[]>();
    for (const e of entries) {
      const list = bySku.get(e.placement.skuId) ?? [];
      list.push(e);
      bySku.set(e.placement.skuId, list);
    }

    const skuSummaries: LoadingStepSkuSummary[] = [];
    for (const [skuId, list] of bySku.entries()) {
      const sku = skuMap.get(skuId);
      const first = list[0];
      const layers = Array.from(
        new Set(list.map((e) => `L${e.placement.layerIndex + 1}`))
      ).sort();
      skuSummaries.push({
        skuId,
        factorySku: sku?.factorySku ?? skuId,
        customerSku: sku?.customerSku ?? '',
        description: sku?.description || sku?.customerSku || '',
        color: sku?.color ?? '#3B82F6',
        qty: list.length,
        lengthCm: Number(((sku?.lengthMm ?? first.placement.dimXMm) / 10).toFixed(1)),
        lengthMm: Math.round(sku?.lengthMm ?? first.placement.dimXMm),
        widthMm: Math.round(sku?.widthMm ?? first.placement.dimZMm),
        heightMm: Math.round(sku?.heightMm ?? first.placement.dimYMm),
        widthCm: Number(((sku?.widthMm ?? first.placement.dimZMm) / 10).toFixed(1)),
        heightCm: Number(((sku?.heightMm ?? first.placement.dimYMm) / 10).toFixed(1)),
        weightKg: sku?.weightKg ?? 0,
        layerLabel:
          layers.length === 1
            ? layers[0]
            : `${layers[0]}-${layers[layers.length - 1]}`,
        zoneLabel: first.zoneLabel.split('(')[0].trim(),
      });
    }

    const minXMm = Math.min(...activePlacements.map((p) => p.xMm));
    const maxXMm = Math.max(...activePlacements.map((p) => p.xMm + p.dimXMm));
    const minLayer = Math.min(...activePlacements.map((p) => p.layerIndex)) + 1;
    const maxLayer = Math.max(...activePlacements.map((p) => p.layerIndex)) + 1;
    const stepWeightKg = entries.reduce(
      (sum, e) => sum + (e.sku?.weightKg ?? 0),
      0
    );

    return {
      stepNumber: idx + 1,
      isFinalStep: idx === mergedGroups.length - 1,
      entries,
      priorPlacements: priorSnapshot,
      activePlacements,
      skuSummaries,
      totalStepCartons: entries.length,
      stepWeightKg,
      cumulativeWeightKg: entries[entries.length - 1].cumulativeWeightKg,
      minXCm: Math.round(minXMm / 10),
      minXMm: Math.round(minXMm),
      maxXMm: Math.round(maxXMm),
      maxXCm: Math.round(maxXMm / 10),
      layerRangeLabel:
        minLayer === maxLayer ? `L${minLayer}` : `L${minLayer}-L${maxLayer}`,
    };
  });
}

// ---------- Color shading helpers ----------

function parseHex(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  if (clean.length === 3) {
    return [
      parseInt(clean[0] + clean[0], 16),
      parseInt(clean[1] + clean[1], 16),
      parseInt(clean[2] + clean[2], 16),
    ];
  }
  const num = parseInt(clean.slice(0, 6), 16);
  if (Number.isNaN(num)) return [96, 165, 250];
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

function shadeHex(hex: string, factor: number): string {
  const [r, g, b] = parseHex(hex);
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
  if (factor >= 1) {
    const t = Math.min(1, factor - 1);
    return `rgb(${clamp(r + (255 - r) * t)}, ${clamp(g + (255 - g) * t)}, ${clamp(b + (255 - b) * t)})`;
  }
  return `rgb(${clamp(r * factor)}, ${clamp(g * factor)}, ${clamp(b * factor)})`;
}

// ---------- Exact Topological AABB Occlusion Sort ----------

interface RenderBox {
  x0: number;
  x1: number;
  y0: number;
  y1: number;
  z0: number; // transformed to camera-near space [0..W] where larger = closer to camera
  z1: number;
  fillHex: string;
  strokeHex: string;
  isPrior: boolean;
  screenMinX: number;
  screenMaxX: number;
  screenMinY: number;
  screenMaxY: number;
  depthScore: number;
}

function sortBoxesBackToFront(boxes: RenderBox[]): RenderBox[] {
  const n = boxes.length;
  if (n <= 1) return boxes;

  const eps = 2.5;
  const adj: number[][] = Array.from({ length: n }, () => []);

  for (let i = 0; i < n; i++) {
    const a = boxes[i];
    for (let j = i + 1; j < n; j++) {
      const b = boxes[j];
      // Skip pairs whose 2D projected bounding boxes don't overlap
      if (
        a.screenMaxX < b.screenMinX - 0.5 ||
        b.screenMaxX < a.screenMinX - 0.5 ||
        a.screenMaxY < b.screenMinY - 0.5 ||
        b.screenMaxY < a.screenMinY - 0.5
      ) {
        continue;
      }

      const aBehindX = a.x1 <= b.x0 + eps;
      const bBehindX = b.x1 <= a.x0 + eps;
      const aBehindY = a.y1 <= b.y0 + eps;
      const bBehindY = b.y1 <= a.y0 + eps;
      const aBehindZ = a.z1 <= b.z0 + eps;
      const bBehindZ = b.z1 <= a.z0 + eps;

      const aBeforeB =
        (aBehindX || aBehindY || aBehindZ) &&
        !bBehindX &&
        !bBehindY &&
        !bBehindZ;
      const bBeforeA =
        (bBehindX || bBehindY || bBehindZ) &&
        !aBehindX &&
        !aBehindY &&
        !aBehindZ;

      if (aBeforeB && !bBeforeA) {
        adj[i].push(j);
      } else if (bBeforeA && !aBeforeB) {
        adj[j].push(i);
      }
    }
  }

  // DFS post-order topological sort (safe against rare manual-overlap cycles)
  const state = new Uint8Array(n); // 0=unvisited, 1=visiting, 2=done
  const postOrder: number[] = [];

  const indices = Array.from({ length: n }, (_, k) => k).sort(
    (i, j) => boxes[i].depthScore - boxes[j].depthScore
  );

  const dfs = (u: number) => {
    state[u] = 1;
    for (const v of adj[u]) {
      if (state[v] === 0) dfs(v);
    }
    state[u] = 2;
    postOrder.push(u);
  };

  for (const idx of indices) {
    if (state[idx] === 0) dfs(idx);
  }

  // Post-order gives reverse topological order; reverse so dependencies (behind) draw first
  postOrder.reverse();
  return postOrder.map((idx) => boxes[idx]);
}

export type IsometricViewAngle = 'iso_front_left' | 'iso_front_right';

/**
 * Render an ultra-crisp 3D isometric cutaway diagram of the container & cartons
 * as a PNG Data URL ready for jsPDF.
 * - `priorPlacements`: already-loaded cartons rendered in crisp white/light-slate.
 * - `activePlacements`: cartons for the current step rendered in vivid SKU colors.
 */
export function renderContainerIsometricDataUrl(params: {
  spec: ContainerSpec;
  priorPlacements: PlacedCarton[];
  activePlacements: PlacedCarton[];
  skuMap: Map<string, CargoSku>;
  angle?: IsometricViewAngle;
  widthPx?: number;
  heightPx?: number;
}): string {
  const {
    spec,
    priorPlacements,
    activePlacements,
    skuMap,
    angle = 'iso_front_left',
    widthPx = 680,
    heightPx = 380,
  } = params;

  const L = spec.internalLengthMm;
  const W = spec.internalWidthMm;
  const H = spec.internalHeightMm;

  const canvas = document.createElement('canvas');
  canvas.width = widthPx;
  canvas.height = heightPx;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, widthPx, heightPx);

  // Camera projection:
  // iso_front_left: Rear (x=0) top-right -> Doors (x=L) bottom-left; near z = W
  // iso_front_right: Rear (x=0) top-left -> Doors (x=L) bottom-right; near z = 0 (zFlipped = W - z)
  const dir = angle === 'iso_front_left' ? 1 : -1;
  const projectRaw = (x: number, y: number, zCam: number): [number, number] => {
    const u = dir * (-0.84 * x + 0.88 * zCam);
    const v = 0.31 * x + 0.44 * zCam - 0.94 * y;
    return [u, v];
  };

  // Compute bounding box of the entire container to fit comfortably inside canvas
  const containerCorners: Array<[number, number, number]> = [
    [0, 0, 0],
    [L, 0, 0],
    [0, 0, W],
    [L, 0, W],
    [0, H, 0],
    [L, H, 0],
    [0, H, W],
    [L, H, W],
  ];

  let minU = Infinity;
  let maxU = -Infinity;
  let minV = Infinity;
  let maxV = -Infinity;
  for (const [cx, cy, cz] of containerCorners) {
    const [u, v] = projectRaw(cx, cy, cz);
    if (u < minU) minU = u;
    if (u > maxU) maxU = u;
    if (v < minV) minV = v;
    if (v > maxV) maxV = v;
  }

  const padX = 20;
  const padY = 16;
  const scale = Math.min(
    (widthPx - padX * 2) / Math.max(1, maxU - minU),
    (heightPx - padY * 2) / Math.max(1, maxV - minV)
  );
  const offsetX = (widthPx - (maxU - minU) * scale) / 2 - minU * scale;
  const offsetY = (heightPx - (maxV - minV) * scale) / 2 - minV * scale;

  const project = (x: number, y: number, zCam: number): [number, number] => {
    const [u, v] = projectRaw(x, y, zCam);
    return [u * scale + offsetX, v * scale + offsetY];
  };

  const drawPoly = (
    pts: Array<[number, number]>,
    fill: string,
    stroke: string,
    lineWidth = 1.25
  ) => {
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) {
      ctx.lineTo(pts[i][0], pts[i][1]);
    }
    ctx.closePath();
    ctx.fillStyle = fill;
    ctx.fill();
    if (lineWidth > 0) {
      ctx.strokeStyle = stroke;
      ctx.lineWidth = lineWidth;
      ctx.lineJoin = 'round';
      ctx.stroke();
    }
  };

  // 1. Draw Cutaway Container Interior (Floor + Rear Wall + Far Side Wall)
  // Floor (y = 0)
  drawPoly(
    [
      project(0, 0, 0),
      project(L, 0, 0),
      project(L, 0, W),
      project(0, 0, W),
    ],
    '#EFE0B9',
    '#78716C',
    1.5
  );

  // Far Side Wall (zCam = 0)
  drawPoly(
    [
      project(0, 0, 0),
      project(L, 0, 0),
      project(L, H, 0),
      project(0, H, 0),
    ],
    '#F5ECD5',
    '#78716C',
    1.5
  );

  // Rear Bulkhead Wall (x = 0)
  drawPoly(
    [
      project(0, 0, 0),
      project(0, 0, W),
      project(0, H, W),
      project(0, H, 0),
    ],
    '#E8D7AD',
    '#78716C',
    1.5
  );

  // Subtle floor depth markers every 2m from rear wall
  ctx.save();
  ctx.strokeStyle = 'rgba(120, 113, 108, 0.22)';
  ctx.lineWidth = 1;
  for (let mx = 2000; mx < L; mx += 2000) {
    const p1 = project(mx, 0, 0);
    const p2 = project(mx, 0, W);
    ctx.beginPath();
    ctx.moveTo(p1[0], p1[1]);
    ctx.lineTo(p2[0], p2[1]);
    ctx.stroke();
  }
  ctx.restore();

  // 2. Prepare RenderBoxes for Prior (White) and Active (Colored) cartons
  const toRenderBox = (p: PlacedCarton, isPrior: boolean): RenderBox => {
    const sku = skuMap.get(p.skuId);
    const z0 = angle === 'iso_front_left' ? p.zMm : W - (p.zMm + p.dimZMm);
    const z1 = angle === 'iso_front_left' ? p.zMm + p.dimZMm : W - p.zMm;
    const x0 = p.xMm;
    const x1 = p.xMm + p.dimXMm;
    const y0 = p.yMm;
    const y1 = p.yMm + p.dimYMm;

    const corners: Array<[number, number]> = [
      project(x0, y0, z0),
      project(x1, y0, z0),
      project(x0, y1, z0),
      project(x1, y1, z0),
      project(x0, y0, z1),
      project(x1, y0, z1),
      project(x0, y1, z1),
      project(x1, y1, z1),
    ];

    let sMinX = Infinity;
    let sMaxX = -Infinity;
    let sMinY = Infinity;
    let sMaxY = -Infinity;
    for (const [sx, sy] of corners) {
      if (sx < sMinX) sMinX = sx;
      if (sx > sMaxX) sMaxX = sx;
      if (sy < sMinY) sMinY = sy;
      if (sy > sMaxY) sMaxY = sy;
    }

    const cx = (x0 + x1) * 0.5;
    const cy = (y0 + y1) * 0.5;
    const cz = (z0 + z1) * 0.5;

    return {
      x0,
      x1,
      y0,
      y1,
      z0,
      z1,
      fillHex: isPrior ? '#F8FAFC' : sku?.color ?? '#3B82F6',
      strokeHex: isPrior ? '#64748B' : '#0F172A',
      isPrior,
      screenMinX: sMinX,
      screenMaxX: sMaxX,
      screenMinY: sMinY,
      screenMaxY: sMaxY,
      depthScore: cx * 0.31 + cz * 0.44 + cy * 0.94,
    };
  };

  const allBoxes: RenderBox[] = [
    ...priorPlacements.map((p) => toRenderBox(p, true)),
    ...activePlacements.map((p) => toRenderBox(p, false)),
  ];

  const sortedBoxes = sortBoxesBackToFront(allBoxes);

  // 3. Paint cartons in exact back-to-front order (Top, Door-Front, Near-Side)
  for (const box of sortedBoxes) {
    const topColor = box.isPrior ? '#FFFFFF' : shadeHex(box.fillHex, 1.24);
    const frontColor = box.isPrior ? '#F1F5F9' : shadeHex(box.fillHex, 0.98);
    const sideColor = box.isPrior ? '#E2E8F0' : shadeHex(box.fillHex, 0.8);
    const lw = box.isPrior ? 1.0 : 1.35;

    // Top face (y = y1)
    drawPoly(
      [
        project(box.x0, box.y1, box.z0),
        project(box.x1, box.y1, box.z0),
        project(box.x1, box.y1, box.z1),
        project(box.x0, box.y1, box.z1),
      ],
      topColor,
      box.strokeHex,
      lw
    );

    // Door-facing front face (x = x1)
    drawPoly(
      [
        project(box.x1, box.y0, box.z0),
        project(box.x1, box.y1, box.z0),
        project(box.x1, box.y1, box.z1),
        project(box.x1, box.y0, box.z1),
      ],
      frontColor,
      box.strokeHex,
      lw
    );

    // Near side face (zCam = z1)
    drawPoly(
      [
        project(box.x0, box.y0, box.z1),
        project(box.x1, box.y0, box.z1),
        project(box.x1, box.y1, box.z1),
        project(box.x0, box.y1, box.z1),
      ],
      sideColor,
      box.strokeHex,
      lw
    );
  }

  // 4. Subtle top rail / door frame hint so container height boundary stays readable
  ctx.save();
  ctx.strokeStyle = 'rgba(100, 116, 139, 0.35)';
  ctx.lineWidth = 1;
  ctx.setLineDash([4, 4]);
  const r1 = project(0, H, W);
  const r2 = project(L, H, W);
  const r3 = project(L, 0, W);
  const r4 = project(L, H, 0);
  ctx.beginPath();
  ctx.moveTo(r1[0], r1[1]);
  ctx.lineTo(r2[0], r2[1]);
  ctx.lineTo(r3[0], r3[1]);
  ctx.moveTo(r2[0], r2[1]);
  ctx.lineTo(r4[0], r4[1]);
  ctx.stroke();
  ctx.restore();

  return canvas.toDataURL('image/png');
}

/**
 * Render a 2D Top-Down Plan View (Rear Bulkhead at top -> Container Doors at bottom)
 * matching the vertical plan strip on Page 1 of the reference Load Plan Details sheet.
 */
export function renderTopDownPlanDataUrl(params: {
  spec: ContainerSpec;
  placements: PlacedCarton[];
  skuMap: Map<string, CargoSku>;
  widthPx?: number;
  heightPx?: number;
}): string {
  const { spec, placements, skuMap, widthPx = 190, heightPx = 560 } = params;
  const L = spec.internalLengthMm;
  const W = spec.internalWidthMm;

  const canvas = document.createElement('canvas');
  canvas.width = widthPx;
  canvas.height = heightPx;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, widthPx, heightPx);

  const padX = 16;
  const padTop = 24;
  const padBottom = 24;
  const scale = Math.min(
    (widthPx - padX * 2) / W,
    (heightPx - padTop - padBottom) / L
  );
  const drawW = W * scale;
  const drawH = L * scale;
  const originX = (widthPx - drawW) / 2;
  const originY = padTop;

  // Container floor outline
  ctx.fillStyle = '#EFE0B9';
  ctx.fillRect(originX, originY, drawW, drawH);
  ctx.strokeStyle = '#475569';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(originX, originY, drawW, drawH);

  // Draw cartons bottom-to-top so upper layers appear on top
  const sorted = [...placements].sort(
    (a, b) => a.yMm - b.yMm || a.xMm - b.xMm || a.zMm - b.zMm
  );

  for (const p of sorted) {
    const sku = skuMap.get(p.skuId);
    const x = originX + p.zMm * scale;
    const y = originY + p.xMm * scale;
    const w = Math.max(2, p.dimZMm * scale);
    const h = Math.max(2, p.dimXMm * scale);

    ctx.fillStyle = sku?.color ?? '#3B82F6';
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = '#0F172A';
    ctx.lineWidth = 1;
    ctx.strokeRect(x, y, w, h);
  }

  // Labels for Rear & Door ends
  ctx.fillStyle = '#475569';
  ctx.font = 'bold 12px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('VÁCH TRONG', widthPx / 2, 16);
  ctx.fillText('CỬA CONT', widthPx / 2, originY + drawH + 16);

  return canvas.toDataURL('image/png');
}
