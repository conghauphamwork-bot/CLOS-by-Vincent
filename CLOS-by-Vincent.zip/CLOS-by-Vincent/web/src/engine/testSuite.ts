import {
  DEFAULT_CONTAINERS,
  DEFAULT_OPTIMIZATION_CONFIG,
  SEED_PROJECTS,
  SEED_TEMPLATES,
} from '../data/seedProjects';
import { CargoSku, ContainerLoad } from '../types/clos';
import { validateCargoRows } from './excelService';
import {
  buildRecalculationPreview,
  realignContainerAnchor,
  runOptimization,
} from './optimizer';
import { reconcileProjectQuantities } from './reconciliation';
import { validateContainerLoad, validateProject } from './validator';

export interface TestCaseResult {
  id: string;
  name: string;
  passed: boolean;
  durationMs: number;
  details: string;
}

export function runAcceptanceTestSuite(): TestCaseResult[] {
  const results: TestCaseResult[] = [];
  const specs = DEFAULT_CONTAINERS;
  const specsById = new Map(specs.map((s) => [s.id, s]));
  const baseProject = SEED_PROJECTS[0];

  const exec = (id: string, name: string, fn: () => { ok: boolean; msg: string }) => {
    const t0 = performance.now();
    try {
      const { ok, msg } = fn();
      results.push({
        id,
        name,
        passed: ok,
        durationMs: Math.max(1, Math.round(performance.now() - t0)),
        details: msg,
      });
    } catch (err) {
      results.push({
        id,
        name,
        passed: false,
        durationMs: Math.max(1, Math.round(performance.now() - t0)),
        details: err instanceof Error ? err.message : 'Unexpected exception',
      });
    }
  };

  // TC01: Import valid Excel cargo data
  exec('TC01', 'Import valid Excel cargo data', () => {
    const parsed = validateCargoRows([
      {
        'Factory SKU': 'TEST-FAC-01',
        'Customer SKU': 'TEST-CUST-01',
        Length: 1200,
        Width: 800,
        Height: 400,
        Weight: 22,
        Quantity: 15,
        Stackable: 'Yes',
        Rotation: 'upright_only',
      },
    ]);
    return {
      ok: parsed.validSkus.length === 1 && parsed.errors.length === 0,
      msg: `Imported ${parsed.validSkus.length} valid SKU(s), ${parsed.errors.length} error(s).`,
    };
  });

  // TC02: Import invalid cargo data
  exec('TC02', 'Detect missing dimensions & duplicate SKUs on import', () => {
    const parsed = validateCargoRows([
      {
        'Factory SKU': 'DUP-01',
        'Customer SKU': 'C-01',
        Length: '',
        Width: 500,
        Height: 300,
        Weight: 10,
        Quantity: 5,
      },
      {
        'Factory SKU': 'DUP-01',
        'Customer SKU': 'C-02',
        Length: 500,
        Width: 500,
        Height: 300,
        Weight: 10,
        Quantity: -3,
      },
    ]);
    return {
      ok: parsed.validSkus.length === 0 && parsed.errors.length >= 2 && parsed.duplicateSkus.includes('DUP-01'),
      msg: `Blocked invalid rows; caught ${parsed.errors.length} validation errors and duplicate SKU.`,
    };
  });

  // TC03: Modify SKU quantity after loading preserves valid arrangements
  exec('TC03', 'Modify SKU quantity preserves existing valid containers', () => {
    const opt = runOptimization(
      baseProject.skus,
      [],
      specs,
      baseProject.defaultContainerSpecId,
      DEFAULT_OPTIMIZATION_CONFIG
    );
    const modifiedSkus = baseProject.skus.map((s, i) =>
      i === 0 ? { ...s, requiredQty: s.requiredQty + 4 } : s
    );
    const preview = buildRecalculationPreview(
      modifiedSkus,
      opt.containers,
      specs,
      baseProject.defaultContainerSpecId,
      DEFAULT_OPTIMIZATION_CONFIG
    );
    return {
      ok:
        preview.invalidatedCartons.length === 0 &&
        preview.proposedContainers.length >= opt.containers.length,
      msg: preview.summary,
    };
  });

  // TC04: Add additional cargo when container has remaining space
  exec('TC04', 'Add cargo into remaining container space without full rebuild', () => {
    const opt = runOptimization(
      baseProject.skus.slice(0, 2),
      [],
      specs,
      baseProject.defaultContainerSpecId,
      DEFAULT_OPTIMIZATION_CONFIG
    );
    const extraSku: CargoSku = {
      ...baseProject.skus[3],
      requiredQty: 5,
    };
    const preview = buildRecalculationPreview(
      [...baseProject.skus.slice(0, 2), extraSku],
      opt.containers,
      specs,
      baseProject.defaultContainerSpecId,
      DEFAULT_OPTIMIZATION_CONFIG
    );
    const recon = reconcileProjectQuantities(
      [...baseProject.skus.slice(0, 2), extraSku],
      preview.proposedContainers
    );
    return {
      ok: recon.totalRemaining === 0 && preview.invalidatedCartons.length === 0,
      msg: `Allocated extra 5 cartons into container space; remaining=${recon.totalRemaining}.`,
    };
  });

  // TC05: Load multiple containers accurately
  exec('TC05', 'Multi-container allocation across container fleet', () => {
    const highQtySkus = baseProject.skus.map((s) => ({
      ...s,
      requiredQty: s.requiredQty * 2,
    }));
    const opt = runOptimization(
      highQtySkus,
      [],
      specs,
      baseProject.defaultContainerSpecId,
      DEFAULT_OPTIMIZATION_CONFIG
    );
    const recon = reconcileProjectQuantities(highQtySkus, opt.containers);
    return {
      ok: opt.containers.length >= 2 && recon.totalRemaining === 0 && !recon.hasDiscrepancies,
      msg: `Allocated ${recon.totalLoaded} cartons across ${opt.containers.length} containers.`,
    };
  });

  // TC06: Validate remaining quantities invariant
  exec('TC06', 'Quantity reconciliation invariant (Req = Loaded + Remaining)', () => {
    const opt = runOptimization(
      baseProject.skus,
      [],
      specs,
      baseProject.defaultContainerSpecId,
      DEFAULT_OPTIMIZATION_CONFIG
    );
    const recon = reconcileProjectQuantities(baseProject.skus, opt.containers);
    const allPass = recon.rows.every(
      (r) =>
        r.requiredQty === r.totalLoadedQty + r.remainingQty &&
        r.remainingQty >= 0 &&
        r.reconciled
    );
    return {
      ok: allPass && !recon.hasDiscrepancies,
      msg: `Verified ${recon.rows.length} SKUs: Req=${recon.totalRequired}, Loaded=${recon.totalLoaded}, Rem=${recon.totalRemaining}.`,
    };
  });

  // TC07: Save and reuse loading template with compatibility check
  exec('TC07', 'Validate & reuse loading template when SKU dimensions match', () => {
    const tpl = SEED_TEMPLATES[0];
    const spec = specs.find((s) => s.code === tpl.containerSpecCode) ?? specs[0];
    const dimsFit =
      tpl.containerLengthMm <= spec.internalLengthMm &&
      tpl.containerWidthMm <= spec.internalWidthMm &&
      tpl.containerHeightMm <= spec.internalHeightMm;
    return {
      ok: dimsFit && tpl.placements.length > 0,
      msg: `Template "${tpl.name}" validated for ${spec.code} (${tpl.placements.length} placements).`,
    };
  });

  // TC08: Manual anchor reposition (Left -> Right -> Center)
  exec('TC08', 'Manual flexible anchor positioning (Left, Right, Center)', () => {
    const opt = runOptimization(
      baseProject.skus.slice(0, 1),
      [],
      specs,
      baseProject.defaultContainerSpecId,
      DEFAULT_OPTIMIZATION_CONFIG
    );
    const spec = specsById.get(opt.containers[0].containerSpecId)!;
    const centered = realignContainerAnchor(opt.containers[0], spec, 'center');
    const rightAligned = realignContainerAnchor(opt.containers[0], spec, 'right');
    const issuesCenter = validateProject([centered], specsById, baseProject.skus, DEFAULT_OPTIMIZATION_CONFIG);
    const issuesRight = validateProject([rightAligned], specsById, baseProject.skus, DEFAULT_OPTIMIZATION_CONFIG);
    return {
      ok:
        issuesCenter.filter((i) => i.severity === 'error').length === 0 &&
        issuesRight.filter((i) => i.severity === 'error').length === 0,
      msg: 'Center and Right wall anchor realignment passed 0 hard constraint errors.',
    };
  });

  // TC09: Validate loading restrictions (reject overlap & non-stackable stacking)
  exec('TC09', 'Independent validator rejects overlap & non-stackable violations', () => {
    const nonStackSku = baseProject.skus.find((s) => !s.stackable) ?? baseProject.skus[0];
    const spec = specs[0];
    const invalidContainer: ContainerLoad = {
      id: 'test-invalid',
      containerSpecId: spec.id,
      label: 'Test Invalid',
      sequenceNumber: 1,
      placements: [
        {
          instanceId: 'p1',
          skuId: nonStackSku.id,
          containerId: 'test-invalid',
          xMm: 0,
          yMm: 0,
          zMm: 0,
          dimXMm: nonStackSku.lengthMm,
          dimYMm: nonStackSku.heightMm,
          dimZMm: nonStackSku.widthMm,
          rotationLabel: 'Std',
          layerIndex: 0,
          anchorMode: 'left',
        },
        {
          instanceId: 'p2',
          skuId: baseProject.skus[0].id,
          containerId: 'test-invalid',
          xMm: 0,
          yMm: nonStackSku.heightMm,
          zMm: 0,
          dimXMm: 500,
          dimYMm: 300,
          dimZMm: 500,
          rotationLabel: 'Std',
          layerIndex: 1,
          anchorMode: 'left',
        },
      ],
    };
    const skuMap = new Map(baseProject.skus.map((s) => [s.id, s]));
    const issues = validateContainerLoad(
      invalidContainer,
      spec,
      skuMap,
      DEFAULT_OPTIMIZATION_CONFIG
    );
    return {
      ok: issues.some((i) => i.severity === 'error'),
      msg: `Validator correctly flagged ${issues.length} violation(s): ${issues[0]?.rule ?? ''}.`,
    };
  });

  // TC10: Export data consistency check
  exec('TC10', 'Export reconciliation totals match saved project state', () => {
    const recon = reconcileProjectQuantities(baseProject.skus, baseProject.containers);
    return {
      ok: recon.rows.length === baseProject.skus.length && !recon.hasDiscrepancies,
      msg: `Verified export payload matches ${recon.rows.length} SKU records with 0 discrepancies.`,
    };
  });

  // TC11: Reopen project preservation
  exec('TC11', 'Structured project serialization & reload fidelity', () => {
    const serialized = JSON.stringify(baseProject);
    const restored = JSON.parse(serialized);
    return {
      ok:
        restored.id === baseProject.id &&
        restored.containers.length === baseProject.containers.length &&
        restored.skus.length === baseProject.skus.length,
      msg: `Round-trip JSON serialization preserved ${restored.containers.length} containers and ${restored.skus.length} SKUs.`,
    };
  });

  // TC12: Handle carton dimension changes
  exec('TC12', 'Dimension change flags invalidated placements for review', () => {
    const opt = runOptimization(
      baseProject.skus,
      [],
      specs,
      baseProject.defaultContainerSpecId,
      DEFAULT_OPTIMIZATION_CONFIG
    );
    const changedSkus = baseProject.skus.map((s, idx) =>
      idx === 0 ? { ...s, lengthMm: s.lengthMm + 250 } : s
    );
    const preview = buildRecalculationPreview(
      changedSkus,
      opt.containers,
      specs,
      baseProject.defaultContainerSpecId,
      DEFAULT_OPTIMIZATION_CONFIG
    );
    return {
      ok: preview.invalidatedCartons.length > 0 && preview.affectedContainerIds.length > 0,
      msg: `Detected ${preview.invalidatedCartons.length} affected placement(s) across ${preview.affectedContainerIds.length} container(s).`,
    };
  });

  return results;
}
