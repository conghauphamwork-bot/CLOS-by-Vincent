// Lớp gọi máy chủ Python (FastAPI). Mọi tính toán nặng + lưu trữ nằm ở máy chủ.
import type {
  BenchmarkTrialRow,
  ContainerSpec,
  LoadingProject,
  LoadingTemplate,
  RecalculationPreview,
  ServerValidation,
} from '../types/clos';

const BASE = '/api/web';

export class ApiConflict extends Error {
  current: LoadingProject | null;
  rev: number | null;
  constructor(message: string, current: LoadingProject | null, rev: number | null) {
    super(message);
    this.current = current;
    this.rev = rev;
  }
}

async function call<T>(method: string, path: string, body?: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(BASE + path, {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new Error('Không kết nối được máy chủ CLOS. Kiểm tra cửa sổ đang chạy start.sh / start.bat.');
  }
  const data = await res.json().catch(() => ({}));
  if (res.status === 409) {
    throw new ApiConflict(data.detail ?? 'Bị từ chối', data.current ?? null, data.rev ?? null);
  }
  if (!res.ok) {
    const d = data.detail;
    throw new Error(typeof d === 'string' ? d : `Lỗi máy chủ (${res.status})`);
  }
  return data as T;
}

export interface ServerState {
  projects: LoadingProject[];
  revs: Record<string, number>;
  specs: ContainerSpec[] | null;
  templates: LoadingTemplate[] | null;
  activeProjectId: string | null;
}

export const api = {
  state: () => call<ServerState>('GET', '/state'),
  saveProject: (project: LoadingProject, baseRev: number | null, note: string, specs: ContainerSpec[]) =>
    call<{ rev: number; validation: ServerValidation | null }>('PUT', `/projects/${encodeURIComponent(project.id)}`, {
      project,
      baseRev,
      note,
      specs,
    }),
  deleteProject: (id: string) => call<{ ok: boolean }>('DELETE', `/projects/${encodeURIComponent(id)}`),
  putKv: (key: 'specs' | 'templates' | 'activeProjectId', value: unknown) =>
    call<{ ok: boolean }>('PUT', `/kv/${key}`, { value }),
  optimize: (project: LoadingProject, specs: ContainerSpec[], mode: 'locked' | 'incremental', seconds?: number) =>
    call<RecalculationPreview>('POST', '/optimize', { project, specs, mode, seconds }),
  validate: (project: LoadingProject, specs: ContainerSpec[]) =>
    call<ServerValidation>('POST', '/validate', { project, specs }),
  benchmark: (project: LoadingProject, specs: ContainerSpec[], seconds: number) =>
    call<BenchmarkTrialRow[]>('POST', '/benchmark', { project, specs, seconds }),
};
