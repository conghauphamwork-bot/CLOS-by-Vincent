// Theo mã CargoWiz: none = 1, upright_only = 2, four_way = 4, all = 6 ('length_width_only' = 2, giữ để đọc dữ liệu cũ)
export type RotationPolicy = 'all' | 'four_way' | 'upright_only' | 'length_width_only' | 'none';

export type AnchorMode = 'left' | 'right' | 'center' | 'free';

export type OptimizationAlgorithm =
  | 'ffd'
  | 'bfd'
  | 'extreme_points'
  | 'maximal_spaces'
  | 'hybrid_alns_ep';

export type AppScreen =
  | 'dashboard'
  | 'workspace'
  | 'projects'
  | 'cargo'
  | 'containers'
  | 'templates'
  | 'reports'
  | 'settings';

export interface CargoSku {
  id: string;
  factorySku: string;
  customerSku: string;
  description: string;
  lengthMm: number;
  widthMm: number;
  heightMm: number;
  weightKg: number;
  requiredQty: number;
  stackable: boolean;
  maxStackLayers: number;
  maxStackWeightKg: number;
  rotationPolicy: RotationPolicy;
  fragile: boolean;
  palletized: boolean;
  palletLengthMm?: number;
  palletWidthMm?: number;
  palletHeightMm?: number;
  color: string;
}

export interface ContainerSpec {
  id: string;
  code: string;
  name: string;
  internalLengthMm: number;
  internalWidthMm: number;
  internalHeightMm: number;
  maxPayloadKg: number;
  tareWeightKg: number;
  doorWidthMm: number;
  doorHeightMm: number;
  isDefault?: boolean;
}

export interface PlacedCarton {
  instanceId: string;
  skuId: string;
  containerId: string;
  xMm: number; // along container length (0 = rear bulkhead, L = doors)
  yMm: number; // vertical height (0 = floor)
  zMm: number; // across container width (0 = left wall, W = right wall)
  dimXMm: number;
  dimYMm: number;
  dimZMm: number;
  rotationLabel: string;
  layerIndex: number;
  anchorMode: AnchorMode;
  locked?: boolean;
}

export interface ContainerStats {
  usedVolumeM3: number;
  totalVolumeM3: number;
  volumeUtilizationPct: number;
  totalCargoWeightKg: number;
  payloadUtilizationPct: number;
  cogXMm: number;
  cogYMm: number;
  cogZMm: number;
  cogLongitudinalOffsetPct: number;
  cogLateralOffsetPct: number;
  cogBalanceOk: boolean;
  totalCartons: number;
  layerCount: number;
}

export interface ContainerLoad {
  id: string;
  containerSpecId: string;
  label: string;
  sequenceNumber: number;
  placements: PlacedCarton[];
  locked?: boolean;
}

export interface ReconciliationRow {
  skuId: string;
  factorySku: string;
  customerSku: string;
  description: string;
  color: string;
  dimensionsLabel: string;
  requiredQty: number;
  perContainerQty: Record<string, number>;
  totalLoadedQty: number;
  remainingQty: number;
  reconciled: boolean;
  status: 'complete' | 'partial' | 'unloaded' | 'overallocated';
}

export type ValidationRuleType =
  | 'boundary'
  | 'overlap'
  | 'rotation'
  | 'stacking'
  | 'payload'
  | 'cog_balance'
  | 'support_stability'
  | 'accessibility'
  | 'quantity';

export interface ValidationIssue {
  id: string;
  severity: 'error' | 'warning';
  rule: ValidationRuleType;
  containerId: string;
  containerLabel: string;
  cartonIds: string[];
  message: string;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  target: string;
  details: string;
}

export interface OptimizationConfig {
  algorithm: OptimizationAlgorithm;
  anchorMode: AnchorMode;
  minSupportRatio: number; // e.g., 0.75
  maxCogOffsetPct: number; // e.g., 15
  respectStacking: boolean;
  respectRotation: boolean;
  respectPayload: boolean;
  prioritizeHeavyBottom: boolean;
  autoAddContainers: boolean;
  alnsIterations: number;
}

export interface OptimizationMetrics {
  algorithm: OptimizationAlgorithm;
  containersUsed: number;
  volumeUtilizationPct: number;
  payloadUtilizationPct: number;
  violationsCount: number;
  computeTimeMs: number;
  feasible: boolean;
  lowerBoundContainers: number;
  optimalityGapPct: number;
  statusLabel: 'Proven Optimal (LB Match)' | 'Best-Known Solution' | 'Feasible Solution' | 'Infeasible';
  explanation: string;
}

export interface LoadingTemplate {
  id: string;
  name: string;
  description: string;
  containerSpecCode: string;
  containerLengthMm: number;
  containerWidthMm: number;
  containerHeightMm: number;
  skuSignatures: Array<{
    factorySku: string;
    customerSku: string;
    lengthMm: number;
    widthMm: number;
    heightMm: number;
    countInTemplate: number;
  }>;
  placements: Array<Omit<PlacedCarton, 'instanceId' | 'containerId'>>;
  createdAt: string;
  utilizationPct: number;
}

export interface LoadingProject {
  id: string;
  code: string;
  name: string;
  customerName: string;
  destinationPort: string;
  status: 'draft' | 'calculated' | 'verified' | 'exported';
  createdAt: string;
  updatedAt: string;
  skus: CargoSku[];
  containers: ContainerLoad[];
  defaultContainerSpecId: string;
  optimizationConfig: OptimizationConfig;
  lastMetrics?: OptimizationMetrics;
  auditTrail: AuditEntry[];
  // Số cont CargoWiz THỰC TẾ cho cùng lô hàng (nhập tay từ file CargoWiz) — dùng để benchmark
  cargowizContainers?: number;
}

export interface RecalculationPreview {
  affectedContainerIds: string[];
  preservedContainerIds: string[];
  invalidatedCartons: Array<{
    containerLabel: string;
    factorySku: string;
    reason: string;
  }>;
  proposedContainers: ContainerLoad[];
  proposedMetrics: OptimizationMetrics;
  summary: string;
  // Kết quả kiểm tra độc lập (Python) cho phương án đề xuất — có khi tính trên máy chủ
  validation?: ServerValidation;
}

// Kết quả validator Python (độc lập với engine, không dùng chung code hình học)
export interface ServerValidation {
  engine?: string;
  checkedAt?: string;
  ok: boolean;
  errors: number;
  warnings: number;
  checked?: string[];
  skipped?: Array<{ code: string; reason: string }>;
  issues: Array<ValidationIssue & { code?: string }>;
  error?: string;
}

export interface BenchmarkTrialRow {
  algorithmId: string;
  algorithmName: string;
  category: string;
  containersUsed: number;
  avgVolumePct: number;
  bestVolumePct: number;
  worstVolumePct: number;
  payloadPct: number;
  violations: number;
  computeTimeMs: number;
  feasible: boolean;
  optimalityGapPct: number;
  statusLabel: string;
  notes: string;
}

export interface ExcelImportRowError {
  rowNumber: number;
  factorySku: string;
  field: string;
  message: string;
}

export interface ExcelImportResult {
  validSkus: CargoSku[];
  errors: ExcelImportRowError[];
  duplicateSkus: string[];
  totalRowsRead: number;
}
