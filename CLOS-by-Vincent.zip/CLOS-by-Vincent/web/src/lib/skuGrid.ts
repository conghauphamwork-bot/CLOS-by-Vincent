// Định nghĩa cột dùng chung cho mọi bảng mã hàng (Dữ liệu hàng, Chú giải hàng ở màn 3D…)
import type { CargoSku } from '../types/clos';
import type { CellValue, GridColumn } from '../components/common/EditableGrid';

export type SkuField =
  | 'factorySku'
  | 'customerSku'
  | 'description'
  | 'lengthMm'
  | 'widthMm'
  | 'heightMm'
  | 'weightKg'
  | 'requiredQty'
  | 'stackable'
  | 'rotationPolicy'
  | 'maxStackLayers';

// Thứ tự cột = thứ tự khi dán từ Excel
export const SKU_FIELDS: Array<{
  key: SkuField;
  header: string;
  kind: GridColumn<unknown>['kind'];
  width: string;
  align?: 'left' | 'right' | 'center';
  optional?: boolean;
  min?: number;
  title?: string;
  mono?: boolean;
}> = [
  { key: 'factorySku', header: 'Mã nhà máy', kind: 'text', width: 'w-36', mono: true },
  { key: 'customerSku', header: 'Mã khách', kind: 'text', width: 'w-32', mono: true, optional: true },
  { key: 'description', header: 'Mô tả', kind: 'text', width: 'w-56', optional: true },
  { key: 'lengthMm', header: 'Dài (mm)', kind: 'int', width: 'w-16', align: 'right', min: 1 },
  { key: 'widthMm', header: 'Rộng (mm)', kind: 'int', width: 'w-16', align: 'right', min: 1 },
  { key: 'heightMm', header: 'Cao (mm)', kind: 'int', width: 'w-16', align: 'right', min: 1 },
  { key: 'weightKg', header: 'Kg/thùng', kind: 'num', width: 'w-16', align: 'right', optional: true, min: 0 },
  { key: 'requiredQty', header: 'Số lượng', kind: 'int', width: 'w-16', align: 'right', min: 0 },
  {
    key: 'stackable',
    header: 'Chồng được',
    kind: 'bool',
    width: 'w-10',
    align: 'center',
    title: 'Được đặt hàng khác lên trên. Khi dán: Có/Không, Y/N, 1/0',
  },
  {
    key: 'rotationPolicy',
    header: 'Xoay',
    kind: 'rotation',
    width: 'w-10',
    align: 'center',
    title:
      'Mã xoay CargoWiz — 1: không xoay · 2: chỉ đảo Dài/Rộng (luôn đứng) · 4: được nằm nghiêng nhưng không dựng Dài lên · 6: mọi hướng',
  },
  {
    key: 'maxStackLayers',
    header: 'Lớp tối đa',
    kind: 'int',
    width: 'w-12',
    align: 'center',
    optional: true,
    min: 1,
    title:
      'Số tầng tối đa của mã này tính từ sàn, theo chiều cao lúc đặt (thùng nằm thấp thì được nhiều tầng hơn thùng dựng). ĐỂ TRỐNG = không giới hạn.',
  },
];

export const REQUIRED_NEW: SkuField[] = ['factorySku', 'lengthMm', 'widthMm', 'heightMm', 'requiredQty'];

export function skuColumns<R>(
  get: (row: R) => Partial<Record<SkuField, CellValue>> | undefined,
  readOnly?: Partial<Record<SkuField, boolean>>
): GridColumn<R>[] {
  return SKU_FIELDS.map((f) => ({
    key: f.key,
    header: f.header,
    kind: f.kind,
    width: f.width,
    align: f.align,
    optional: f.optional,
    min: f.min,
    title: f.title,
    mono: f.mono,
    readOnly: readOnly?.[f.key],
    get: (row: R) => {
      const v = get(row)?.[f.key] ?? null;
      // 99 (hoặc lớn hơn) = không giới hạn -> hiện ô trống
      if (f.key === 'maxStackLayers' && (v === null || (typeof v === 'number' && v >= 99))) return null;
      return v;
    },
  }));
}

/** Gán 1 giá trị vào mã hàng (giữ các trường phụ thuộc cho nhất quán). */
export function applySkuValue(sku: CargoSku, key: string, value: CellValue): CargoSku {
  const next = { ...sku, [key]: value } as CargoSku;
  if (key === 'weightKg') next.weightKg = typeof value === 'number' ? value : 0;
  if (key === 'customerSku' || key === 'description') (next as unknown as Record<string, string>)[key] = String(value ?? '');
  if (key === 'maxStackLayers') next.maxStackLayers = typeof value === 'number' && value > 0 ? value : 99;
  if (key === 'stackable') {
    next.maxStackLayers = value ? 99 : 1;
    next.maxStackWeightKg = value ? Math.max(sku.maxStackWeightKg || 0, 200) : 0;
  }
  return next;
}
