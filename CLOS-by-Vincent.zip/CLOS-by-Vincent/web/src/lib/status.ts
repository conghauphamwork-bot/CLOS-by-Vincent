// Trạng thái lời giải (giá trị trao đổi với máy chủ giữ tiếng Anh; chỉ dịch khi hiển thị)
const STATUS_VI: Record<string, string> = {
  'Proven Optimal (LB Match)': 'Đã chứng minh tối ưu (bằng cận dưới)',
  'Best-Known Solution': 'Phương án tốt nhất tìm được',
  'Feasible Solution': 'Hợp lệ, chưa chứng minh tối ưu',
  Infeasible: 'Không hợp lệ / chưa xếp đủ',
  'Lower Bound': 'Cận dưới',
};
export const statusVi = (s?: string | null) => (s ? STATUS_VI[s] ?? s : '');
