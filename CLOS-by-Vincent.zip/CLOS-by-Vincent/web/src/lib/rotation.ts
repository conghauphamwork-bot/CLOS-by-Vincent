// Mã hướng xoay theo CargoWiz: 1 / 2 / 4 / 6
import type { RotationPolicy } from '../types/clos';

export type RotationCode = 1 | 2 | 4 | 6;

export const ROTATION_CODES: Array<{
  code: RotationCode;
  policy: RotationPolicy;
  label: string;
  hint: string;
}> = [
  { code: 1, policy: 'none', label: '1', hint: '1 hướng – không xoay. Chiều Rộng nằm ngang cont.' },
  { code: 2, policy: 'upright_only', label: '2', hint: '2 hướng – chỉ xoay ngang (đảo Dài/Rộng), Cao luôn đứng.' },
  { code: 4, policy: 'four_way', label: '4', hint: '4 hướng – được nằm nghiêng, nhưng không dựng cạnh Dài lên làm chiều cao.' },
  { code: 6, policy: 'all', label: '6', hint: '6 hướng – xoay mọi hướng.' },
];

export function policyToCode(p: RotationPolicy | undefined): RotationCode {
  switch (p) {
    case 'none':
      return 1;
    case 'four_way':
      return 4;
    case 'all':
      return 6;
    case 'upright_only':
    case 'length_width_only':
    default:
      return 2;
  }
}

export function codeToPolicy(code: number): RotationPolicy | null {
  return ROTATION_CODES.find((r) => r.code === code)?.policy ?? null;
}

/** Đọc mã xoay từ ô Excel / ô nhập: nhận 1/2/4/6 và một số chữ quen dùng. */
export function parseRotation(raw: unknown): RotationPolicy | null {
  if (raw === undefined || raw === null) return null;
  const s = String(raw).trim().toLowerCase().replace(/[\s_-]+/g, '');
  if (s === '') return null;
  const m = s.match(/^([1246])(way|ways|huong|hướng)?$/);
  if (m) return codeToPolicy(Number(m[1]));
  if (['all', 'any', 'free', '3d', 'tựdo', 'tudo'].includes(s)) return 'all';
  if (['upright', 'uprightonly', 'thiswayup', 'lw', 'lxw', 'l×w', 'đứng', 'dung'].includes(s)) return 'upright_only';
  if (['none', 'fixed', 'locked', 'khôngxoay', 'khongxoay', 'cốđịnh', 'codinh'].includes(s)) return 'none';
  return null;
}

export function rotationHint(p: RotationPolicy): string {
  return ROTATION_CODES.find((r) => r.code === policyToCode(p))!.hint;
}
