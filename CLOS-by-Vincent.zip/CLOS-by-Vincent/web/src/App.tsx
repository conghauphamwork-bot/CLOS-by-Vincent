import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bookmark,
  Box,
  Container,
  FileSpreadsheet,
  FolderKanban,
  LayoutDashboard,
  Package,
  SlidersHorizontal,
  Undo2,
  Redo2,
} from 'lucide-react';
import {
  DEFAULT_CONTAINERS,
  SEED_PROJECTS,
  SEED_TEMPLATES,
} from './data/seedProjects';
import {
  AppScreen,
  CargoSku,
  ContainerLoad,
  ContainerSpec,
  LoadingProject,
  LoadingTemplate,
  OptimizationConfig,
  ServerValidation,
} from './types/clos';
import { api, ApiConflict } from './api/client';
import { DashboardScreen } from './components/screens/DashboardScreen';
import { ProjectsScreen } from './components/screens/ProjectsScreen';
import { CargoManagementScreen } from './components/screens/CargoManagementScreen';
import { ContainersScreen } from './components/screens/ContainersScreen';
import { TemplatesScreen } from './components/screens/TemplatesScreen';
import { ReportsScreen } from './components/screens/ReportsScreen';
import { SettingsBenchmarkScreen } from './components/screens/SettingsBenchmarkScreen';
import { LoadingWorkspace } from './components/workspace/LoadingWorkspace';
import { ContainerScene3DHandle } from './components/workspace/ContainerScene3D';
import { exportProjectToPdf } from './engine/pdfService';

const STORAGE_KEYS = {
  projects: 'clos_projects_v1',
  specs: 'clos_specs_v1',
  templates: 'clos_templates_v1',
  activeProjectId: 'clos_active_project_v1',
};

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

const HISTORY_LIMIT = 60;

export default function App() {
  const [screen, setScreen] = useState<AppScreen>('workspace');
  // Dữ liệu nằm trên máy chủ (SQLite). Trình duyệt chỉ giữ bản đang làm việc.
  const [loaded, setLoaded] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [projects, setProjects] = useState<LoadingProject[]>([]);
  const [specs, setSpecs] = useState<ContainerSpec[]>(DEFAULT_CONTAINERS);
  const [templates, setTemplates] = useState<LoadingTemplate[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<string>('');
  const [serverValidation, setServerValidation] = useState<
    Record<string, ServerValidation>
  >({});
  const [syncState, setSyncState] = useState<'idle' | 'saving' | 'error'>('idle');
  // lịch sử tiến/lùi theo từng dự án (giữ trong phiên làm việc)
  const historyRef = useRef<{
    past: Map<string, Array<{ project: LoadingProject; label: string }>>;
    future: Map<string, Array<{ project: LoadingProject; label: string }>>;
  }>({ past: new Map(), future: new Map() });
  const [, setHistoryTick] = useState(0);
  const activeProjectIdRef = useRef<string>('');

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const sceneRef = useRef<ContainerScene3DHandle | null>(null);
  const lastSnapshotRef = useRef<string | null>(null);

  // --- đồng bộ với máy chủ ---------------------------------------------------
  const projectsRef = useRef<LoadingProject[]>(projects);
  projectsRef.current = projects;
  const specsRef = useRef<ContainerSpec[]>(specs);
  specsRef.current = specs;
  const syncedRef = useRef<Map<string, LoadingProject>>(new Map());
  const revRef = useRef<Map<string, number | null>>(new Map());
  const timersRef = useRef<Map<string, number>>(new Map());
  const chainRef = useRef<Map<string, Promise<void>>>(new Map());
  const kvSyncedRef = useRef<{ specs?: unknown; templates?: unknown; active?: unknown }>({});

  const notify = (msg: string, ms = 3500) => {
    setToastMessage(msg);
    window.setTimeout(() => {
      setToastMessage((curr) => (curr === msg ? null : curr));
    }, ms);
  };

  const flushProject = async (id: string) => {
    const p = projectsRef.current.find((x) => x.id === id);
    if (!p || syncedRef.current.get(id) === p) return;
    const note = p.auditTrail[p.auditTrail.length - 1]?.details ?? '';
    setSyncState('saving');
    try {
      const r = await api.saveProject(p, revRef.current.get(id) ?? null, note, specsRef.current);
      revRef.current.set(id, r.rev);
      syncedRef.current.set(id, p);
      if (r.validation) {
        setServerValidation((v) => ({ ...v, [id]: r.validation! }));
      }
      setSyncState('idle');
    } catch (e) {
      if (e instanceof ApiConflict) {
        // Máy chủ từ chối (sai số lượng / bị sửa nơi khác): quay về bản máy chủ đang giữ
        setSyncState('idle');
        if (e.current) {
          revRef.current.set(id, e.rev);
          syncedRef.current.set(id, e.current);
          setProjects((prev) => prev.map((x) => (x.id === id ? e.current! : x)));
        } else {
          syncedRef.current.set(id, p);
        }
        notify(`⚠ ${e.message}`, 9000);
      } else {
        setSyncState('error');
        notify(`⚠ Chưa lưu được: ${(e as Error).message}`, 9000);
        window.setTimeout(() => scheduleSave(id), 5000);
      }
    }
  };

  const scheduleSave = (id: string) => {
    const t = timersRef.current.get(id);
    if (t) window.clearTimeout(t);
    timersRef.current.set(
      id,
      window.setTimeout(() => {
        timersRef.current.delete(id);
        const prev = chainRef.current.get(id) ?? Promise.resolve();
        const next = prev.then(() => flushProject(id));
        chainRef.current.set(id, next);
        next.then(() => {
          const latest = projectsRef.current.find((x) => x.id === id);
          if (latest && syncedRef.current.get(id) !== latest) scheduleSave(id);
        });
      }, 350)
    );
  };

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const st = await api.state();
        const sp = st.specs ?? DEFAULT_CONTAINERS;
        const tp = st.templates ?? SEED_TEMPLATES;
        let projs = st.projects;
        if (projs.length === 0) {
          // Lần chạy đầu: nạp dữ liệu mẫu của bản AI Studio lên máy chủ
          const seeds = loadFromStorage(STORAGE_KEYS.projects, SEED_PROJECTS);
          const ok: LoadingProject[] = [];
          for (const p of seeds) {
            try {
              const r = await api.saveProject(p, null, 'Khởi tạo dữ liệu mẫu', sp);
              revRef.current.set(p.id, r.rev);
              ok.push(p);
            } catch (e) {
              // Dữ liệu mẫu vi phạm luật số lượng -> nạp phần mã hàng, bỏ phương án cũ
              const clean = { ...p, containers: [], status: 'draft' as const };
              const r = await api.saveProject(clean, null, `Khởi tạo (bỏ phương án mẫu: ${(e as Error).message})`, sp);
              revRef.current.set(p.id, r.rev);
              ok.push(clean);
            }
          }
          projs = ok;
        } else {
          for (const [id, rev] of Object.entries(st.revs)) revRef.current.set(id, rev);
        }
        if (cancelled) return;
        for (const p of projs) syncedRef.current.set(p.id, p);
        kvSyncedRef.current = { specs: st.specs ? sp : undefined, templates: st.templates ? tp : undefined, active: st.activeProjectId };
        setSpecs(sp);
        setTemplates(tp);
        setProjects(projs);
        setActiveProjectId(
          st.activeProjectId && projs.some((p) => p.id === st.activeProjectId)
            ? st.activeProjectId
            : projs[0]?.id ?? ''
        );
        setLoaded(true);
      } catch (e) {
        if (!cancelled) setLoadError((e as Error).message);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!loaded) return;
    const ids = new Set(projects.map((p) => p.id));
    for (const p of projects) {
      if (syncedRef.current.get(p.id) !== p) scheduleSave(p.id);
    }
    for (const id of Array.from(syncedRef.current.keys())) {
      if (!ids.has(id)) {
        syncedRef.current.delete(id);
        api.deleteProject(id).catch((e) => notify(`⚠ ${(e as Error).message}`, 9000));
      }
    }
  }, [projects, loaded]);

  useEffect(() => {
    if (!loaded || kvSyncedRef.current.specs === specs) return;
    kvSyncedRef.current.specs = specs;
    api.putKv('specs', specs).catch((e) => notify(`⚠ ${(e as Error).message}`, 9000));
  }, [specs, loaded]);

  useEffect(() => {
    if (!loaded || kvSyncedRef.current.templates === templates) return;
    kvSyncedRef.current.templates = templates;
    api.putKv('templates', templates).catch((e) => notify(`⚠ ${(e as Error).message}`, 9000));
  }, [templates, loaded]);

  useEffect(() => {
    if (!loaded || kvSyncedRef.current.active === activeProjectId) return;
    kvSyncedRef.current.active = activeProjectId;
    api.putKv('activeProjectId', activeProjectId).catch(() => undefined);
  }, [activeProjectId, loaded]);

  // Kiểm tra độc lập (Python) cho dự án đang mở nếu chưa có kết quả
  useEffect(() => {
    if (!loaded || !activeProjectId || serverValidation[activeProjectId]) return;
    const p = projectsRef.current.find((x) => x.id === activeProjectId);
    if (!p) return;
    api
      .validate(p, specs)
      .then((v) => setServerValidation((s) => ({ ...s, [activeProjectId]: v })))
      .catch(() => undefined);
  }, [activeProjectId, loaded]);

  const activeProject = useMemo(
    () => projects.find((p) => p.id === activeProjectId) ?? projects[0],
    [projects, activeProjectId]
  );
  activeProjectIdRef.current = activeProject?.id ?? '';
  const undoList = activeProject ? historyRef.current.past.get(activeProject.id) ?? [] : [];
  const redoList = activeProject ? historyRef.current.future.get(activeProject.id) ?? [] : [];
  const activeValidation = activeProject
    ? serverValidation[activeProject.id]
    : undefined;

  const specsById = useMemo(
    () => new Map(specs.map((s) => [s.id, s])),
    [specs]
  );

  const updateProjectWithAudit = (
    updated: LoadingProject,
    auditNote?: string
  ) => {
    const nextAudit = auditNote
      ? [
          ...updated.auditTrail,
          {
            id: `aud-${Date.now().toString(36)}`,
            timestamp: new Date().toISOString(),
            actor: 'Người dùng',
            action: 'PROJECT_UPDATE',
            target: updated.code,
            details: auditNote,
          },
        ]
      : updated.auditTrail;

    const finalProj: LoadingProject = {
      ...updated,
      auditTrail: nextAudit,
      updatedAt: new Date().toISOString(),
    };

    // Lịch sử tiến/lùi: lưu bản TRƯỚC khi sửa, xoá nhánh "tiến" cũ
    const before = projectsRef.current.find((p) => p.id === finalProj.id);
    if (before) {
      const past = historyRef.current.past.get(finalProj.id) ?? [];
      past.push({ project: before, label: auditNote ?? 'Thay đổi' });
      if (past.length > HISTORY_LIMIT) past.shift();
      historyRef.current.past.set(finalProj.id, past);
      historyRef.current.future.set(finalProj.id, []);
      setHistoryTick((t) => t + 1);
    }

    setProjects((prev) =>
      prev.map((p) => (p.id === finalProj.id ? finalProj : p))
    );
  };

  // ---- Tiến / lùi ----------------------------------------------------------
  const stepHistory = (dir: 'undo' | 'redo') => {
    const id = activeProjectIdRef.current;
    const cur = projectsRef.current.find((p) => p.id === id);
    if (!cur) return;
    const from = dir === 'undo' ? historyRef.current.past : historyRef.current.future;
    const to = dir === 'undo' ? historyRef.current.future : historyRef.current.past;
    const stack = from.get(id) ?? [];
    const entry = stack.pop();
    if (!entry) return;
    from.set(id, stack);
    // Nhật ký chỉ cộng thêm, không bao giờ mất dòng nào khi lùi/tiến
    const restored: LoadingProject = {
      ...entry.project,
      auditTrail: [
        ...cur.auditTrail,
        {
          id: `aud-${Date.now().toString(36)}`,
          timestamp: new Date().toISOString(),
          actor: 'Người dùng',
          action: 'PROJECT_UPDATE',
          target: cur.code,
          details: `${dir === 'undo' ? 'Lùi lại' : 'Làm lại'}: ${entry.label}`,
        },
      ],
      updatedAt: new Date().toISOString(),
    };
    to.set(id, [...(to.get(id) ?? []), { project: cur, label: entry.label }]);
    setHistoryTick((t) => t + 1);
    setProjects((prev) => prev.map((p) => (p.id === id ? restored : p)));
    notify(`${dir === 'undo' ? '↶ Đã lùi' : '↷ Đã làm lại'}: ${entry.label}`, 2500);
  };
  const stepHistoryRef = useRef(stepHistory);
  stepHistoryRef.current = stepHistory;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!(e.ctrlKey || e.metaKey)) return;
      const t = e.target as HTMLElement | null;
      // đang gõ trong ô nhập: để trình duyệt tự hoàn tác chữ
      if (t && (t.tagName === 'TEXTAREA' || t.isContentEditable || (t.tagName === 'INPUT' && (t as HTMLInputElement).type !== 'checkbox'))) return;
      const k = e.key.toLowerCase();
      if (k === 'z' && !e.shiftKey) {
        e.preventDefault();
        stepHistoryRef.current('undo');
      } else if ((k === 'z' && e.shiftKey) || k === 'y') {
        e.preventDefault();
        stepHistoryRef.current('redo');
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const handleSaveTemplateFromContainer = (
    container: ContainerLoad,
    spec: ContainerSpec
  ) => {
    const skuMap = new Map(activeProject.skus.map((s) => [s.id, s]));
    const countMap = new Map<string, number>();
    for (const p of container.placements) {
      countMap.set(p.skuId, (countMap.get(p.skuId) ?? 0) + 1);
    }
    const usedVol = container.placements.reduce(
      (s, p) => s + p.dimXMm * p.dimYMm * p.dimZMm,
      0
    );
    const totalVol =
      spec.internalLengthMm * spec.internalWidthMm * spec.internalHeightMm;

    const newTpl: LoadingTemplate = {
      id: `tpl-${Date.now().toString(36)}`,
      name: `${spec.code} Mẫu xếp — ${activeProject.code} (${container.label})`,
      description: `Lưu từ ${activeProject.name} gồm ${container.placements.length} thùng.`,
      containerSpecCode: spec.code,
      containerLengthMm: spec.internalLengthMm,
      containerWidthMm: spec.internalWidthMm,
      containerHeightMm: spec.internalHeightMm,
      skuSignatures: Array.from(countMap.entries())
        .map(([skuId, cnt]) => {
          const sku = skuMap.get(skuId);
          if (!sku) return null;
          return {
            factorySku: sku.factorySku,
            customerSku: sku.customerSku,
            lengthMm: sku.lengthMm,
            widthMm: sku.widthMm,
            heightMm: sku.heightMm,
            countInTemplate: cnt,
          };
        })
        .filter((x): x is NonNullable<typeof x> => x !== null),
      placements: container.placements.map(
        ({ instanceId: _i, containerId: _c, ...rest }) => rest
      ),
      createdAt: new Date().toISOString(),
      utilizationPct: totalVol > 0 ? (usedVol / totalVol) * 100 : 0,
    };

    setTemplates((prev) => [newTpl, ...prev]);
    notify(`Đã lưu mẫu xếp "${newTpl.name}"`);
  };

  const get3DSnapshot = () => {
    const live = sceneRef.current?.captureSnapshot();
    if (live) {
      lastSnapshotRef.current = live;
      return live;
    }
    return lastSnapshotRef.current;
  };

  const handleQuickExportPdf = () => {
    const qtyErr = activeValidation?.issues.find(
      (i) => i.code === 'V9' && i.severity === 'error'
    );
    if (qtyErr) {
      notify(
        `⚠ Chưa xuất được: ${qtyErr.message}. Bấm Recalculate để xử lý số lượng trước.`,
        9000
      );
      return;
    }
    if (
      activeValidation &&
      activeValidation.errors > 0 &&
      !window.confirm(
        `Kiểm tra độc lập (Python) đang báo ${activeValidation.errors} lỗi. Vẫn xuất load plan?`
      )
    ) {
      return;
    }
    const snap = get3DSnapshot();
    exportProjectToPdf(activeProject, specsById, { snapshotDataUrl: snap });
    updateProjectWithAudit(
      { ...activeProject, status: 'exported' },
      'Đã xuất PDF kế hoạch xếp (tất cả cont)'
    );
    notify(`Đã xuất ${activeProject.code}_KeHoachXep_TatCaCont_CLOSbyVincent.pdf`);
  };

  const navItems: Array<{
    id: AppScreen;
    label: string;
    icon: React.FC<{ className?: string }>;
  }> = [
    { id: 'dashboard', label: 'Tổng quan', icon: LayoutDashboard },
    { id: 'workspace', label: 'Xếp hàng 3D', icon: Box },
    { id: 'projects', label: 'Dự án xếp hàng', icon: FolderKanban },
    { id: 'cargo', label: 'Dữ liệu hàng', icon: Package },
    { id: 'containers', label: 'Loại container', icon: Container },
    { id: 'templates', label: 'Thư viện mẫu xếp', icon: Bookmark },
    { id: 'reports', label: 'Báo cáo & xuất file', icon: FileSpreadsheet },
    { id: 'settings', label: 'Luật xếp hàng', icon: SlidersHorizontal },
  ];

  if (!loaded || !activeProject) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 text-slate-700 p-6">
        <div className="max-w-md text-center space-y-2">
          <p className="text-base font-bold text-slate-900">CLOS by Vincent</p>
          {loadError ? (
            <>
              <p className="text-sm text-red-700">{loadError}</p>
              <p className="text-xs text-slate-500">
                Mở cửa sổ đã chạy start.sh / start.bat và kiểm tra máy chủ Python còn chạy, rồi tải lại trang.
              </p>
            </>
          ) : (
            <p className="text-sm">Đang tải dữ liệu từ máy chủ…</p>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Top Bar Contract: 3 clean zones separated by gap-8 */}
      <header className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between gap-8 sticky top-0 z-30 no-print">
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setScreen('dashboard');
          }}
          className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
        >
          CLOS by Vincent
        </a>

        <nav className="hidden lg:flex items-center gap-6 text-xs font-medium text-slate-600">
          <button
            onClick={() => setScreen('workspace')}
            className={`hover:text-slate-900 whitespace-nowrap shrink-0 ${
              screen === 'workspace' ? 'text-slate-900 underline underline-offset-4' : ''
            }`}
          >
            Xếp hàng 3D
          </button>
          <button
            onClick={() => setScreen('cargo')}
            className={`hover:text-slate-900 whitespace-nowrap shrink-0 ${
              screen === 'cargo' ? 'text-slate-900 underline underline-offset-4' : ''
            }`}
          >
            Dữ liệu hàng
          </button>
          <button
            onClick={() => setScreen('templates')}
            className={`hover:text-slate-900 whitespace-nowrap shrink-0 ${
              screen === 'templates' ? 'text-slate-900 underline underline-offset-4' : ''
            }`}
          >
            Mẫu xếp
          </button>
          <button
            onClick={() => setScreen('reports')}
            className={`hover:text-slate-900 whitespace-nowrap shrink-0 ${
              screen === 'reports' ? 'text-slate-900 underline underline-offset-4' : ''
            }`}
          >
            Báo cáo
          </button>
          <button
            onClick={() => setScreen('settings')}
            className={`hover:text-slate-900 whitespace-nowrap shrink-0 ${
              screen === 'settings' ? 'text-slate-900 underline underline-offset-4' : ''
            }`}
          >
            Luật xếp hàng
          </button>
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-1">
            <button
              onClick={() => stepHistory('undo')}
              disabled={!undoList.length}
              title={undoList.length ? `Lùi lại (Ctrl+Z): ${undoList[undoList.length - 1].label}` : 'Chưa có gì để lùi'}
              className="p-1.5 rounded-md border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Undo2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => stepHistory('redo')}
              disabled={!redoList.length}
              title={redoList.length ? `Làm lại (Ctrl+Y): ${redoList[redoList.length - 1].label}` : 'Chưa có gì để làm lại'}
              className="p-1.5 rounded-md border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Redo2 className="w-4 h-4" />
            </button>
          </div>
          <span
            className={`text-[11px] whitespace-nowrap ${
              syncState === 'error'
                ? 'text-red-700'
                : syncState === 'saving'
                  ? 'text-amber-700'
                  : 'text-emerald-700'
            }`}
            title="Dữ liệu được lưu trên máy chủ CLOS (SQLite), mỗi lần lưu giữ lại 1 bản cũ"
          >
            {syncState === 'error' ? '● Chưa lưu' : syncState === 'saving' ? '● Đang lưu…' : '● Đã lưu'}
          </span>
          <button
            onClick={handleQuickExportPdf}
            className="px-4 py-2 text-xs font-medium bg-slate-900 text-white rounded-md hover:bg-slate-800 whitespace-nowrap shrink-0"
          >
            Xuất kế hoạch xếp
          </button>
        </div>
      </header>

      {/* Main Workspace Frame: Left Sidebar + Main Content */}
      <div className="flex-1 flex flex-col lg:flex-row">
        {/* Left Navigation Sidebar */}
        <aside className="lg:w-56 bg-white border-b lg:border-b-0 lg:border-r border-slate-200 p-3 shrink-0 no-print">
          <div className="mb-3 px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-md">
            <p className="text-[11px] text-slate-500">Dự án đang mở</p>
            <p className="text-xs font-mono font-semibold text-slate-900 truncate">
              {activeProject.code}
            </p>
            <p className="text-[11px] text-slate-600 truncate">
              {activeProject.customerName}
            </p>
          </div>

          <nav className="flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = screen === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    if (screen === 'workspace' && item.id !== 'workspace') {
                      const snap = sceneRef.current?.captureSnapshot();
                      if (snap) lastSnapshotRef.current = snap;
                    }
                    setScreen(item.id);
                  }}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-md text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                    isActive
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </aside>

        {/* Primary Content Viewport */}
        <main className="flex-1 p-4 lg:p-6 min-w-0">
          {screen === 'dashboard' && (
            <DashboardScreen
              projects={projects}
              activeProject={activeProject}
              specs={specs}
              onSelectProject={setActiveProjectId}
              onNavigate={setScreen}
            />
          )}

          {screen === 'workspace' && (
            <LoadingWorkspace
              project={activeProject}
              specs={specs}
              onUpdateProject={updateProjectWithAudit}
              onSaveTemplateFromContainer={handleSaveTemplateFromContainer}
              sceneRef={sceneRef}
              serverValidation={activeValidation}
              onNotify={notify}
            />
          )}

          {screen === 'projects' && (
            <ProjectsScreen
              onUpdateProject={(p, note) => updateProjectWithAudit(p, note)}
              projects={projects}
              activeProjectId={activeProject.id}
              specs={specs}
              onSelectProject={setActiveProjectId}
              onCreateProject={(proj) => {
                setProjects((prev) => [proj, ...prev]);
                setActiveProjectId(proj.id);
                notify(`Đã tạo dự án ${proj.code}`);
              }}
              onDuplicateProject={(id) => {
                const orig = projects.find((p) => p.id === id);
                if (!orig) return;
                const copy: LoadingProject = {
                  ...orig,
                  id: `proj-${Date.now().toString(36)}`,
                  code: `${orig.code}-COPY`,
                  name: `${orig.name} (Bản sao)`,
                  createdAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString(),
                  auditTrail: [
                    ...orig.auditTrail,
                    {
                      id: `aud-${Date.now()}`,
                      timestamp: new Date().toISOString(),
                      actor: 'Người dùng',
                      action: 'DUPLICATE',
                      target: orig.code,
                      details: `Nhân bản từ ${orig.code}`,
                    },
                  ],
                };
                setProjects((prev) => [copy, ...prev]);
                setActiveProjectId(copy.id);
                notify(`Đã nhân bản ${orig.code}`);
              }}
              onDeleteProject={(id) => {
                const target = projects.find((p) => p.id === id);
                if (projects.length <= 1) {
                  notify('Không xoá được dự án cuối cùng. Tạo dự án khác trước.', 6000);
                  return;
                }
                if (
                  !window.confirm(
                    `Xoá dự án ${target?.code ?? id}?\n(Máy chủ vẫn giữ lịch sử, có thể khôi phục.)`
                  )
                ) {
                  return;
                }
                const remaining = projects.filter((p) => p.id !== id);
                setProjects(remaining);
                if (activeProjectId === id && remaining[0]) {
                  setActiveProjectId(remaining[0].id);
                }
                notify('Đã xoá dự án');
              }}
              onOpenWorkspace={() => setScreen('workspace')}
            />
          )}

          {screen === 'cargo' && (
            <CargoManagementScreen
              project={activeProject}
              onUpdateSkus={(skus: CargoSku[], auditNote: string) => {
                updateProjectWithAudit({ ...activeProject, skus }, auditNote);
                notify(auditNote);
              }}
              onGoToWorkspace={() => setScreen('workspace')}
              onDeleteSkus={(ids: string[]) => {
                // Xoá mã + gỡ luôn các thùng của mã đó (không để thùng "mồ côi"); bỏ cont trống chưa khoá
                const del = new Set(ids);
                const blocked = activeProject.containers.filter(
                  (c) => c.locked && c.placements.some((pl) => del.has(pl.skuId))
                );
                if (blocked.length) {
                  notify(
                    `⚠ Mã cần xoá đang nằm trong cont đã khoá (${blocked.map((c) => c.label).join(', ')}). Mở khoá các cont đó trước.`,
                    8000
                  );
                  return false;
                }
                const removedCartons = activeProject.containers.reduce(
                  (a, c) => a + c.placements.filter((pl) => del.has(pl.skuId)).length,
                  0
                );
                const kept = activeProject.containers
                  .map((c) => ({ ...c, placements: c.placements.filter((pl) => !del.has(pl.skuId)) }))
                  .filter((c) => c.placements.length > 0 || c.locked);
                const relabeled = kept.map((c, i) => {
                  const spec = specs.find((sp) => sp.id === c.containerSpecId);
                  return { ...c, sequenceNumber: i + 1, label: `Container #${i + 1} (${spec?.code ?? ''})` };
                });
                const names = activeProject.skus.filter((sk) => del.has(sk.id)).map((sk) => sk.factorySku);
                const note = `Xoá ${names.length} mã${removedCartons ? ` (gỡ ${removedCartons} thùng khỏi cont)` : ''}: ${names
                  .slice(0, 6)
                  .join(', ')}${names.length > 6 ? '…' : ''}`;
                updateProjectWithAudit(
                  {
                    ...activeProject,
                    skus: activeProject.skus.filter((sk) => !del.has(sk.id)),
                    containers: relabeled,
                    status: removedCartons ? 'draft' : activeProject.status,
                  },
                  note
                );
                notify(`${note}. Bấm ↶ (Ctrl+Z) nếu xoá nhầm.`, 6000);
                return true;
              }}
            />
          )}

          {screen === 'containers' && (
            <ContainersScreen
              specs={specs}
              activeProject={activeProject}
              onUpdateSpecs={setSpecs}
              onSetProjectDefaultSpec={(specId) => {
                updateProjectWithAudit(
                  { ...activeProject, defaultContainerSpecId: specId },
                  `Đổi loại cont mặc định sang ${specsById.get(specId)?.code ?? specId}`
                );
                notify('Đã đổi loại cont mặc định');
              }}
            />
          )}

          {screen === 'templates' && (
            <TemplatesScreen
              templates={templates}
              activeProject={activeProject}
              specs={specs}
              onApplyTemplate={(newContainer, templateName) => {
                updateProjectWithAudit(
                  {
                    ...activeProject,
                    containers: [...activeProject.containers, newContainer],
                  },
                  `Áp dụng mẫu xếp "${templateName}" thành ${newContainer.label}`
                );
                notify(`Đã áp dụng mẫu "${templateName}"`);
                setScreen('workspace');
              }}
              onDeleteTemplate={(id) => {
                setTemplates((prev) => prev.filter((t) => t.id !== id));
                notify('Đã xoá mẫu');
              }}
            />
          )}

          {screen === 'reports' && (
            <ReportsScreen
              project={activeProject}
              specs={specs}
              onGet3DSnapshot={get3DSnapshot}
              onMarkExported={(note) => {
                updateProjectWithAudit(
                  { ...activeProject, status: 'exported' },
                  note
                );
                notify(note);
              }}
            />
          )}

          {screen === 'settings' && (
            <SettingsBenchmarkScreen
              project={activeProject}
              specs={specs}
              onSetCargowizContainers={(n) => {
                updateProjectWithAudit(
                  { ...activeProject, cargowizContainers: n },
                  n === undefined
                    ? 'Xoá số cont CargoWiz thực tế'
                    : `Nhập số cont CargoWiz thực tế: ${n}`
                );
              }}
              onUpdateConfig={(optimizationConfig: OptimizationConfig) => {
                updateProjectWithAudit(
                  { ...activeProject, optimizationConfig },
                  'Đã cập nhật luật xếp hàng'
                );
              }}
            />
          )}
        </main>
      </div>

      {/* Transient Confirmation Toast */}
      {toastMessage && (
        <div className="fixed bottom-4 right-4 z-50 bg-slate-900 text-white text-xs font-medium px-4 py-2.5 rounded-md shadow-lg border border-slate-700 no-print">
          {toastMessage}
        </div>
      )}
    </div>
  );
}
