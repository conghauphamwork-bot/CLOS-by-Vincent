// Bảng sửa trực tiếp kiểu Excel:
//  - gõ vào ô, Enter/rời ô mới lưu (Esc = huỷ), Enter/↑/↓ chuyển dòng
//  - dán một vùng nhiều ô/nhiều dòng copy từ Excel vào bất kỳ ô nào
//  - đọc số kiểu Việt Nam (44,5 · 1.860) lẫn kiểu Anh (44.5 · 1,860)
import React, { useRef, useState } from 'react';
import type { RotationPolicy } from '../../types/clos';
import { parseRotation, policyToCode, rotationHint } from '../../lib/rotation';

export type CellKind = 'text' | 'int' | 'num' | 'bool' | 'rotation';
export type CellValue = string | number | boolean | RotationPolicy | null;

export interface GridColumn<T> {
  key: string;
  header: string;
  kind: CellKind;
  get: (row: T) => CellValue | undefined;
  width?: string; // class Tailwind cho ô nhập, vd 'w-20'
  align?: 'left' | 'right' | 'center';
  title?: string; // chú thích khi rê chuột lên tiêu đề
  readOnly?: boolean | ((row: T) => boolean);
  render?: (row: T) => React.ReactNode; // hiển thị riêng cho cột chỉ đọc
  optional?: boolean; // cho phép để trống (giá trị null)
  min?: number; // số nhỏ nhất (mặc định 0)
  mono?: boolean;
}

export interface CellChange {
  rowIndex: number;
  key: string;
  value: CellValue;
}
export interface CellReject {
  rowIndex: number;
  key: string;
  header: string;
  raw: string;
  reason: string;
}

interface Props<T> {
  columns: GridColumn<T>[];
  rows: T[];
  rowKey: (row: T, index: number) => string;
  onCommit: (changes: CellChange[], rejects: CellReject[]) => void;
  rowClassName?: (row: T, index: number) => string;
  cellError?: (row: T, key: string, index: number) => string | undefined;
  leading?: (row: T, index: number) => React.ReactNode; // ô đầu dòng (màu, nhãn…)
  leadingHeader?: React.ReactNode;
  trailing?: (row: T, index: number) => React.ReactNode; // nút xoá…
  trailingHeader?: React.ReactNode;
  // cho phép dán tràn xuống quá số dòng hiện có (để tạo dòng mới)
  allowOverflowRows?: boolean;
  compact?: boolean;
  onRowHover?: (row: T | null) => void;
}

// ----------------------------------------------------------------------------- đọc giá trị

export function parseNumberLoose(raw: string): number | null {
  let s = raw.replace(/[\s ]/g, '').replace(/(mm|kg|pcs|cái|thùng)$/i, '');
  if (s === '') return null;
  const hasDot = s.includes('.');
  const hasComma = s.includes(',');
  if (hasDot && hasComma) {
    // dấu xuất hiện sau cùng là dấu thập phân
    if (s.lastIndexOf(',') > s.lastIndexOf('.')) s = s.replace(/\./g, '').replace(',', '.');
    else s = s.replace(/,/g, '');
  } else if (hasComma) {
    s = /^-?\d{1,3}(,\d{3})+$/.test(s) ? s.replace(/,/g, '') : s.replace(',', '.');
  } else if (hasDot && /^-?\d{1,3}(\.\d{3})+$/.test(s)) {
    // 1.860 hoặc 12.345.678 -> phân cách nghìn kiểu VN
    s = s.replace(/\./g, '');
  }
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

export function parseBoolLoose(raw: string): boolean | null {
  const s = raw.trim().toLowerCase();
  if (['y', 'yes', 'true', '1', 'x', 'có', 'co', '✓', '✔', 'ok', 'được', 'duoc'].includes(s)) return true;
  if (['n', 'no', 'false', '0', 'không', 'khong', 'ko', 'k', '-'].includes(s)) return false;
  return null;
}

export function parseCell<T>(col: GridColumn<T>, raw: string): { ok: true; value: CellValue } | { ok: false; reason: string } {
  const t = raw.trim();
  if (t === '') {
    if (col.optional) return { ok: true, value: col.kind === 'text' ? '' : null };
    if (col.kind === 'text') return { ok: true, value: '' };
    if (col.kind === 'bool') return { ok: true, value: true };
    return { ok: false, reason: 'đang để trống' };
  }
  switch (col.kind) {
    case 'text':
      return { ok: true, value: t };
    case 'int':
    case 'num': {
      const n = parseNumberLoose(t);
      if (n === null) return { ok: false, reason: `"${t}" không phải số` };
      const v = col.kind === 'int' ? Math.round(n) : Math.round(n * 1000) / 1000;
      if (col.kind === 'int' && Math.abs(n - v) > 1e-9 && col.key === 'requiredQty')
        return { ok: false, reason: `số lượng phải là số nguyên (đang là ${t})` };
      const min = col.min ?? 0;
      if (v < min) return { ok: false, reason: `phải ≥ ${min}` };
      return { ok: true, value: v };
    }
    case 'bool': {
      const b = parseBoolLoose(t);
      return b === null ? { ok: false, reason: `"${t}" không hiểu (dùng Có/Không, Y/N, 1/0)` } : { ok: true, value: b };
    }
    case 'rotation': {
      const r = parseRotation(t);
      return r === null ? { ok: false, reason: `"${t}" không phải mã xoay 1/2/4/6` } : { ok: true, value: r };
    }
  }
}

export function formatCell<T>(col: GridColumn<T>, v: CellValue | undefined): string {
  if (v === undefined || v === null) return '';
  if (col.kind === 'rotation')
    return ['none', 'upright_only', 'length_width_only', 'four_way', 'all'].includes(String(v))
      ? String(policyToCode(v as RotationPolicy))
      : String(v); // giá trị sai đang chờ sửa: hiện nguyên văn
  if (col.kind === 'bool') return typeof v === 'boolean' ? (v ? 'Có' : 'Không') : String(v);
  return String(v);
}

/** Tách dữ liệu dán từ Excel (TSV, có xử lý ô có ngoặc kép/xuống dòng). */
export function parseClipboardTable(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        cell += '"';
        i++;
      } else if (ch === '"') quoted = false;
      else cell += ch;
      continue;
    }
    if (ch === '"' && cell === '') quoted = true;
    else if (ch === '\t') {
      row.push(cell);
      cell = '';
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = '';
    } else cell += ch;
  }
  if (cell !== '' || row.length) {
    row.push(cell);
    rows.push(row);
  }
  while (rows.length && rows[rows.length - 1].every((c) => c.trim() === '')) rows.pop();
  return rows;
}

export function gridToTsv<T>(columns: GridColumn<T>[], rows: T[]): string {
  const esc = (s: string) => (/[\t\n"]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s);
  const head = columns.map((c) => esc(c.header)).join('\t');
  const body = rows.map((r) => columns.map((c) => esc(formatCell(c, c.get(r)))).join('\t'));
  return [head, ...body].join('\n');
}

// ----------------------------------------------------------------------------- bảng

export function EditableGrid<T>({
  columns,
  rows,
  rowKey,
  onCommit,
  rowClassName,
  cellError,
  leading,
  leadingHeader,
  trailing,
  trailingHeader,
  allowOverflowRows = false,
  compact = false,
  onRowHover,
}: Props<T>) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [editing, setEditing] = useState<{ r: number; c: number; text: string } | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const isReadOnly = (col: GridColumn<T>, row: T) =>
    typeof col.readOnly === 'function' ? col.readOnly(row) : !!col.readOnly;

  const focusCell = (r: number, c: number) => {
    const el = wrapRef.current?.querySelector<HTMLElement>(`[data-r="${r}"][data-c="${c}"]`);
    if (el) {
      el.focus();
      if (el instanceof HTMLInputElement && el.type === 'text') el.select();
    }
  };

  const applyResults = (changes: CellChange[], rejects: CellReject[]) => {
    setErrors((prev) => {
      const next = { ...prev };
      for (const ch of changes) delete next[`${ch.rowIndex}:${ch.key}`];
      for (const rj of rejects) next[`${rj.rowIndex}:${rj.key}`] = rj.reason;
      return next;
    });
    if (changes.length || rejects.length) onCommit(changes, rejects);
  };

  const commitText = (r: number, c: number, text: string) => {
    const col = columns[c];
    const row = rows[r];
    if (!col || !row) return;
    if (text === formatCell(col, col.get(row))) return; // không đổi
    const res = parseCell(col, text);
    if (res.ok) applyResults([{ rowIndex: r, key: col.key, value: res.value }], []);
    else applyResults([], [{ rowIndex: r, key: col.key, header: col.header, raw: text, reason: res.reason }]);
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLDivElement>) => {
    const target = (e.target as HTMLElement).closest<HTMLElement>('[data-r]');
    if (!target) return;
    const text = e.clipboardData.getData('text/plain');
    const isMulti = /[\t\n\r]/.test(text.replace(/[\r\n]+$/, ''));
    if (!isMulti && target instanceof HTMLInputElement && target.type === 'text') return; // dán 1 ô: để trình duyệt tự xử lý
    e.preventDefault();
    const r0 = Number(target.dataset.r);
    const c0 = Number(target.dataset.c);
    const matrix = parseClipboardTable(text);
    const changes: CellChange[] = [];
    const rejects: CellReject[] = [];
    matrix.forEach((line, i) => {
      const r = r0 + i;
      if (r >= rows.length && !allowOverflowRows) return;
      line.forEach((raw, j) => {
        const col = columns[c0 + j];
        if (!col) return;
        const row = rows[r];
        if (row && isReadOnly(col, row)) return;
        if (!row && col.readOnly === true) return;
        const res = parseCell(col, raw);
        if (res.ok) changes.push({ rowIndex: r, key: col.key, value: res.value });
        else rejects.push({ rowIndex: r, key: col.key, header: col.header, raw, reason: res.reason });
      });
    });
    setEditing(null);
    applyResults(changes, rejects);
  };

  const pad = compact ? 'py-1 px-1.5' : 'py-1.5 px-2';

  return (
    <div ref={wrapRef} className="overflow-x-auto" onPaste={handlePaste}>
      <table className="w-full text-xs text-left">
        <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
          <tr>
            {leading && <th className="py-2.5 px-3 font-medium whitespace-nowrap">{leadingHeader}</th>}
            {columns.map((col) => (
              <th
                key={col.key}
                title={col.title}
                className={`py-2.5 px-2 font-medium whitespace-nowrap ${
                  col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : ''
                } ${col.title ? 'underline decoration-dotted underline-offset-2 cursor-help' : ''}`}
              >
                {col.header}
              </th>
            ))}
            {trailing && <th className="py-2.5 px-3 font-medium text-right">{trailingHeader}</th>}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {rows.map((row, r) => (
            <tr
              key={rowKey(row, r)}
              className={rowClassName?.(row, r) ?? 'hover:bg-slate-50'}
              onMouseEnter={onRowHover ? () => onRowHover(row) : undefined}
              onMouseLeave={onRowHover ? () => onRowHover(null) : undefined}
            >
              {leading && <td className={`${pad} whitespace-nowrap`}>{leading(row, r)}</td>}
              {columns.map((col, c) => {
                const ro = isReadOnly(col, row);
                const err = errors[`${r}:${col.key}`] ?? cellError?.(row, col.key, r);
                const align = col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : 'text-left';
                if (ro) {
                  return (
                    <td key={col.key} className={`${pad} ${align} whitespace-nowrap ${col.mono ? 'font-mono tabular-nums' : ''}`}>
                      {col.render ? col.render(row) : formatCell(col, col.get(row))}
                    </td>
                  );
                }
                if (col.kind === 'bool') {
                  return (
                    <td key={col.key} className={`${pad} text-center`}>
                      <input
                        type="checkbox"
                        data-r={r}
                        data-c={c}
                        checked={Boolean(col.get(row) ?? true)}
                        onChange={(e) => applyResults([{ rowIndex: r, key: col.key, value: e.target.checked }], [])}
                        onKeyDown={(e) => {
                          if (e.key === 'ArrowDown' || e.key === 'Enter') {
                            e.preventDefault();
                            focusCell(r + 1, c);
                          } else if (e.key === 'ArrowUp') {
                            e.preventDefault();
                            focusCell(r - 1, c);
                          }
                        }}
                        title={err}
                        className={err ? 'outline outline-2 outline-red-500' : ''}
                      />
                    </td>
                  );
                }
                const shown =
                  editing && editing.r === r && editing.c === c ? editing.text : formatCell(col, col.get(row));
                return (
                  <td key={col.key} className={`${pad} ${align}`}>
                    <input
                      type="text"
                      inputMode={col.kind === 'int' || col.kind === 'num' || col.kind === 'rotation' ? 'decimal' : undefined}
                      data-r={r}
                      data-c={c}
                      value={shown}
                      title={err ?? (col.kind === 'rotation' && col.get(row) ? rotationHint(col.get(row) as RotationPolicy) : undefined)}
                      onFocus={(e) => {
                        setEditing({ r, c, text: formatCell(col, col.get(row)) });
                        e.currentTarget.select();
                      }}
                      onChange={(e) => setEditing({ r, c, text: e.target.value })}
                      onBlur={(e) => {
                        commitText(r, c, e.target.value);
                        setEditing((cur) => (cur && cur.r === r && cur.c === c ? null : cur));
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === 'ArrowDown') {
                          e.preventDefault();
                          if (r + 1 < rows.length) focusCell(r + 1, c);
                          else e.currentTarget.blur();
                        } else if (e.key === 'ArrowUp') {
                          e.preventDefault();
                          focusCell(r - 1, c);
                        } else if (e.key === 'Escape') {
                          setEditing({ r, c, text: formatCell(col, col.get(row)) });
                          setTimeout(() => (e.target as HTMLInputElement).blur(), 0);
                        }
                      }}
                      className={`${col.width ?? 'w-full'} ${align} ${
                        col.mono || col.kind !== 'text' ? 'font-mono tabular-nums' : ''
                      } border rounded px-1.5 py-1 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                        err ? 'border-red-500 bg-red-50' : 'border-slate-200'
                      }`}
                    />
                  </td>
                );
              })}
              {trailing && <td className={`${pad} text-right whitespace-nowrap`}>{trailing(row, r)}</td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
