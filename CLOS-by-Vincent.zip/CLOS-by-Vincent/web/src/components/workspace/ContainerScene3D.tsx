import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  CargoSku,
  ContainerLoad,
  ContainerSpec,
  PlacedCarton,
  ValidationIssue,
} from '../../types/clos';
import { computeContainerStats } from '../../engine/reconciliation';

export type CameraPreset = 'iso' | 'side' | 'top' | 'doors';

export interface ContainerScene3DHandle {
  captureSnapshot: () => string | null;
  setCameraPreset: (preset: CameraPreset) => void;
  resolveDropPosition: (
    clientX: number,
    clientY: number,
    dimXMm: number,
    dimYMm: number,
    dimZMm: number
  ) => { xMm: number; yMm: number; zMm: number };
}

interface ContainerScene3DProps {
  container: ContainerLoad;
  spec: ContainerSpec;
  skus: CargoSku[];
  selectedCartonId: string | null;
  hoveredSkuId: string | null;
  visibleMaxLayer: number; // -1 means all layers
  explodeFactor: number; // 0..1 vertical layer explode
  showWireframeWalls: boolean;
  showCogMarker: boolean;
  dragModeEnabled: boolean;
  issues: ValidationIssue[];
  onSelectCarton: (instanceId: string | null) => void;
  onMoveCarton: (
    instanceId: string,
    xMm: number,
    yMm: number,
    zMm: number
  ) => void;
  onDragStatusChange?: (
    coords: { xMm: number; yMm: number; zMm: number; skuLabel: string } | null
  ) => void;
}

const SCALE = 0.001; // 1 mm = 0.001 Three.js meters
const _vec3A = new THREE.Vector3();
const _vec3B = new THREE.Vector3();
const _plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

function createTimberFloorTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#9c7b56';
  ctx.fillRect(0, 0, 512, 512);

  // Subtle plank seams and grain
  const plankCount = 8;
  const plankH = 512 / plankCount;
  for (let i = 0; i < plankCount; i++) {
    const shade = i % 2 === 0 ? '#a4835d' : '#93724d';
    ctx.fillStyle = shade;
    ctx.fillRect(0, i * plankH, 512, plankH - 2);
    ctx.fillStyle = 'rgba(40, 28, 16, 0.35)';
    ctx.fillRect(0, (i + 1) * plankH - 2, 512, 2);

    // Grain lines
    ctx.strokeStyle = 'rgba(65, 45, 25, 0.14)';
    ctx.lineWidth = 1;
    for (let g = 0; g < 6; g++) {
      const y = i * plankH + 6 + g * 8;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(512, y + (g % 2 === 0 ? 2 : -2));
      ctx.stroke();
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(4, 2);
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createCartonTexture(
  baseHex: string,
  skuCode: string,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, 256, 256);

  // Subtle corrugated cardboard overlay
  ctx.fillStyle = 'rgba(255,255,255,0.08)';
  for (let y = 0; y < 256; y += 8) {
    ctx.fillRect(0, y, 256, 2);
  }

  // Crisp inner packaging border
  ctx.strokeStyle = 'rgba(15, 23, 42, 0.25)';
  ctx.lineWidth = 6;
  ctx.strokeRect(6, 6, 244, 244);

  // Tape band & shipping label patch
  ctx.fillStyle = 'rgba(255, 255, 255, 0.88)';
  ctx.fillRect(22, 22, 152, 46);
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 17px monospace';
  ctx.fillText(skuCode.slice(0, 14), 30, 51);

  // Upward orientation arrows
  ctx.fillStyle = 'rgba(255, 255, 255, 0.72)';
  ctx.beginPath();
  ctx.moveTo(212, 24);
  ctx.lineTo(226, 44);
  ctx.lineTo(218, 44);
  ctx.lineTo(218, 66);
  ctx.lineTo(206, 66);
  ctx.lineTo(206, 44);
  ctx.lineTo(198, 44);
  ctx.closePath();
  ctx.fill();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export const ContainerScene3D = forwardRef<
  ContainerScene3DHandle,
  ContainerScene3DProps
>(function ContainerScene3D(
  {
    container,
    spec,
    skus,
    selectedCartonId,
    hoveredSkuId,
    visibleMaxLayer,
    explodeFactor,
    showWireframeWalls,
    showCogMarker,
    dragModeEnabled,
    issues,
    onSelectCarton,
    onMoveCarton,
    onDragStatusChange,
  },
  ref
) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [webglError, setWebglError] = useState<string | null>(null);

  // Mutable refs so Three.js loop never tears down on React state updates
  const propsRef = useRef({
    container,
    spec,
    skus,
    selectedCartonId,
    hoveredSkuId,
    visibleMaxLayer,
    explodeFactor,
    showWireframeWalls,
    showCogMarker,
    dragModeEnabled,
    issues,
    onSelectCarton,
    onMoveCarton,
    onDragStatusChange,
  });
  propsRef.current = {
    container,
    spec,
    skus,
    selectedCartonId,
    hoveredSkuId,
    visibleMaxLayer,
    explodeFactor,
    showWireframeWalls,
    showCogMarker,
    dragModeEnabled,
    issues,
    onSelectCarton,
    onMoveCarton,
    onDragStatusChange,
  };

  const sceneApiRef = useRef<{
    syncSceneData: () => void;
    requestRender: () => void;
    captureSnapshot: () => string | null;
    setCameraPreset: (preset: CameraPreset) => void;
    resolveDropPosition: (
      clientX: number,
      clientY: number,
      dimXMm: number,
      dimYMm: number,
      dimZMm: number
    ) => { xMm: number; yMm: number; zMm: number };
  } | null>(null);

  useImperativeHandle(ref, () => ({
    captureSnapshot: () => sceneApiRef.current?.captureSnapshot() ?? null,
    setCameraPreset: (preset: CameraPreset) =>
      sceneApiRef.current?.setCameraPreset(preset),
    resolveDropPosition: (clientX, clientY, dimXMm, dimYMm, dimZMm) =>
      sceneApiRef.current?.resolveDropPosition(
        clientX,
        clientY,
        dimXMm,
        dimYMm,
        dimZMm
      ) ?? { xMm: 0, yMm: 0, zMm: 0 },
  }));

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const isSoftwareGl = (() => {
      try {
        const c = document.createElement('canvas');
        const gl = c.getContext('webgl2') || c.getContext('webgl');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
        preserveDrawingBuffer: false,
      });
    } catch {
      setWebglError('Không khởi tạo được WebGL để vẽ 3D.');
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(
      isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2)
    );
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(mount.clientWidth || 800, mount.clientHeight || 540);

    mount.innerHTML = '';
    mount.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setWebglError('Mất kết nối WebGL. Đang thử khôi phục…');
    };
    const handleContextRestored = () => {
      setWebglError(null);
      requestRender();
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener(
      'webglcontextrestored',
      handleContextRestored
    );

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#e8edf3');
    scene.fog = new THREE.Fog('#e8edf3', 28, 65);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTex = pmremGenerator.fromScene(roomEnv, 0.04).texture;
    scene.environment = envTex;
    roomEnv.dispose();
    pmremGenerator.dispose();

    const width = mount.clientWidth || 800;
    const height = mount.clientHeight || 540;
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 150);
    camera.position.set(11.5, 6.8, 9.2);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.08;
    controls.maxPolarAngle = Math.PI / 2 - 0.02;
    controls.minDistance = 2.5;
    controls.maxDistance = 32;

    // 3-point lighting rig
    const hemiLight = new THREE.HemisphereLight('#f0f6ff', '#cbd5e1', 0.85);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight('#fff6eb', 1.45);
    keyLight.position.set(12, 18, 10);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.left = -10;
    keyLight.shadow.camera.right = 10;
    keyLight.shadow.camera.top = 10;
    keyLight.shadow.camera.bottom = -10;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight('#dbeafe', 0.55);
    rimLight.position.set(-12, 9, -10);
    scene.add(rimLight);

    // Warehouse dock ground plane + subtle grid
    const groundGeo = new THREE.PlaneGeometry(80, 80);
    const groundMat = new THREE.MeshStandardMaterial({
      color: '#dde4ed',
      roughness: 0.9,
      metalness: 0.05,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.04;
    ground.receiveShadow = true;
    scene.add(ground);

    const gridHelper = new THREE.GridHelper(36, 36, '#94a3b8', '#cbd5e1');
    gridHelper.position.y = -0.03;
    scene.add(gridHelper);

    // Groups for container structure, cartons, and CoG marker
    const containerGroup = new THREE.Group();
    const cartonsGroup = new THREE.Group();
    const cogGroup = new THREE.Group();
    scene.add(containerGroup);
    scene.add(cartonsGroup);
    scene.add(cogGroup);

    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();
    const floorTex = createTimberFloorTexture(maxAnisotropy);
    const skuTextureCache = new Map<string, THREE.CanvasTexture>();
    const cartonMeshMap = new Map<
      string,
      {
        mesh: THREE.Mesh;
        edgeLine: THREE.LineSegments;
        baseY: number;
        layerIndex: number;
      }
    >();

    // Camera transition target state
    let camTransition: {
      active: boolean;
      pos: THREE.Vector3;
      target: THREE.Vector3;
    } = {
      active: false,
      pos: new THREE.Vector3(),
      target: new THREE.Vector3(),
    };

    controls.addEventListener('start', () => {
      camTransition.active = false;
    });

    // On-demand render scheduler (with software WebGL afterDraw pacing)
    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let disposed = false;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || !gl.fenceSync) {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    let lastAnimTime = performance.now();
    function requestRender() {
      if (disposed) return;
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame(() => {
        if (disposed) return;
        renderDirty = false;
        const now = performance.now();
        const dt = Math.min(0.05, Math.max(0.001, (now - lastAnimTime) / 1000));
        lastAnimTime = now;

        let needsAnotherFrame = false;

        // Smooth camera preset damping
        if (camTransition.active) {
          camera.position.x = THREE.MathUtils.damp(
            camera.position.x,
            camTransition.pos.x,
            7,
            dt
          );
          camera.position.y = THREE.MathUtils.damp(
            camera.position.y,
            camTransition.pos.y,
            7,
            dt
          );
          camera.position.z = THREE.MathUtils.damp(
            camera.position.z,
            camTransition.pos.z,
            7,
            dt
          );
          controls.target.x = THREE.MathUtils.damp(
            controls.target.x,
            camTransition.target.x,
            7,
            dt
          );
          controls.target.y = THREE.MathUtils.damp(
            controls.target.y,
            camTransition.target.y,
            7,
            dt
          );
          controls.target.z = THREE.MathUtils.damp(
            controls.target.z,
            camTransition.target.z,
            7,
            dt
          );
          if (
            camera.position.distanceTo(camTransition.pos) < 0.02 &&
            controls.target.distanceTo(camTransition.target) < 0.02
          ) {
            camTransition.active = false;
          } else {
            needsAnotherFrame = true;
          }
        }

        // Smooth layer-explode damping
        const exp = propsRef.current.explodeFactor;
        for (const entry of cartonMeshMap.values()) {
          const targetY = entry.baseY + entry.layerIndex * exp * 0.42;
          if (Math.abs(entry.mesh.position.y - targetY) > 0.002) {
            entry.mesh.position.y = THREE.MathUtils.damp(
              entry.mesh.position.y,
              targetY,
              10,
              dt
            );
            needsAnotherFrame = true;
          } else {
            entry.mesh.position.y = targetY;
          }
        }

        controls.update();
        renderer.render(scene, camera);

        const done = () => {
          renderBusy = false;
          if (renderDirty || needsAnotherFrame) requestRender();
        };
        if (isSoftwareGl) afterDraw(done);
        else done();
      });
    }

    controls.addEventListener('change', requestRender);

    function rebuildContainerShell() {
      while (containerGroup.children.length > 0) {
        const ch = containerGroup.children[0];
        containerGroup.remove(ch);
        if ((ch as THREE.Mesh).geometry) (ch as THREE.Mesh).geometry.dispose();
      }

      const { spec, showWireframeWalls } = propsRef.current;
      const L = spec.internalLengthMm * SCALE;
      const W = spec.internalWidthMm * SCALE;
      const H = spec.internalHeightMm * SCALE;

      // Center container around origin in X/Z, floor at y=0
      const halfL = L / 2;
      const halfW = W / 2;

      // 1. Timber Floor Deck
      const deckGeo = new THREE.BoxGeometry(L, 0.036, W);
      const deckMat = new THREE.MeshStandardMaterial({
        map: floorTex,
        roughness: 0.78,
        metalness: 0.05,
      });
      const deck = new THREE.Mesh(deckGeo, deckMat);
      deck.position.set(0, -0.018, 0);
      deck.receiveShadow = true;
      containerGroup.add(deck);

      // 2. Heavy Corten Steel Corner Posts & Rails (3-12 part structural assembly)
      const steelMat = new THREE.MeshStandardMaterial({
        color: '#1e3a5f',
        roughness: 0.42,
        metalness: 0.72,
      });

      const postThickness = 0.055;
      const cornerCoords = [
        [-halfL, -halfW],
        [-halfL, halfW],
        [halfL, -halfW],
        [halfL, halfW],
      ];
      for (const [cx, cz] of cornerCoords) {
        const post = new THREE.Mesh(
          new THREE.BoxGeometry(postThickness, H + 0.06, postThickness),
          steelMat
        );
        post.position.set(cx, H / 2, cz);
        post.castShadow = true;
        containerGroup.add(post);
      }

      // Top & bottom longitudinal rails
      const railGeoLong = new THREE.BoxGeometry(L + 0.06, 0.05, 0.05);
      for (const ry of [0, H + 0.025]) {
        for (const rz of [-halfW, halfW]) {
          const rail = new THREE.Mesh(railGeoLong, steelMat);
          rail.position.set(0, ry, rz);
          containerGroup.add(rail);
        }
      }

      // Top & bottom transverse crossbeams
      const railGeoTrans = new THREE.BoxGeometry(0.05, 0.05, W + 0.06);
      for (const ry of [0, H + 0.025]) {
        for (const rx of [-halfL, halfL]) {
          const beam = new THREE.Mesh(railGeoTrans, steelMat);
          beam.position.set(rx, ry, 0);
          containerGroup.add(beam);
        }
      }

      // Open Double Doors at +X end
      const doorMat = new THREE.MeshStandardMaterial({
        color: '#1e3a5f',
        roughness: 0.48,
        metalness: 0.65,
      });
      const doorW = W / 2 - 0.02;
      const leftDoor = new THREE.Mesh(
        new THREE.BoxGeometry(0.04, H, doorW),
        doorMat
      );
      leftDoor.position.set(halfL + doorW * 0.45, H / 2, -halfW - 0.16);
      leftDoor.rotation.y = -Math.PI * 0.62;
      containerGroup.add(leftDoor);

      const rightDoor = new THREE.Mesh(
        new THREE.BoxGeometry(0.04, H, doorW),
        doorMat
      );
      rightDoor.position.set(halfL + doorW * 0.45, H / 2, halfW + 0.16);
      rightDoor.rotation.y = Math.PI * 0.62;
      containerGroup.add(rightDoor);

      // Rear bulkhead + semi-transparent side walls
      const wallMat = new THREE.MeshStandardMaterial({
        color: '#475569',
        roughness: 0.6,
        metalness: 0.3,
        transparent: true,
        opacity: showWireframeWalls ? 0.08 : 0.24,
        depthWrite: false,
        side: THREE.DoubleSide,
      });

      const rearWall = new THREE.Mesh(
        new THREE.PlaneGeometry(W, H),
        new THREE.MeshStandardMaterial({
          color: '#334155',
          roughness: 0.55,
          metalness: 0.55,
          transparent: true,
          opacity: showWireframeWalls ? 0.22 : 0.72,
          side: THREE.DoubleSide,
        })
      );
      rearWall.rotation.y = Math.PI / 2;
      rearWall.position.set(-halfL, H / 2, 0);
      containerGroup.add(rearWall);

      for (const wz of [-halfW, halfW]) {
        const sideWall = new THREE.Mesh(new THREE.PlaneGeometry(L, H), wallMat);
        sideWall.position.set(0, H / 2, wz);
        containerGroup.add(sideWall);
      }

      // Wireframe bounding outline
      const frameEdges = new THREE.EdgesGeometry(new THREE.BoxGeometry(L, H, W));
      const frameLines = new THREE.LineSegments(
        frameEdges,
        new THREE.LineBasicMaterial({ color: '#1e293b', transparent: true, opacity: 0.5 })
      );
      frameLines.position.set(0, H / 2, 0);
      containerGroup.add(frameLines);

      // Left / Right / Rear floor reference strip indicators
      const leftMarker = new THREE.Mesh(
        new THREE.BoxGeometry(L, 0.008, 0.04),
        new THREE.MeshBasicMaterial({ color: '#2563eb' })
      );
      leftMarker.position.set(0, 0.004, -halfW + 0.02);
      containerGroup.add(leftMarker);

      const rightMarker = new THREE.Mesh(
        new THREE.BoxGeometry(L, 0.008, 0.04),
        new THREE.MeshBasicMaterial({ color: '#0d9488' })
      );
      rightMarker.position.set(0, 0.004, halfW - 0.02);
      containerGroup.add(rightMarker);
    }

    function syncCartonsAndCog() {
      const {
        container,
        spec,
        skus,
        selectedCartonId,
        hoveredSkuId,
        visibleMaxLayer,
        showCogMarker,
        issues,
      } = propsRef.current;

      const skuMap = new Map(skus.map((s) => [s.id, s]));
      const errorCartonIds = new Set<string>();
      for (const iss of issues) {
        if (iss.containerId === container.id && iss.severity === 'error') {
          iss.cartonIds.forEach((id) => errorCartonIds.add(id));
        }
      }

      // Clear old cartons
      while (cartonsGroup.children.length > 0) {
        const ch = cartonsGroup.children[0] as THREE.Mesh;
        cartonsGroup.remove(ch);
        if (ch.geometry) ch.geometry.dispose();
        if (Array.isArray(ch.material)) ch.material.forEach((m) => m.dispose());
        else if (ch.material) ch.material.dispose();
      }
      cartonMeshMap.clear();

      const L = spec.internalLengthMm * SCALE;
      const W = spec.internalWidthMm * SCALE;
      const halfL = L / 2;
      const halfW = W / 2;

      for (const p of container.placements) {
        if (visibleMaxLayer >= 0 && p.layerIndex > visibleMaxLayer) continue;

        const sku = skuMap.get(p.skuId);
        const colorHex = sku?.color ?? '#2563eb';
        const cacheKey = `${p.skuId}_${colorHex}`;
        let tex = skuTextureCache.get(cacheKey);
        if (!tex) {
          tex = createCartonTexture(
            colorHex,
            sku?.factorySku ?? p.skuId,
            maxAnisotropy
          );
          skuTextureCache.set(cacheKey, tex);
        }

        const dx = p.dimXMm * SCALE;
        const dy = p.dimYMm * SCALE;
        const dz = p.dimZMm * SCALE;

        const isSelected = p.instanceId === selectedCartonId;
        const isError = errorCartonIds.has(p.instanceId);
        const isDimmed = hoveredSkuId !== null && p.skuId !== hoveredSkuId;

        const geo = new THREE.BoxGeometry(
          Math.max(0.02, dx - 0.006),
          Math.max(0.02, dy - 0.006),
          Math.max(0.02, dz - 0.006)
        );
        const mat = new THREE.MeshStandardMaterial({
          map: tex,
          color: isError ? '#ef4444' : '#ffffff',
          roughness: 0.72,
          metalness: 0.04,
          emissive: isSelected
            ? new THREE.Color('#1d4ed8')
            : isError
              ? new THREE.Color('#991b1b')
              : new THREE.Color('#000000'),
          emissiveIntensity: isSelected ? 0.35 : isError ? 0.3 : 0,
          transparent: isDimmed,
          opacity: isDimmed ? 0.28 : 1,
        });

        const mesh = new THREE.Mesh(geo, mat);
        mesh.castShadow = !isSoftwareGl;
        mesh.receiveShadow = !isSoftwareGl;
        mesh.layers.enable(1);
        mesh.userData = { instanceId: p.instanceId, placement: p };

        const posX = p.xMm * SCALE - halfL + dx / 2;
        const baseY = p.yMm * SCALE + dy / 2;
        const posZ = p.zMm * SCALE - halfW + dz / 2;
        mesh.position.set(
          posX,
          baseY + p.layerIndex * propsRef.current.explodeFactor * 0.42,
          posZ
        );

        const edgeGeo = new THREE.EdgesGeometry(geo);
        const edgeLine = new THREE.LineSegments(
          edgeGeo,
          new THREE.LineBasicMaterial({
            color: isSelected ? '#ffffff' : isError ? '#fee2e2' : '#0f172a',
            transparent: true,
            opacity: isSelected ? 0.95 : 0.45,
          })
        );
        mesh.add(edgeLine);

        cartonsGroup.add(mesh);
        cartonMeshMap.set(p.instanceId, {
          mesh,
          edgeLine,
          baseY,
          layerIndex: p.layerIndex,
        });
      }

      // Update Center-of-Gravity marker
      while (cogGroup.children.length > 0) {
        const ch = cogGroup.children[0] as THREE.Mesh;
        cogGroup.remove(ch);
        if (ch.geometry) ch.geometry.dispose();
      }
      if (showCogMarker && container.placements.length > 0) {
        const stats = computeContainerStats(container, spec, skuMap);
        const cogX = stats.cogXMm * SCALE - halfL;
        const cogZ = stats.cogZMm * SCALE - halfW;
        const cogY = Math.max(0.25, stats.cogYMm * SCALE);

        const color = stats.cogBalanceOk ? '#16a34a' : '#d97706';
        const sphere = new THREE.Mesh(
          new THREE.SphereGeometry(0.11, 16, 16),
          new THREE.MeshBasicMaterial({ color })
        );
        sphere.position.set(cogX, cogY, cogZ);
        cogGroup.add(sphere);

        const plumbGeo = new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(cogX, 0.01, cogZ),
          new THREE.Vector3(cogX, spec.internalHeightMm * SCALE + 0.35, cogZ),
        ]);
        const plumbLine = new THREE.Line(
          plumbGeo,
          new THREE.LineBasicMaterial({ color })
        );
        cogGroup.add(plumbLine);
      }
    }

    function applyCameraPreset(preset: CameraPreset) {
      const { spec } = propsRef.current;
      const L = spec.internalLengthMm * SCALE;
      const H = spec.internalHeightMm * SCALE;
      camTransition.target.set(0, H * 0.45, 0);
      if (preset === 'iso') {
        camTransition.pos.set(L * 0.85, H * 2.4, L * 0.72);
      } else if (preset === 'side') {
        camTransition.pos.set(0, H * 0.65, L * 1.15);
      } else if (preset === 'top') {
        camTransition.pos.set(0, L * 1.18, 0.01);
      } else if (preset === 'doors') {
        camTransition.pos.set(L * 0.98, H * 0.85, 0.01);
      }
      camTransition.active = true;
      requestRender();
    }

    // Raycasting & interactive 3D plane drag
    const raycaster = new THREE.Raycaster();
    raycaster.layers.set(1);
    const pointer = new THREE.Vector2();
    let draggingPlacement: PlacedCarton | null = null;
    let dragStartOffsetX = 0;
    let dragStartOffsetZ = 0;
    let pointerDownPos = { x: 0, y: 0 };

    function updatePointer(e: PointerEvent) {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    }

    function onPointerDown(e: PointerEvent) {
      pointerDownPos = { x: e.clientX, y: e.clientY };
      updatePointer(e);
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(cartonsGroup.children, false);
      if (hits.length > 0) {
        const hitObj = hits[0].object as THREE.Mesh;
        const p = hitObj.userData.placement as PlacedCarton | undefined;
        if (p) {
          propsRef.current.onSelectCarton(p.instanceId);
          if (propsRef.current.dragModeEnabled) {
            draggingPlacement = p;
            controls.enabled = false;
            const planeY =
              (p.yMm + p.dimYMm / 2) * SCALE +
              p.layerIndex * propsRef.current.explodeFactor * 0.42;
            _plane.set(new THREE.Vector3(0, 1, 0), -planeY);
            if (raycaster.ray.intersectPlane(_plane, _vec3A)) {
              dragStartOffsetX = hitObj.position.x - _vec3A.x;
              dragStartOffsetZ = hitObj.position.z - _vec3A.z;
            }
          }
        }
      }
    }

    let lastHoverCheck = 0;
    function onPointerMove(e: PointerEvent) {
      if (draggingPlacement) {
        updatePointer(e);
        raycaster.setFromCamera(pointer, camera);
        if (raycaster.ray.intersectPlane(_plane, _vec3B)) {
          const { spec } = propsRef.current;
          const L = spec.internalLengthMm * SCALE;
          const W = spec.internalWidthMm * SCALE;
          const dx = draggingPlacement.dimXMm * SCALE;
          const dz = draggingPlacement.dimZMm * SCALE;

          const worldX = _vec3B.x + dragStartOffsetX;
          const worldZ = _vec3B.z + dragStartOffsetZ;

          let newXMm = Math.round(((worldX + L / 2 - dx / 2) / SCALE) / 25) * 25;
          let newZMm = Math.round(((worldZ + W / 2 - dz / 2) / SCALE) / 25) * 25;

          newXMm = Math.max(
            0,
            Math.min(spec.internalLengthMm - draggingPlacement.dimXMm, newXMm)
          );
          newZMm = Math.max(
            0,
            Math.min(spec.internalWidthMm - draggingPlacement.dimZMm, newZMm)
          );

          const entry = cartonMeshMap.get(draggingPlacement.instanceId);
          if (entry) {
            entry.mesh.position.x = newXMm * SCALE - L / 2 + dx / 2;
            entry.mesh.position.z = newZMm * SCALE - W / 2 + dz / 2;
            draggingPlacement = {
              ...draggingPlacement,
              xMm: newXMm,
              zMm: newZMm,
            };
            const skuLabel =
              propsRef.current.skus.find((s) => s.id === draggingPlacement?.skuId)
                ?.factorySku ?? draggingPlacement.skuId;
            propsRef.current.onDragStatusChange?.({
              xMm: newXMm,
              yMm: draggingPlacement.yMm,
              zMm: newZMm,
              skuLabel,
            });
            requestRender();
          }
        }
        return;
      }

      const now = performance.now();
      if (now - lastHoverCheck < 50) return;
      lastHoverCheck = now;

      updatePointer(e);
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(cartonsGroup.children, false);
      renderer.domElement.style.cursor =
        hits.length > 0
          ? propsRef.current.dragModeEnabled
            ? 'grab'
            : 'pointer'
          : 'default';
    }

    function onPointerUp(e: PointerEvent) {
      if (draggingPlacement) {
        const finalP = draggingPlacement;
        draggingPlacement = null;
        controls.enabled = true;
        propsRef.current.onDragStatusChange?.(null);
        propsRef.current.onMoveCarton(
          finalP.instanceId,
          finalP.xMm,
          finalP.yMm,
          finalP.zMm
        );
        return;
      }

      // Click empty space deselects
      const dist = Math.hypot(
        e.clientX - pointerDownPos.x,
        e.clientY - pointerDownPos.y
      );
      if (dist < 4) {
        updatePointer(e);
        raycaster.setFromCamera(pointer, camera);
        const hits = raycaster.intersectObjects(cartonsGroup.children, false);
        if (hits.length === 0) {
          propsRef.current.onSelectCarton(null);
        }
      }
    }

    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);

    const resizeObserver = new ResizeObserver(() => {
      if (disposed || !mount) return;
      const w = mount.clientWidth || 800;
      const h = mount.clientHeight || 540;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      requestRender();
    });
    resizeObserver.observe(mount);

    function resolveDropPosition(
      clientX: number,
      clientY: number,
      dimXMm: number,
      dimYMm: number,
      dimZMm: number
    ): { xMm: number; yMm: number; zMm: number } {
      const { spec } = propsRef.current;
      const rect = renderer.domElement.getBoundingClientRect();
      const dropNdc = new THREE.Vector2(
        ((clientX - rect.left) / rect.width) * 2 - 1,
        -((clientY - rect.top) / rect.height) * 2 + 1
      );
      const dropRaycaster = new THREE.Raycaster();
      dropRaycaster.layers.set(1);
      dropRaycaster.setFromCamera(dropNdc, camera);

      const L = spec.internalLengthMm * SCALE;
      const W = spec.internalWidthMm * SCALE;

      // Check if dropped onto an existing carton's top surface
      const cartonHits = dropRaycaster.intersectObjects(
        cartonsGroup.children,
        false
      );
      if (cartonHits.length > 0) {
        const hit = cartonHits[0];
        const hitPlacement = hit.object.userData.placement as
          | PlacedCarton
          | undefined;
        if (hitPlacement) {
          let xMm = Math.round(((hit.point.x + L / 2) / SCALE - dimXMm / 2) / 25) * 25;
          let zMm = Math.round(((hit.point.z + W / 2) / SCALE - dimZMm / 2) / 25) * 25;
          let yMm = hitPlacement.yMm + hitPlacement.dimYMm;
          if (yMm + dimYMm > spec.internalHeightMm) {
            yMm = Math.max(0, spec.internalHeightMm - dimYMm);
          }
          xMm = Math.max(0, Math.min(spec.internalLengthMm - dimXMm, xMm));
          zMm = Math.max(0, Math.min(spec.internalWidthMm - dimZMm, zMm));
          return { xMm, yMm, zMm };
        }
      }

      // Otherwise intersect container floor plane (y = 0)
      const floorPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
      const pt = new THREE.Vector3();
      if (dropRaycaster.ray.intersectPlane(floorPlane, pt)) {
        let xMm = Math.round(((pt.x + L / 2) / SCALE - dimXMm / 2) / 25) * 25;
        let zMm = Math.round(((pt.z + W / 2) / SCALE - dimZMm / 2) / 25) * 25;
        xMm = Math.max(0, Math.min(spec.internalLengthMm - dimXMm, xMm));
        zMm = Math.max(0, Math.min(spec.internalWidthMm - dimZMm, zMm));
        return { xMm, yMm: 0, zMm };
      }

      return { xMm: 0, yMm: 0, zMm: 0 };
    }

    sceneApiRef.current = {
      syncSceneData: () => {
        rebuildContainerShell();
        syncCartonsAndCog();
        requestRender();
      },
      requestRender,
      captureSnapshot: () => {
        renderer.render(scene, camera);
        return renderer.domElement.toDataURL('image/png');
      },
      setCameraPreset: applyCameraPreset,
      resolveDropPosition,
    };

    rebuildContainerShell();
    syncCartonsAndCog();
    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }
    requestRender();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObserver.disconnect();
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      renderer.domElement.removeEventListener(
        'webglcontextlost',
        handleContextLost
      );
      renderer.domElement.removeEventListener(
        'webglcontextrestored',
        handleContextRestored
      );
      controls.dispose();
      floorTex.dispose();
      skuTextureCache.forEach((t) => t.dispose());
      envTex.dispose();
      renderer.dispose();
      sceneApiRef.current = null;
    };
  }, []);

  // Sync scene objects whenever props update without recreating WebGL context
  useEffect(() => {
    sceneApiRef.current?.syncSceneData();
  }, [
    container,
    spec,
    skus,
    selectedCartonId,
    hoveredSkuId,
    visibleMaxLayer,
    explodeFactor,
    showWireframeWalls,
    showCogMarker,
    issues,
  ]);

  if (webglError) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-slate-100 border border-slate-200 rounded-lg p-6 text-center">
        <div>
          <p className="text-sm font-semibold text-slate-900">
            Không hiển thị được 3D
          </p>
          <p className="text-xs text-slate-600 mt-1">{webglError}</p>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={mountRef}
      className="w-full h-full select-none outline-none"
      aria-label="Hình 3D xếp cont"
    />
  );
});
