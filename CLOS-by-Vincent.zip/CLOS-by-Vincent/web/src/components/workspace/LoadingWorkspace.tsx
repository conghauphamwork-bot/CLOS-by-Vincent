import React, { useMemo, useRef, useState } from 'react';
import {
  Anchor,
  ArrowDownToLine,
  BookmarkPlus,
  ChevronDown,
  ChevronUp,
  Copy,
  Eye,
  FileSpreadsheet,
  FileText,
  GripVertical,
  Hand,
  Layers,
  Lock,
  Move3d,
  Play,
  Plus,
  RefreshCw,
  RotateCw,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  Unlock,
  Search,
} from 'lucide-react';
import {
  AnchorMode,
  CargoSku,
  ContainerLoad,
  ContainerSpec,
  LoadingProject,
  OptimizationAlgorithm,
  PlacedCarton,
  RecalculationPreview,
  RotationPolicy,
  ServerValidation,
} from '../../types/clos';
import { api } from '../../api/client';
import { statusVi } from '../../lib/status';
import { CellValue, EditableGrid, parseNumberLoose } from '../common/EditableGrid';
import { applySkuValue, skuColumns, SkuField } from '../../lib/skuGrid';
import { exportStepByStepExcel } from '../../engine/excelService';
import { exportStepByStepPdf } from '../../engine/pdfService';
import {
  realignContainerAnchor,
  runOptimization,
} from '../../engine/optimizer';
import {
  computeContainerStats,
  computeLayerIndex,
  reconcileProjectQuantities,
} from '../../engine/reconciliation';
import {
  getPermittedOrientations,
  validateContainerLoad,
  validateProject,
} from '../../engine/validator';
import {
  CameraPreset,
  ContainerScene3D,
  ContainerScene3DHandle,
} from './ContainerScene3D';

interface LoadingWorkspaceProps {
  project: LoadingProject;
  specs: ContainerSpec[];
  onUpdateProject: (updated: LoadingProject, auditNote?: string) => void;
  onSaveTemplateFromContainer: (
    container: ContainerLoad,
    spec: ContainerSpec
  ) => void;
  sceneRef?: React.RefObject<ContainerScene3DHandle | null>;
  serverValidation?: ServerValidation;
  onNotify?: (msg: string, ms?: number) => void;
}

export const LoadingWorkspace: React.FC<LoadingWorkspaceProps> = ({
  project,
  specs,
  onUpdateProject,
  onSaveTemplateFromContainer,
  sceneRef: externalSceneRef,
  serverValidation,
  onNotify,
}) => {
  const internalSceneRef = useRef<ContainerScene3DHandle | null>(null);
  const sceneRef = externalSceneRef ?? internalSceneRef;

  const [activeContainerIdx, setActiveContainerIdx] = useState(0);
  const [selectedCartonId, setSelectedCartonId] = useState<string | null>(null);
  const [hoveredSkuId, setHoveredSkuId] = useState<string | null>(null);

  // 3D viewport dock controls
  const [dockExpanded, setDockExpanded] = useState(true);
  const [visibleMaxLayer, setVisibleMaxLayer] = useState(-1);
  const [explodeFactor, setExplodeFactor] = useState(0);
  const [showWireframeWalls, setShowWireframeWalls] = useState(true);
  const [showCogMarker, setShowCogMarker] = useState(true);
  const [dragModeEnabled, setDragModeEnabled] = useState(true);
  const [isDragOverCanvas, setIsDragOverCanvas] = useState(false);
  const [draggingSkuId, setDraggingSkuId] = useState<string | null>(null);
  const [dragPayload, setDragPayload] = useState<
    | { kind: 'pool'; skuId: string }
    | { kind: 'quick_add'; skuId: string }
    | { kind: 'new_sku_form' }
    | null
  >(null);
  const [autoIncrementOnDrop, setAutoIncrementOnDrop] = useState(false);
  const [liveDragCoords, setLiveDragCoords] = useState<{
    xMm: number;
    yMm: number;
    zMm: number;
    skuLabel: string;
  } | null>(null);

  // Right card tab: inspector | quick_sku
  const [rightPanelTab, setRightPanelTab] = useState<'inspector' | 'quick_sku'>(
    'inspector'
  );
  const [showQuickAddForm, setShowQuickAddForm] = useState(false);
  const [quickSkuForm, setQuickSkuForm] = useState({
    factorySku: '',
    customerSku: '',
    description: '',
    lengthMm: 1000,
    widthMm: 600,
    heightMm: 500,
    weightKg: 24,
    requiredQty: 8,
    stackable: true,
    rotationPolicy: 'upright_only' as RotationPolicy,
  });

  // Bottom drawer tab: legend | reconciliation | validation | layers
  const [bottomTab, setBottomTab] = useState<
    'legend' | 'reconciliation' | 'validation' | 'layers'
  >('legend');

  // Recalculation diff modal (never overwrite without review!)
  const [recalcPreview, setRecalcPreview] =
    useState<RecalculationPreview | null>(null);
  // Tìm mã hàng (dùng chung cho SL/Thêm mã, hàng chờ, chú giải, đối soát)
  const [skuQuery, setSkuQuery] = useState('');
  const matchSku = (id: string) => {
    const q = skuQuery.trim().toLowerCase();
    if (!q) return true;
    const sk = skuMap.get(id);
    return !!sk && [sk.factorySku, sk.customerSku, sk.description].some((v) => (v ?? '').toLowerCase().includes(q));
  };
  const searchBox = (cls = '') => (
    <div className={`relative ${cls}`}>
      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-1/2 -translate-y-1/2" />
      <input
        type="text"
        value={skuQuery}
        onChange={(e) => setSkuQuery(e.target.value)}
        placeholder="Tìm mã nhà máy, mã khách, mô tả…"
        className="w-full pl-7 pr-6 py-1.5 text-xs border border-slate-200 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
      {skuQuery && (
        <button onClick={() => setSkuQuery('')} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 text-xs" title="Xoá tìm kiếm">
          ✕
        </button>
      )}
    </div>
  );
  // Khoá nhiều cont
  const [pickMode, setPickMode] = useState(false);
  const [pickedConts, setPickedConts] = useState<Set<string>>(new Set());
  const lastPickIdx = useRef<number | null>(null);
  const applyLock = (lock: boolean) => {
    const ids = pickedConts;
    const labels = project.containers.filter((c) => ids.has(c.id)).map((c) => c.label.replace(/ \(.*\)$/, ''));
    onUpdateProject(
      {
        ...project,
        containers: project.containers.map((c) => (ids.has(c.id) ? { ...c, locked: lock } : c)),
        updatedAt: new Date().toISOString(),
      },
      `${lock ? 'Khoá' : 'Mở khoá'} ${ids.size} cont: ${labels.slice(0, 8).join(', ')}${labels.length > 8 ? '…' : ''}`
    );
    onNotify?.(`${lock ? 'Đã khoá' : 'Đã mở khoá'} ${ids.size} cont`, 2500);
    setPickedConts(new Set());
  };
  // Đang chờ máy chủ Python tính (null = rảnh)
  const [serverBusy, setServerBusy] = useState<string | null>(null);
  const [previewKind, setPreviewKind] = useState<'full' | 'incremental'>('incremental');

  const specsById = useMemo(
    () => new Map(specs.map((s) => [s.id, s])),
    [specs]
  );
  const skuMap = useMemo(
    () => new Map(project.skus.map((s) => [s.id, s])),
    [project.skus]
  );

  const safeIdx = Math.min(
    activeContainerIdx,
    Math.max(0, project.containers.length - 1)
  );
  const activeContainer: ContainerLoad | undefined = project.containers[safeIdx];
  const activeSpec: ContainerSpec =
    (activeContainer
      ? specsById.get(activeContainer.containerSpecId)
      : undefined) ??
    specsById.get(project.defaultContainerSpecId) ??
    specs[0];

  const allIssues = useMemo(
    () =>
      validateProject(
        project.containers,
        specsById,
        project.skus,
        project.optimizationConfig
      ),
    [project.containers, specsById, project.skus, project.optimizationConfig]
  );

  const activeContainerIssues = useMemo(
    () =>
      activeContainer
        ? validateContainerLoad(
            activeContainer,
            activeSpec,
            skuMap,
            project.optimizationConfig
          )
        : [],
    [activeContainer, activeSpec, skuMap, project.optimizationConfig]
  );

  const reconciliation = useMemo(
    () => reconcileProjectQuantities(project.skus, project.containers),
    [project.skus, project.containers]
  );
  const reconMap = useMemo(
    () => new Map(reconciliation.rows.map((r) => [r.skuId, r])),
    [reconciliation]
  );

  const activeStats = useMemo(
    () =>
      activeContainer
        ? computeContainerStats(activeContainer, activeSpec, skuMap)
        : null,
    [activeContainer, activeSpec, skuMap]
  );

  const selectedPlacement = useMemo(
    () =>
      activeContainer?.placements.find(
        (p) => p.instanceId === selectedCartonId
      ) ?? null,
    [activeContainer, selectedCartonId]
  );

  const selectedSku = selectedPlacement
    ? skuMap.get(selectedPlacement.skuId) ?? null
    : null;

  const updateContainer = (
    containerId: string,
    updater: (c: ContainerLoad) => ContainerLoad,
    auditAction: string,
    auditDetails: string
  ) => {
    const updatedContainers = project.containers.map((c) =>
      c.id === containerId ? updater(c) : c
    );
    onUpdateProject(
      {
        ...project,
        containers: updatedContainers,
        updatedAt: new Date().toISOString(),
      },
      `${auditAction}: ${auditDetails}`
    );
  };

  // Tính trên máy chủ Python, KHÔNG ghi đè: kết quả mở ra hộp duyệt trước
  const runServerCalc = async (mode: 'locked' | 'incremental') => {
    if (serverBusy) return;
    const algo = project.optimizationConfig.algorithm;
    setServerBusy(
      mode === 'locked'
        ? algo === 'hybrid_alns_ep'
          ? 'Đang xếp toàn bộ + cải thiện (khoảng 30 giây)…'
          : 'Đang xếp toàn bộ…'
        : 'Đang tính lại phần bị ảnh hưởng…'
    );
    try {
      const preview = await api.optimize(
        project,
        specs,
        mode,
        mode === 'incremental' ? 0 : undefined
      );
      setPreviewKind(mode === 'locked' ? 'full' : 'incremental');
      setRecalcPreview(preview);
    } catch (e) {
      onNotify?.(`⚠ ${(e as Error).message}`, 9000);
    } finally {
      setServerBusy(null);
    }
  };

  const handleRunFullOptimization = () => {
    void runServerCalc('locked');
  };

  const handleIncrementalRecalcPreview = () => {
    void runServerCalc('incremental');
  };

  const handleApplyRecalcPreview = () => {
    if (!recalcPreview) return;
    const v = recalcPreview.validation;
    if (
      v &&
      v.errors > 0 &&
      !window.confirm(
        `Kiểm tra độc lập báo ${v.errors} lỗi trong phương án này. Vẫn áp dụng?`
      )
    ) {
      return;
    }
    setSelectedCartonId(null);
    if (previewKind === 'full') setActiveContainerIdx(0);
    onUpdateProject(
      {
        ...project,
        containers: recalcPreview.proposedContainers,
        lastMetrics: recalcPreview.proposedMetrics,
        status: recalcPreview.proposedMetrics.feasible ? 'calculated' : 'draft',
        updatedAt: new Date().toISOString(),
      },
      previewKind === 'full'
        ? `Duyệt phương án xếp toàn bộ (engine Python, ${project.optimizationConfig.algorithm}): ${recalcPreview.proposedMetrics.containersUsed} cont, ${recalcPreview.proposedMetrics.volumeUtilizationPct.toFixed(1)}% thể tích, cận dưới ${recalcPreview.proposedMetrics.lowerBoundContainers}`
        : `Duyệt tính lại một phần: ${recalcPreview.summary}`
    );
    setRecalcPreview(null);
  };

  const handleAddEmptyContainer = () => {
    const nextNum = project.containers.length + 1;
    const spec =
      specsById.get(project.defaultContainerSpecId) ?? specs[0];
    const newC: ContainerLoad = {
      id: `cnt-${Date.now().toString(36)}-${nextNum}`,
      containerSpecId: spec.id,
      label: `Cont #${nextNum} (${spec.code})`,
      sequenceNumber: nextNum,
      placements: [],
    };
    onUpdateProject(
      {
        ...project,
        containers: [...project.containers, newC],
        updatedAt: new Date().toISOString(),
      },
      `Thêm cont trống ${newC.label}`
    );
    setActiveContainerIdx(project.containers.length);
  };

  const handleCopyContainer = () => {
    if (!activeContainer) return;
    // Check if remaining SKU quantities allow duplicating placements
    const remMap = new Map(
      reconciliation.rows.map((r) => [r.skuId, r.remainingQty])
    );
    const copiedPlacements: PlacedCarton[] = [];
    for (const p of activeContainer.placements) {
      const rem = remMap.get(p.skuId) ?? 0;
      if (rem > 0) {
        copiedPlacements.push({
          ...p,
          instanceId: `copy-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
          containerId: '',
        });
        remMap.set(p.skuId, rem - 1);
      }
    }
    const nextNum = project.containers.length + 1;
    const newId = `cnt-${Date.now().toString(36)}-${nextNum}`;
    const newC: ContainerLoad = {
      id: newId,
      containerSpecId: activeContainer.containerSpecId,
      label: `Cont #${nextNum} (${activeSpec.code})`,
      sequenceNumber: nextNum,
      placements: copiedPlacements.map((p) => ({ ...p, containerId: newId })),
    };
    onUpdateProject(
      {
        ...project,
        containers: [...project.containers, newC],
        updatedAt: new Date().toISOString(),
      },
      `Đã chép ${copiedPlacements.length} thùng còn chờ từ ${activeContainer.label} sang ${newC.label}`
    );
    setActiveContainerIdx(project.containers.length);
  };

  const handleMoveCarton = (
    instanceId: string,
    newX: number,
    newY: number,
    newZ: number
  ) => {
    if (!activeContainer) return;
    updateContainer(
      activeContainer.id,
      (c) => {
        const others = c.placements.filter((p) => p.instanceId !== instanceId);
        return {
          ...c,
          placements: c.placements.map((p) => {
            if (p.instanceId !== instanceId) return p;
            const updated: PlacedCarton = {
              ...p,
              xMm: Math.max(0, Math.min(activeSpec.internalLengthMm - p.dimXMm, newX)),
              yMm: Math.max(0, Math.min(activeSpec.internalHeightMm - p.dimYMm, newY)),
              zMm: Math.max(0, Math.min(activeSpec.internalWidthMm - p.dimZMm, newZ)),
              anchorMode: 'free',
            };
            updated.layerIndex = computeLayerIndex(updated, others);
            return updated;
          }),
        };
      },
      'MANUAL_MOVE',
      `Dời thùng ${instanceId} tới (${Math.round(newX)}, ${Math.round(newY)}, ${Math.round(newZ)})`
    );
  };

  const handleRotateSelected = () => {
    if (!activeContainer || !selectedPlacement || !selectedSku) return;
    const orientations = project.optimizationConfig.respectRotation
      ? getPermittedOrientations(selectedSku)
      : getPermittedOrientations({ ...selectedSku, rotationPolicy: 'all' });

    if (orientations.length <= 1) return;
    const currentIdx = orientations.findIndex(
      (o) =>
        Math.abs(o.dimXMm - selectedPlacement.dimXMm) < 1 &&
        Math.abs(o.dimYMm - selectedPlacement.dimYMm) < 1 &&
        Math.abs(o.dimZMm - selectedPlacement.dimZMm) < 1
    );
    const next = orientations[(currentIdx + 1) % orientations.length];

    updateContainer(
      activeContainer.id,
      (c) => ({
        ...c,
        placements: c.placements.map((p) =>
          p.instanceId === selectedPlacement.instanceId
            ? {
                ...p,
                dimXMm: next.dimXMm,
                dimYMm: next.dimYMm,
                dimZMm: next.dimZMm,
                xMm: Math.min(p.xMm, activeSpec.internalLengthMm - next.dimXMm),
                yMm: Math.min(p.yMm, activeSpec.internalHeightMm - next.dimYMm),
                zMm: Math.min(p.zMm, activeSpec.internalWidthMm - next.dimZMm),
                rotationLabel: next.label,
              }
            : p
        ),
      }),
      'MANUAL_ROTATE',
      `Xoay ${selectedSku.factorySku} sang ${next.label}`
    );
  };

  const handleDropSelectedToSupport = () => {
    if (!activeContainer || !selectedPlacement) return;
    const others = activeContainer.placements.filter(
      (p) => p.instanceId !== selectedPlacement.instanceId
    );
    let supportY = 0;
    for (const o of others) {
      const overlapX =
        Math.min(
          selectedPlacement.xMm + selectedPlacement.dimXMm,
          o.xMm + o.dimXMm
        ) - Math.max(selectedPlacement.xMm, o.xMm);
      const overlapZ =
        Math.min(
          selectedPlacement.zMm + selectedPlacement.dimZMm,
          o.zMm + o.dimZMm
        ) - Math.max(selectedPlacement.zMm, o.zMm);
      if (
        overlapX > 5 &&
        overlapZ > 5 &&
        o.yMm + o.dimYMm <= selectedPlacement.yMm + 2
      ) {
        supportY = Math.max(supportY, o.yMm + o.dimYMm);
      }
    }
    handleMoveCarton(
      selectedPlacement.instanceId,
      selectedPlacement.xMm,
      supportY,
      selectedPlacement.zMm
    );
  };

  const handleDeleteSelected = () => {
    if (!activeContainer || !selectedPlacement) return;
    const skuCode = selectedSku?.factorySku ?? selectedPlacement.skuId;
    updateContainer(
      activeContainer.id,
      (c) => ({
        ...c,
        placements: c.placements.filter(
          (p) => p.instanceId !== selectedPlacement.instanceId
        ),
      }),
      'REMOVE_CARTON',
      `Trả 1 thùng ${skuCode} về hàng chờ`
    );
    setSelectedCartonId(null);
  };

  const handleInsertRemainingUnit = (sku: CargoSku) => {
    if (!activeContainer) return;
    const row = reconciliation.rows.find((r) => r.skuId === sku.id);
    if (!row || row.remainingQty <= 0) return;

    // Run single-unit placement attempt inside active container using current anchor mode
    const singleSkuList: CargoSku[] = [{ ...sku, requiredQty: 1 }];
    const tempResult = runOptimization(
      singleSkuList,
      [activeContainer],
      specs,
      activeContainer.containerSpecId,
      { ...project.optimizationConfig, autoAddContainers: false },
      { remainingOnly: true }
    );

    const updatedTarget = tempResult.containers[0];
    if (
      updatedTarget &&
      updatedTarget.placements.length > activeContainer.placements.length
    ) {
      const newlyAdded =
        updatedTarget.placements[updatedTarget.placements.length - 1];
      updateContainer(
        activeContainer.id,
        (c) => ({
          ...c,
          placements: [...c.placements, newlyAdded],
        }),
        'MANUAL_INSERT',
        `Thêm 1 thùng ${sku.factorySku} sang ${activeContainer.label} (${project.optimizationConfig.anchorMode} canh)`
      );
      setSelectedCartonId(newlyAdded.instanceId);
    } else {
      // Fallback: place at open front/floor zone for manual positioning so user can drag/adjust
      const maxX = activeContainer.placements.reduce(
        (m, p) => Math.max(m, p.xMm + p.dimXMm),
        0
      );
      const fallbackX = Math.min(
        maxX,
        Math.max(0, activeSpec.internalLengthMm - sku.lengthMm)
      );
      const fallbackZ =
        project.optimizationConfig.anchorMode === 'right'
          ? Math.max(0, activeSpec.internalWidthMm - sku.widthMm)
          : project.optimizationConfig.anchorMode === 'center'
            ? Math.max(0, (activeSpec.internalWidthMm - sku.widthMm) / 2)
            : 0;
      const newCarton: PlacedCarton = {
        instanceId: `man-${Date.now().toString(36)}`,
        skuId: sku.id,
        containerId: activeContainer.id,
        xMm: fallbackX,
        yMm: 0,
        zMm: fallbackZ,
        dimXMm: sku.lengthMm,
        dimYMm: sku.heightMm,
        dimZMm: sku.widthMm,
        rotationLabel: 'D×C×R (thủ công)',
        layerIndex: 0,
        anchorMode: project.optimizationConfig.anchorMode,
      };
      updateContainer(
        activeContainer.id,
        (c) => ({
          ...c,
          placements: [...c.placements, newCarton],
        }),
        'MANUAL_INSERT',
        `Đặt 1 thùng ${sku.factorySku} để chỉnh tay`
      );
      setSelectedCartonId(newCarton.instanceId);
    }
  };

  const handleAnchorChange = (anchor: AnchorMode) => {
    onUpdateProject(
      {
        ...project,
        optimizationConfig: {
          ...project.optimizationConfig,
          anchorMode: anchor,
        },
      },
      `Đổi canh mặc định sang ${anchor.toUpperCase()}`
    );
  };

  const handleRealignActiveContainer = (anchor: 'left' | 'right' | 'center') => {
    if (!activeContainer) return;
    const realigned = realignContainerAnchor(
      activeContainer,
      activeSpec,
      anchor
    );
    updateContainer(
      activeContainer.id,
      () => realigned,
      'ANCHOR_REALIGN',
      `Dời nhóm hàng trong ${activeContainer.label} sang ${anchor.toUpperCase()} canh`
    );
  };

  const SKU_QUICK_PALETTE = [
    '#2563EB',
    '#0D9488',
    '#D97706',
    '#7C3AED',
    '#059669',
    '#DC2626',
    '#0284C7',
  ];

  const createSkuRecordFromForm = (overrideQty?: number): CargoSku => {
    const code =
      quickSkuForm.factorySku.trim() || `SKU-${project.skus.length + 1}`;
    const cust = quickSkuForm.customerSku.trim() || code;
    return {
      id: `sku-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 5)}`,
      factorySku: code,
      customerSku: cust,
      description: quickSkuForm.description.trim() || code,
      lengthMm: Math.max(50, Number(quickSkuForm.lengthMm) || 500),
      widthMm: Math.max(50, Number(quickSkuForm.widthMm) || 500),
      heightMm: Math.max(50, Number(quickSkuForm.heightMm) || 500),
      weightKg: Math.max(0.5, Number(quickSkuForm.weightKg) || 10),
      requiredQty: Math.max(
        1,
        Math.round(overrideQty ?? (Number(quickSkuForm.requiredQty) || 1))
      ),
      stackable: quickSkuForm.stackable,
      maxStackLayers: quickSkuForm.stackable ? 99 : 1,
      maxStackWeightKg: quickSkuForm.stackable ? 220 : 0,
      rotationPolicy: quickSkuForm.rotationPolicy,
      fragile: false,
      palletized: false,
      color: SKU_QUICK_PALETTE[project.skus.length % SKU_QUICK_PALETTE.length],
    };
  };

  const handleDropSkuOnto3D = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOverCanvas(false);

    // Resolve payload from dataTransfer JSON, React state, or plain skuId fallback
    let resolved = dragPayload;
    const raw = e.dataTransfer.getData('text/plain');
    if (!resolved && raw) {
      try {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed.kind === 'string') {
          resolved = parsed;
        }
      } catch {
        resolved = { kind: 'pool', skuId: raw };
      }
    } else if (!resolved && draggingSkuId) {
      resolved = { kind: 'pool', skuId: draggingSkuId };
    }

    setDragPayload(null);
    setDraggingSkuId(null);
    if (!resolved || !activeContainer) return;

    // Case 1: Dragged directly from the "+ Add SKU" form
    if (resolved.kind === 'new_sku_form') {
      const targetCode =
        quickSkuForm.factorySku.trim() || `SKU-${project.skus.length + 1}`;
      const existing = project.skus.find(
        (s) => s.factorySku.toLowerCase() === targetCode.toLowerCase()
      );

      let targetSku: CargoSku;
      let nextSkus: CargoSku[];
      let auditVerb: string;

      if (existing) {
        const existingRow = reconciliation.rows.find(
          (r) => r.skuId === existing.id
        );
        const shouldBump =
          autoIncrementOnDrop || !existingRow || existingRow.remainingQty <= 0;
        targetSku = shouldBump
          ? { ...existing, requiredQty: existing.requiredQty + 1 }
          : existing;
        nextSkus = project.skus.map((s) =>
          s.id === existing.id ? targetSku : s
        );
        auditVerb = shouldBump
          ? `Tự tăng ${targetSku.factorySku} (Yêu cầu -> ${targetSku.requiredQty}) & đặt bằng kéo thả 3D`
          : `Đặt ${targetSku.factorySku} bằng kéo thả 3D`;
      } else {
        targetSku = createSkuRecordFromForm(
          Math.max(1, Number(quickSkuForm.requiredQty) || 1)
        );
        nextSkus = [...project.skus, targetSku];
        if (!quickSkuForm.factorySku.trim()) {
          setQuickSkuForm((prev) => ({
            ...prev,
            factorySku: targetSku.factorySku,
            customerSku: prev.customerSku || targetSku.customerSku,
          }));
        }
        auditVerb = `Tạo mã ${targetSku.factorySku} (SL ${targetSku.requiredQty}) & đặt thùng đầu bằng kéo thả 3D`;
      }

      const pos = sceneRef.current?.resolveDropPosition(
        e.clientX,
        e.clientY,
        targetSku.lengthMm,
        targetSku.heightMm,
        targetSku.widthMm
      ) ?? { xMm: 0, yMm: 0, zMm: 0 };

      const candidate: PlacedCarton = {
        instanceId: `dnd-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 5)}`,
        skuId: targetSku.id,
        containerId: activeContainer.id,
        xMm: pos.xMm,
        yMm: pos.yMm,
        zMm: pos.zMm,
        dimXMm: targetSku.lengthMm,
        dimYMm: targetSku.heightMm,
        dimZMm: targetSku.widthMm,
        rotationLabel: 'D×C×R (chuẩn)',
        layerIndex: 0,
        anchorMode: 'free',
      };
      candidate.layerIndex = computeLayerIndex(
        candidate,
        activeContainer.placements
      );

      const nextContainers = project.containers.map((c) =>
        c.id === activeContainer.id
          ? { ...c, placements: [...c.placements, candidate] }
          : c
      );

      onUpdateProject(
        {
          ...project,
          skus: nextSkus,
          containers: nextContainers,
          updatedAt: new Date().toISOString(),
        },
        `${auditVerb} tại (${Math.round(pos.xMm)}, ${Math.round(pos.yMm)}, ${Math.round(pos.zMm)})`
      );
      setSelectedCartonId(candidate.instanceId);
      return;
    }

    // Case 2: Dragged from Remaining Pool OR from Qty / Add SKU list card
    const sku = skuMap.get(resolved.skuId);
    if (!sku) return;
    const row = reconciliation.rows.find((r) => r.skuId === sku.id);

    if (resolved.kind === 'pool' && (!row || row.remainingQty <= 0)) {
      return;
    }

    const shouldIncrementReq =
      resolved.kind === 'quick_add' &&
      (autoIncrementOnDrop || !row || row.remainingQty <= 0);

    const updatedSku = shouldIncrementReq
      ? { ...sku, requiredQty: sku.requiredQty + 1 }
      : sku;

    const pos = sceneRef.current?.resolveDropPosition(
      e.clientX,
      e.clientY,
      sku.lengthMm,
      sku.heightMm,
      sku.widthMm
    ) ?? { xMm: 0, yMm: 0, zMm: 0 };

    const candidate: PlacedCarton = {
      instanceId: `dnd-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 5)}`,
      skuId: sku.id,
      containerId: activeContainer.id,
      xMm: pos.xMm,
      yMm: pos.yMm,
      zMm: pos.zMm,
      dimXMm: sku.lengthMm,
      dimYMm: sku.heightMm,
      dimZMm: sku.widthMm,
      rotationLabel: 'D×C×R (chuẩn)',
      layerIndex: 0,
      anchorMode: 'free',
    };
    candidate.layerIndex = computeLayerIndex(
      candidate,
      activeContainer.placements
    );

    const nextSkus = shouldIncrementReq
      ? project.skus.map((s) => (s.id === sku.id ? updatedSku : s))
      : project.skus;

    const nextContainers = project.containers.map((c) =>
      c.id === activeContainer.id
        ? { ...c, placements: [...c.placements, candidate] }
        : c
    );

    onUpdateProject(
      {
        ...project,
        skus: nextSkus,
        containers: nextContainers,
        updatedAt: new Date().toISOString(),
      },
      shouldIncrementReq
        ? `Kéo thả ${sku.factorySku} từ bảng SL/Thêm mã (tự tăng yêu cầu -> ${updatedSku.requiredQty}) lên ${activeContainer.label}`
        : `Thả ${sku.factorySku} lên ${activeContainer.label} tại (${Math.round(pos.xMm)}, ${Math.round(pos.yMm)}, ${Math.round(pos.zMm)})`
    );
    setSelectedCartonId(candidate.instanceId);
  };

  const handleQuickAdjustSkuQty = (skuId: string, nextQty: number) => {
    const cleanQty = Math.max(0, Math.round(nextQty));
    const target = skuMap.get(skuId);
    const updatedSkus = project.skus.map((s) =>
      s.id === skuId ? { ...s, requiredQty: cleanQty } : s
    );
    onUpdateProject(
      {
        ...project,
        skus: updatedSkus,
        updatedAt: new Date().toISOString(),
      },
      `Sửa số yêu cầu ${target?.factorySku ?? skuId} sang ${cleanQty} ở màn 3D`
    );
  };

  const handleQuickAddSku = (e: React.FormEvent) => {
    e.preventDefault();
    const code = quickSkuForm.factorySku.trim();
    if (!code) return;

    const addQty = Math.max(1, Math.round(Number(quickSkuForm.requiredQty) || 1));
    const existing = project.skus.find(
      (s) => s.factorySku.toLowerCase() === code.toLowerCase()
    );

    if (existing) {
      const nextQty = existing.requiredQty + addQty;
      const updatedSkus = project.skus.map((s) =>
        s.id === existing.id ? { ...s, requiredQty: nextQty } : s
      );
      onUpdateProject(
        {
          ...project,
          skus: updatedSkus,
          updatedAt: new Date().toISOString(),
        },
        `Tự tăng mã có sẵn ${existing.factorySku} (+${addQty} -> ${nextQty} thùng) từ bảng SL/Thêm mã`
      );
    } else {
      const created = createSkuRecordFromForm(addQty);
      onUpdateProject(
        {
          ...project,
          skus: [...project.skus, created],
          updatedAt: new Date().toISOString(),
        },
        `Thêm mã mới ${created.factorySku} (${created.requiredQty} thùng) ngay ở màn 3D`
      );
    }

    setQuickSkuForm({
      ...quickSkuForm,
      factorySku: '',
      customerSku: '',
      description: '',
    });
    setShowQuickAddForm(false);
  };

  const handleExportStepByStep = () => {
    exportStepByStepExcel(project, specsById, activeContainer?.id);
    onUpdateProject(
      { ...project, updatedAt: new Date().toISOString() },
      `Đã xuất Excel xếp từng bước (${activeContainer?.label ?? project.code})`
    );
  };

  const handleExportStepByStepPdf = () => {
    exportStepByStepPdf(project, specsById, {
      containerFilterId: activeContainer?.id,
    });
    onUpdateProject(
      { ...project, updatedAt: new Date().toISOString() },
      `Đã xuất PDF xếp từng bước 3D & kiểm tra (${activeContainer?.label ?? project.code})`
    );
  };

  const layerGroups = useMemo(() => {
    if (!activeContainer) return [];
    const map = new Map<
      number,
      { layer: number; count: number; weightKg: number; skus: Set<string> }
    >();
    for (const p of activeContainer.placements) {
      const entry = map.get(p.layerIndex) ?? {
        layer: p.layerIndex,
        count: 0,
        weightKg: 0,
        skus: new Set<string>(),
      };
      entry.count++;
      entry.weightKg += skuMap.get(p.skuId)?.weightKg ?? 0;
      entry.skus.add(skuMap.get(p.skuId)?.factorySku ?? p.skuId);
      map.set(p.layerIndex, entry);
    }
    return Array.from(map.values()).sort((a, b) => a.layer - b.layer);
  }, [activeContainer, skuMap]);

  return (
    <div className="flex flex-col gap-4 h-full">
      {/* Top Workspace Action Strip */}
      <div className="bg-white border border-slate-200 rounded-lg px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Container Switcher Tabs */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {project.containers.map((c, idx) => {
            const cIssues = allIssues.filter(
              (i) => i.containerId === c.id && i.severity === 'error'
            ).length;
            const isActive = idx === safeIdx;
            const isPicked = pickedConts.has(c.id);
            return (
              <button
                key={c.id}
                onClick={(e) => {
                  // Chọn nhiều: đang ở chế độ chọn, hoặc giữ Ctrl/Cmd; giữ Shift để chọn cả dải
                  if (pickMode || e.ctrlKey || e.metaKey || e.shiftKey) {
                    if (!pickMode) setPickMode(true);
                    setPickedConts((prev) => {
                      const next = new Set(prev);
                      if (e.shiftKey && lastPickIdx.current !== null) {
                        const [a, b] = [Math.min(lastPickIdx.current, idx), Math.max(lastPickIdx.current, idx)];
                        for (let i = a; i <= b; i++) next.add(project.containers[i].id);
                      } else if (next.has(c.id)) next.delete(c.id);
                      else next.add(c.id);
                      return next;
                    });
                    lastPickIdx.current = idx;
                    return;
                  }
                  setActiveContainerIdx(idx);
                  setSelectedCartonId(null);
                  setVisibleMaxLayer(-1);
                }}
                className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap shrink-0 flex items-center gap-1.5 border transition-colors ${
                  pickMode
                    ? isPicked
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-blue-50'
                    : isActive
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {pickMode && (
                  <input type="checkbox" readOnly checked={isPicked} className="w-3 h-3 pointer-events-none" />
                )}
                {c.locked && <Lock className="w-3 h-3" />}
                <span>{c.label}</span>
                <span className="font-mono tabular-nums opacity-75">
                  ({c.placements.length})
                </span>
                {cIssues > 0 && (
                  <span className="text-red-400 font-mono">!</span>
                )}
              </button>
            );
          })}
          <button
            onClick={handleAddEmptyContainer}
            className="px-2.5 py-1.5 rounded-md text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 flex items-center gap-1 whitespace-nowrap shrink-0"
            title="Thêm cont mới"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Thêm cont</span>
          </button>
          <button
            onClick={() => {
              setPickMode((v) => !v);
              setPickedConts(new Set());
              lastPickIdx.current = null;
            }}
            className={`px-2.5 py-1.5 rounded-md text-xs font-medium border flex items-center gap-1 whitespace-nowrap shrink-0 ${
              pickMode ? 'bg-blue-600 text-white border-blue-600' : 'text-slate-700 bg-white border-slate-200 hover:bg-slate-50'
            }`}
            title="Chọn nhiều cont để khoá / mở khoá cùng lúc (hoặc giữ Ctrl/Cmd khi bấm cont, Shift để chọn cả dải)"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>{pickMode ? 'Xong' : 'Khoá nhiều cont'}</span>
          </button>
          {activeContainer && !pickMode && (
            <button
              onClick={handleCopyContainer}
              className="px-2.5 py-1.5 rounded-md text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 flex items-center gap-1 whitespace-nowrap shrink-0"
              title="Chép cách xếp của cont này cho số còn lại"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Chép</span>
            </button>
          )}
        </div>

        {pickMode && (
          <div className="w-full flex flex-wrap items-center gap-2 text-xs bg-blue-50 border border-blue-200 rounded-md px-3 py-2">
            <span className="font-medium text-blue-950">
              Đã chọn {pickedConts.size}/{project.containers.length} cont
            </span>
            <button onClick={() => setPickedConts(new Set(project.containers.map((c) => c.id)))} className="px-2 py-1 rounded border border-blue-300 bg-white hover:bg-blue-100">
              Chọn tất cả
            </button>
            <button onClick={() => setPickedConts(new Set())} className="px-2 py-1 rounded border border-blue-300 bg-white hover:bg-blue-100">
              Bỏ chọn
            </button>
            <span className="text-blue-300">|</span>
            <button
              disabled={!pickedConts.size}
              onClick={() => applyLock(true)}
              className="px-2.5 py-1 rounded bg-slate-900 text-white font-medium disabled:opacity-40 flex items-center gap-1"
            >
              <Lock className="w-3 h-3" /> Khoá {pickedConts.size || ''} cont
            </button>
            <button
              disabled={!pickedConts.size}
              onClick={() => applyLock(false)}
              className="px-2.5 py-1 rounded border border-slate-300 bg-white font-medium disabled:opacity-40 flex items-center gap-1"
            >
              <Unlock className="w-3 h-3" /> Mở khoá
            </button>
            <span className="text-blue-800/80">
              Cont đã khoá được giữ nguyên khi bấm Xếp tự động / Tính lại.
            </span>
          </div>
        )}

        {/* Optimization & Anchor Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          <select
            aria-label="Thuật toán"
            value={project.optimizationConfig.algorithm}
            onChange={(e) =>
              onUpdateProject({
                ...project,
                optimizationConfig: {
                  ...project.optimizationConfig,
                  algorithm: e.target.value as OptimizationAlgorithm,
                },
              })
            }
            className="text-xs border border-slate-200 rounded-md px-2.5 py-1.5 bg-white text-slate-800 font-medium"
          >
            <option value="hybrid_alns_ep">Xếp khối + cải thiện (~30 giây) – nên dùng</option>
            <option value="extreme_points">Xếp khối nhanh (10 biến thể)</option>
            <option value="maximal_spaces">Xếp khối nhanh – hộc trống tối đa</option>
            <option value="bfd">Xếp khối nhanh – vừa khít nhất</option>
            <option value="ffd">FFD – mốc so sánh</option>
          </select>

          <div className="flex items-center bg-slate-100 p-0.5 rounded-md border border-slate-200">
            {(['left', 'center', 'right'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => handleAnchorChange(mode)}
                className={`px-2.5 py-1 text-xs font-medium rounded whitespace-nowrap shrink-0 capitalize transition-colors ${
                  project.optimizationConfig.anchorMode === mode
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Canh hàng trong cont"
              >
                {{ left: 'Sát trái', center: 'Giữa', right: 'Sát phải' }[mode]}
              </button>
            ))}
          </div>

          <button
            onClick={handleIncrementalRecalcPreview}
            disabled={!!serverBusy}
            className="disabled:opacity-50 px-3 py-1.5 rounded-md text-xs font-medium bg-white border border-slate-300 text-slate-800 hover:bg-slate-50 flex items-center gap-1.5 whitespace-nowrap shrink-0"
            title="Giữ các thùng còn hợp lệ, xem trước phần thay đổi"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Tính lại</span>
          </button>


          <button
            onClick={handleExportStepByStepPdf}
            className="px-3 py-1.5 rounded-md text-xs font-medium bg-white border border-blue-600 text-blue-800 hover:bg-blue-50 flex items-center gap-1.5 whitespace-nowrap shrink-0"
            title="Xuất PDF xếp từng bước 3D & kiểm tra (kiểu CargoWiz)"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>PDF từng bước</span>
          </button>

          <button
            onClick={handleRunFullOptimization}
            disabled={!!serverBusy}
            className="disabled:opacity-50 px-3.5 py-1.5 rounded-md text-xs font-medium bg-blue-700 text-white hover:bg-blue-800 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Xếp tự động</span>
          </button>
        </div>
      </div>

      {/* Main Split: Dominant 3D Viewport + Precision Inspector */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
        {/* 3D Viewport Frame (9 cols on xl) */}
        <div className="xl:col-span-9 bg-white border border-slate-200 rounded-lg overflow-hidden flex flex-col">
          {/* Viewport Spec Header */}
          <div className="px-4 py-2.5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4 bg-slate-50/60">
            <div className="flex items-center gap-3 text-xs text-slate-600">
              <span className="font-semibold text-slate-900">
                {activeContainer ? activeContainer.label : 'Chưa có cont'}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">
                {activeSpec.internalLengthMm} × {activeSpec.internalWidthMm} ×{' '}
                {activeSpec.internalHeightMm} mm
              </span>
              {activeStats && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums text-slate-900 font-medium">
                    Thể tích {activeStats.volumeUtilizationPct.toFixed(1)}%
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums text-slate-900 font-medium">
                    Tải {activeStats.totalCargoWeightKg.toFixed(0)} /{' '}
                    {activeSpec.maxPayloadKg} kg (
                    {activeStats.payloadUtilizationPct.toFixed(1)}%)
                  </span>
                  <span aria-hidden="true">·</span>
                  <span
                    className={`font-medium ${
                      activeStats.cogBalanceOk
                        ? 'text-emerald-700'
                        : 'text-amber-700'
                    }`}
                  >
                    {activeStats.cogBalanceOk ? 'Trọng tâm cân' : 'Trọng tâm lệch'}
                  </span>
                </>
              )}
            </div>

            <div className="flex items-center gap-2">
              {activeContainer && (
                <>
                  <button
                    onClick={() =>
                      updateContainer(
                        activeContainer.id,
                        (c) => ({ ...c, locked: !c.locked }),
                        activeContainer.locked ? 'UNLOCK' : 'LOCK',
                        activeContainer.label
                      )
                    }
                    className="px-2.5 py-1 rounded text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 flex items-center gap-1 whitespace-nowrap shrink-0"
                  >
                    {activeContainer.locked ? (
                      <Unlock className="w-3 h-3" />
                    ) : (
                      <Lock className="w-3 h-3" />
                    )}
                    <span>{activeContainer.locked ? 'Mở khoá' : 'Khoá cont'}</span>
                  </button>
                  <button
                    onClick={() =>
                      onSaveTemplateFromContainer(activeContainer, activeSpec)
                    }
                    className="px-2.5 py-1 rounded text-xs font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 flex items-center gap-1 whitespace-nowrap shrink-0"
                  >
                    <BookmarkPlus className="w-3 h-3" />
                    <span>Lưu mẫu</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Dedicated 3D Canvas Container with Drop Target & Bottom Collapsible Control Dock */}
          <div
            className={`relative w-full h-[500px] bg-[#e8edf3] transition-shadow ${
              isDragOverCanvas ? 'ring-2 ring-inset ring-blue-600' : ''
            }`}
            onDragOver={(e) => {
              e.preventDefault();
              e.dataTransfer.dropEffect = 'copy';
              if (!isDragOverCanvas) setIsDragOverCanvas(true);
            }}
            onDragLeave={(e) => {
              if (!e.currentTarget.contains(e.relatedTarget as Node)) {
                setIsDragOverCanvas(false);
              }
            }}
            onDrop={handleDropSkuOnto3D}
          >
            {activeContainer ? (
              <ContainerScene3D
                ref={sceneRef}
                container={activeContainer}
                spec={activeSpec}
                skus={project.skus}
                selectedCartonId={selectedCartonId}
                hoveredSkuId={hoveredSkuId}
                visibleMaxLayer={visibleMaxLayer}
                explodeFactor={explodeFactor}
                showWireframeWalls={showWireframeWalls}
                showCogMarker={showCogMarker}
                dragModeEnabled={dragModeEnabled}
                issues={activeContainerIssues}
                onSelectCarton={setSelectedCartonId}
                onMoveCarton={handleMoveCarton}
                onDragStatusChange={setLiveDragCoords}
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center text-slate-600 gap-2">
                <p className="text-sm font-medium">
                  Dự án chưa có cont nào.
                </p>
                <button
                  onClick={handleRunFullOptimization}
                  className="px-4 py-2 text-xs font-medium bg-blue-700 text-white rounded-md"
                >
                  Xếp tự động
                </button>
              </div>
            )}

            {isDragOverCanvas && (
              <div className="pointer-events-none absolute top-3 left-1/2 -translate-x-1/2 z-20 bg-blue-700 text-white text-xs font-medium px-3 py-1.5 rounded-md shadow">
                {dragPayload?.kind === 'quick_add' ||
                dragPayload?.kind === 'new_sku_form'
                  ? 'Thả xuống sàn hoặc mặt thùng để đặt & tự tăng (+1) số lượng'
                  : 'Thả xuống sàn cont hoặc mặt thùng để đặt'}
              </div>
            )}

            {liveDragCoords && (
              <div className="pointer-events-none absolute top-3 left-3 z-20 bg-slate-900 text-white text-xs font-mono tabular-nums px-3 py-1.5 rounded-md shadow">
                {liveDragCoords.skuLabel} · X:{Math.round(liveDragCoords.xMm)} ·
                Y:{Math.round(liveDragCoords.yMm)} · Z:
                {Math.round(liveDragCoords.zMm)} mm
              </div>
            )}

            {/* Collapsible Bottom Control Dock (Zero Mid-Screen Occlusion) */}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center max-w-[95%]">
              <button
                onClick={() => setDockExpanded((v) => !v)}
                className="px-3 py-1 bg-slate-900 text-white text-[11px] font-medium rounded-t-md flex items-center gap-1 shadow-sm"
              >
                {dockExpanded ? (
                  <ChevronDown className="w-3 h-3" />
                ) : (
                  <ChevronUp className="w-3 h-3" />
                )}
                <span>{dockExpanded ? 'Ẩn công cụ 3D' : 'Hiện công cụ 3D'}</span>
              </button>

              {dockExpanded && (
                <div className="bg-white/95 border border-slate-200 rounded-lg shadow-md px-3 py-2 flex flex-wrap items-center gap-3 text-xs">
                  {/* Camera Presets */}
                  <div className="flex items-center gap-1 border-r border-slate-200 pr-3">
                    {(
                      [
                        ['iso', 'Góc 3D'],
                        ['side', 'Cạnh'],
                        ['top', 'Trên xuống'],
                        ['doors', 'Từ cửa'],
                      ] as Array<[CameraPreset, string]>
                    ).map(([preset, label]) => (
                      <button
                        key={preset}
                        onClick={() => sceneRef.current?.setCameraPreset(preset)}
                        className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 font-medium whitespace-nowrap shrink-0"
                      >
                        {label}
                      </button>
                    ))}
                  </div>

                  {/* Layer Slicer */}
                  <div className="flex items-center gap-2 border-r border-slate-200 pr-3">
                    <Layers className="w-3.5 h-3.5 text-slate-500" />
                    <span className="text-slate-600 whitespace-nowrap">
                      Lớp:
                    </span>
                    <select
                      aria-label="Lọc lớp hiển thị"
                      value={visibleMaxLayer}
                      onChange={(e) =>
                        setVisibleMaxLayer(Number(e.target.value))
                      }
                      className="border border-slate-200 rounded px-1.5 py-0.5 text-xs bg-white font-mono"
                    >
                      <option value={-1}>Tất cả</option>
                      {layerGroups.map((g) => (
                        <option key={g.layer} value={g.layer}>
                          Tới lớp{g.layer + 1}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Explode Slider */}
                  <div className="flex items-center gap-2 border-r border-slate-200 pr-3">
                    <span className="text-slate-600 whitespace-nowrap">
                      Tách lớp
                    </span>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={explodeFactor}
                      onChange={(e) => setExplodeFactor(Number(e.target.value))}
                      className="w-20 accent-blue-700"
                      aria-label="Tách các lớp theo chiều cao"
                    />
                  </div>

                  {/* Wall & CoG & Drag toggles */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setShowWireframeWalls((v) => !v)}
                      className={`px-2 py-1 rounded border text-xs font-medium flex items-center gap-1 whitespace-nowrap shrink-0 ${
                        showWireframeWalls
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-700 border-slate-200'
                      }`}
                    >
                      <Eye className="w-3 h-3" />
                      <span>Xuyên thấu</span>
                    </button>

                    <button
                      onClick={() => setShowCogMarker((v) => !v)}
                      className={`px-2 py-1 rounded border text-xs font-medium whitespace-nowrap shrink-0 ${
                        showCogMarker
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-700 border-slate-200'
                      }`}
                    >
                      Trọng tâm
                    </button>

                    <button
                      onClick={() => setDragModeEnabled((v) => !v)}
                      className={`px-2 py-1 rounded border text-xs font-medium flex items-center gap-1 whitespace-nowrap shrink-0 ${
                        dragModeEnabled
                          ? 'bg-blue-700 text-white border-blue-700'
                          : 'bg-white text-slate-700 border-slate-200'
                      }`}
                      title="Kéo thùng đang chọn trên mặt sàn/lớp"
                    >
                      <Hand className="w-3 h-3" />
                      <span>{dragModeEnabled ? 'Kéo 3D: bật' : 'Kéo 3D'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Side Panel: Tabbed Cargo Inspector & Direct Qty / Add SKU Card (3 cols on xl) */}
        <div className="xl:col-span-3 bg-white border border-slate-200 rounded-lg p-4 flex flex-col gap-3">
          {/* Card Header with Direct Tab Switch */}
          <div className="flex items-center justify-between border-b border-slate-200 pb-2.5 gap-2">
            <div className="flex items-center gap-1 p-0.5 bg-slate-100 rounded-md flex-1">
              <button
                onClick={() => setRightPanelTab('inspector')}
                className={`flex-1 py-1 px-2 text-xs font-medium rounded whitespace-nowrap transition-colors flex items-center justify-center gap-1 ${
                  rightPanelTab === 'inspector'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Move3d className="w-3.5 h-3.5" />
                <span>Chi tiết thùng</span>
              </button>
              <button
                onClick={() => setRightPanelTab('quick_sku')}
                className={`flex-1 py-1 px-2 text-xs font-medium rounded whitespace-nowrap transition-colors flex items-center justify-center gap-1 ${
                  rightPanelTab === 'quick_sku'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>SL / Thêm mã</span>
              </button>
            </div>

            {activeContainer && rightPanelTab === 'inspector' && (
              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => handleRealignActiveContainer('left')}
                  className="px-1.5 py-0.5 text-[11px] border border-slate-200 rounded hover:bg-slate-100"
                  title="Dồn hàng sát vách trái"
                >
                  T
                </button>
                <button
                  onClick={() => handleRealignActiveContainer('center')}
                  className="px-1.5 py-0.5 text-[11px] border border-slate-200 rounded hover:bg-slate-100"
                  title="Canh hàng giữa cont"
                >
                  G
                </button>
                <button
                  onClick={() => handleRealignActiveContainer('right')}
                  className="px-1.5 py-0.5 text-[11px] border border-slate-200 rounded hover:bg-slate-100"
                  title="Dồn hàng sát vách phải"
                >
                  P
                </button>
              </div>
            )}
          </div>

          {rightPanelTab === 'inspector' ? (
            <>
              {selectedPlacement && selectedSku ? (
                <div className="flex flex-col gap-3">
                  <div className="flex items-start gap-2.5">
                    <span
                      className="w-3.5 h-3.5 rounded-sm mt-0.5 shrink-0 border border-slate-300"
                      style={{ backgroundColor: selectedSku.color }}
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-mono font-semibold text-slate-900 truncate">
                        {selectedSku.factorySku}
                      </p>
                      <p className="text-[11px] text-slate-500 truncate">
                        Mã khách: {selectedSku.customerSku} · L
                        {selectedPlacement.layerIndex + 1}
                      </p>
                      <p className="text-xs text-slate-700 mt-0.5">
                        {selectedSku.description}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 border border-slate-200 rounded-md p-2.5 font-mono tabular-nums">
                    <div>
                      <span className="text-[10px] text-slate-500 block">
                        Đặt D×C×R
                      </span>
                      <span className="text-slate-900 font-medium">
                        {Math.round(selectedPlacement.dimXMm)}×
                        {Math.round(selectedPlacement.dimYMm)}×
                        {Math.round(selectedPlacement.dimZMm)}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">
                        Kg / luật xoay
                      </span>
                      <span className="text-slate-900 font-medium">
                        {selectedSku.weightKg}kg ·{' '}
                        {selectedSku.stackable ? 'Stack' : 'NoStack'}
                      </span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-[10px] text-slate-500 block">
                        Toạ độ (X từ vách trong · Y từ sàn · Z từ vách trái)
                      </span>
                      <span className="text-slate-900 font-medium">
                        X:{Math.round(selectedPlacement.xMm)} · Y:
                        {Math.round(selectedPlacement.yMm)} · Z:
                        {Math.round(selectedPlacement.zMm)} mm
                      </span>
                    </div>
                  </div>

                  {/* Manual Nudge Controls */}
                  <div className="flex flex-col gap-2">
                    <span className="text-xs font-medium text-slate-700">
                      Dời tay (±100 mm)
                    </span>
                    <div className="grid grid-cols-3 gap-1.5 text-xs font-mono">
                      <button
                        onClick={() =>
                          handleMoveCarton(
                            selectedPlacement.instanceId,
                            selectedPlacement.xMm - 100,
                            selectedPlacement.yMm,
                            selectedPlacement.zMm
                          )
                        }
                        className="py-1.5 border border-slate-200 rounded hover:bg-slate-50"
                      >
                        -X vào trong
                      </button>
                      <button
                        onClick={() =>
                          handleMoveCarton(
                            selectedPlacement.instanceId,
                            selectedPlacement.xMm + 100,
                            selectedPlacement.yMm,
                            selectedPlacement.zMm
                          )
                        }
                        className="py-1.5 border border-slate-200 rounded hover:bg-slate-50"
                      >
                        +X ra cửa
                      </button>
                      <button
                        onClick={handleDropSelectedToSupport}
                        className="py-1.5 border border-slate-200 rounded hover:bg-slate-50 flex items-center justify-center gap-1"
                        title="Hạ xuống sàn hoặc thùng bên dưới"
                      >
                        <ArrowDownToLine className="w-3 h-3" />
                        <span>Hạ</span>
                      </button>
                      <button
                        onClick={() =>
                          handleMoveCarton(
                            selectedPlacement.instanceId,
                            selectedPlacement.xMm,
                            selectedPlacement.yMm,
                            selectedPlacement.zMm - 100
                          )
                        }
                        className="py-1.5 border border-slate-200 rounded hover:bg-slate-50"
                      >
                        -Z sang trái
                      </button>
                      <button
                        onClick={() =>
                          handleMoveCarton(
                            selectedPlacement.instanceId,
                            selectedPlacement.xMm,
                            selectedPlacement.yMm,
                            selectedPlacement.zMm + 100
                          )
                        }
                        className="py-1.5 border border-slate-200 rounded hover:bg-slate-50"
                      >
                        +Z sang phải
                      </button>
                      <button
                        onClick={() =>
                          handleMoveCarton(
                            selectedPlacement.instanceId,
                            selectedPlacement.xMm,
                            selectedPlacement.yMm + 100,
                            selectedPlacement.zMm
                          )
                        }
                        className="py-1.5 border border-slate-200 rounded hover:bg-slate-50"
                      >
                        +Y lên
                      </button>
                    </div>
                  </div>

                  {/* Snap to Anchor & Rotate */}
                  <div className="grid grid-cols-3 gap-1.5 text-xs">
                    <button
                      onClick={() =>
                        handleMoveCarton(
                          selectedPlacement.instanceId,
                          selectedPlacement.xMm,
                          selectedPlacement.yMm,
                          0
                        )
                      }
                      className="py-1.5 border border-slate-200 rounded hover:bg-slate-50 flex items-center justify-center gap-1"
                    >
                      <Anchor className="w-3 h-3" />
                      <span>Trái</span>
                    </button>
                    <button
                      onClick={() =>
                        handleMoveCarton(
                          selectedPlacement.instanceId,
                          selectedPlacement.xMm,
                          selectedPlacement.yMm,
                          (activeSpec.internalWidthMm -
                            selectedPlacement.dimZMm) /
                            2
                        )
                      }
                      className="py-1.5 border border-slate-200 rounded hover:bg-slate-50"
                    >
                      Giữa
                    </button>
                    <button
                      onClick={() =>
                        handleMoveCarton(
                          selectedPlacement.instanceId,
                          selectedPlacement.xMm,
                          selectedPlacement.yMm,
                          activeSpec.internalWidthMm - selectedPlacement.dimZMm
                        )
                      }
                      className="py-1.5 border border-slate-200 rounded hover:bg-slate-50"
                    >
                      Phải
                    </button>
                  </div>

                  <div className="flex items-center gap-2 pt-1 border-t border-slate-200">
                    <button
                      onClick={handleRotateSelected}
                      className="flex-1 py-2 px-3 rounded-md bg-slate-900 text-white text-xs font-medium hover:bg-slate-800 flex items-center justify-center gap-1.5"
                    >
                      <RotateCw className="w-3.5 h-3.5" />
                      <span>Xoay</span>
                    </button>
                    <button
                      onClick={handleDeleteSelected}
                      className="py-2 px-3 rounded-md border border-red-200 text-red-700 hover:bg-red-50 text-xs font-medium flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Gỡ ra</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-xs text-slate-600 space-y-2 py-1">
                  <p>
                    Bấm giữ và kéo thùng trong cont 3D để dời, hoặc kéo mã hàng từ danh sách chờ bên dưới thả vào cont.
                  </p>
                  <p className="text-slate-500">
                    Chuyển sang <strong>SL / Thêm mã</strong> ở trên để sửa số lượng hoặc thêm mã mới ngay trên màn 3D.
                  </p>
                </div>
              )}

              {/* Unloaded / Remaining Quick Insert & Drag-to-3D Pool */}
              <div className="border-t border-slate-200 pt-3 mt-auto">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-slate-900">
                    Hàng chờ xếp (kéo vào 3D)
                  </span>
                  <span className="text-xs font-mono tabular-nums text-slate-600">
                    {reconciliation.totalRemaining} thùng chờ
                  </span>
                </div>
                {reconciliation.totalRemaining > 0 && searchBox('mb-2')}
                {reconciliation.totalRemaining === 0 ? (
                  <div className="text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-md px-2.5 py-2 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                    <span>Đã xếp đủ mọi mã (còn 0).</span>
                  </div>
                ) : (
                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                    {reconciliation.rows
                      .filter((r) => r.remainingQty > 0 && matchSku(r.skuId))
                      .map((r) => {
                        const sku = skuMap.get(r.skuId)!;
                        return (
                          <div
                            key={r.skuId}
                            draggable
                            onDragStart={(e) => {
                              const payload = { kind: 'pool', skuId: sku.id } as const;
                              e.dataTransfer.setData('text/plain', JSON.stringify(payload));
                              e.dataTransfer.effectAllowed = 'copy';
                              setDragPayload(payload);
                              setDraggingSkuId(sku.id);
                            }}
                            onDragEnd={() => {
                              setDragPayload(null);
                              setDraggingSkuId(null);
                              setIsDragOverCanvas(false);
                            }}
                            className="flex items-center justify-between gap-2 text-xs border border-slate-200 rounded px-2 py-1.5 bg-slate-50 cursor-grab active:cursor-grabbing hover:border-blue-400"
                            title="Kéo thả vào cont 3D, hoặc bấm + Xếp 1"
                          >
                            <div className="min-w-0 flex items-center gap-1.5">
                              <GripVertical className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              <span
                                className="w-2.5 h-2.5 rounded-xs shrink-0"
                                style={{ backgroundColor: r.color }}
                              />
                              <div className="truncate">
                                <span className="font-mono font-medium text-slate-900">
                                  {r.factorySku}
                                </span>
                                <span className="text-slate-500 ml-1.5 font-mono tabular-nums">
                                  ×{r.remainingQty}
                                </span>
                              </div>
                            </div>
                            <button
                              onClick={() => handleInsertRemainingUnit(sku)}
                              className="px-2 py-0.5 bg-blue-700 text-white rounded text-[11px] font-medium hover:bg-blue-800 shrink-0"
                            >
                              + Xếp 1
                            </button>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            </>
          ) : (
            /* Direct 3D Qty Adjustment & Add New SKU Card */
            <div className="flex flex-col gap-2.5 flex-1 min-h-0">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-900">
                  +SL / Thêm mã ({project.skus.length})
                </span>
                <button
                  onClick={() => setShowQuickAddForm((v) => !v)}
                  className="px-2.5 py-1 text-[11px] font-medium bg-blue-700 text-white rounded hover:bg-blue-800 flex items-center gap-1 whitespace-nowrap shrink-0"
                >
                  <Plus className="w-3 h-3" />
                  <span>{showQuickAddForm ? 'Đóng' : 'Thêm mã'}</span>
                </button>
              </div>
              {searchBox()}

              <label className="flex items-center justify-between gap-2 text-[11px] text-slate-700 bg-blue-50/70 border border-blue-200 rounded px-2.5 py-1.5 cursor-pointer">
                <span>Tự +1 số lượng khi thả vào 3D</span>
                <input
                  type="checkbox"
                  checked={autoIncrementOnDrop}
                  onChange={(e) => setAutoIncrementOnDrop(e.target.checked)}
                />
              </label>

              {showQuickAddForm && (
                <form
                  onSubmit={handleQuickAddSku}
                  className="bg-slate-50 border border-slate-200 rounded-md p-2.5 space-y-2 text-xs"
                >
                  <div className="grid grid-cols-2 gap-1.5">
                    <input
                      type="text"
                      placeholder="Mã nhà máy *"
                      value={quickSkuForm.factorySku}
                      onChange={(e) =>
                        setQuickSkuForm({
                          ...quickSkuForm,
                          factorySku: e.target.value,
                        })
                      }
                      className="border border-slate-300 rounded px-2 py-1 font-mono bg-white"
                      required
                    />
                    <input
                      type="text"
                      placeholder="Mã khách"
                      value={quickSkuForm.customerSku}
                      onChange={(e) =>
                        setQuickSkuForm({
                          ...quickSkuForm,
                          customerSku: e.target.value,
                        })
                      }
                      className="border border-slate-300 rounded px-2 py-1 font-mono bg-white"
                    />
                  </div>
                  <input
                    type="text"
                    placeholder="Mô tả"
                    value={quickSkuForm.description}
                    onChange={(e) =>
                      setQuickSkuForm({
                        ...quickSkuForm,
                        description: e.target.value,
                      })
                    }
                    className="w-full border border-slate-300 rounded px-2 py-1 bg-white"
                  />
                  <div className="grid grid-cols-3 gap-1.5 font-mono">
                    <div>
                      <span className="text-[10px] text-slate-500">Dài (mm)</span>
                      <input
                        type="number"
                        min={50}
                        value={quickSkuForm.lengthMm}
                        onChange={(e) =>
                          setQuickSkuForm({
                            ...quickSkuForm,
                            lengthMm: Number(e.target.value),
                          })
                        }
                        className="w-full border border-slate-300 rounded px-1.5 py-1 bg-white"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500">Rộng (mm)</span>
                      <input
                        type="number"
                        min={50}
                        value={quickSkuForm.widthMm}
                        onChange={(e) =>
                          setQuickSkuForm({
                            ...quickSkuForm,
                            widthMm: Number(e.target.value),
                          })
                        }
                        className="w-full border border-slate-300 rounded px-1.5 py-1 bg-white"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500">Cao (mm)</span>
                      <input
                        type="number"
                        min={50}
                        value={quickSkuForm.heightMm}
                        onChange={(e) =>
                          setQuickSkuForm({
                            ...quickSkuForm,
                            heightMm: Number(e.target.value),
                          })
                        }
                        className="w-full border border-slate-300 rounded px-1.5 py-1 bg-white"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5 font-mono">
                    <div>
                      <span className="text-[10px] text-slate-500">
                        Kg
                      </span>
                      <input
                        type="number"
                        min={0.5}
                        step={0.5}
                        value={quickSkuForm.weightKg}
                        onChange={(e) =>
                          setQuickSkuForm({
                            ...quickSkuForm,
                            weightKg: Number(e.target.value),
                          })
                        }
                        className="w-full border border-slate-300 rounded px-1.5 py-1 bg-white"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500">SL</span>
                      <input
                        type="number"
                        min={1}
                        value={quickSkuForm.requiredQty}
                        onChange={(e) =>
                          setQuickSkuForm({
                            ...quickSkuForm,
                            requiredQty: Number(e.target.value),
                          })
                        }
                        className="w-full border border-slate-300 rounded px-1.5 py-1 bg-white"
                      />
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-2 pt-1">
                    <label className="flex items-center gap-1.5 text-[11px] text-slate-700">
                      <input
                        type="checkbox"
                        checked={quickSkuForm.stackable}
                        onChange={(e) =>
                          setQuickSkuForm({
                            ...quickSkuForm,
                            stackable: e.target.checked,
                          })
                        }
                      />
                      <span>Chồng được</span>
                    </label>
                    <button
                      type="submit"
                      className="px-3 py-1 bg-slate-900 text-white rounded text-[11px] font-medium hover:bg-slate-800"
                    >
                      Lưu / +SL
                    </button>
                  </div>

                  {/* Direct Drag-and-Drop handle from Add SKU form onto 3D */}
                  <div
                    draggable
                    onDragStart={(e) => {
                      const payload = { kind: 'new_sku_form' } as const;
                      e.dataTransfer.setData('text/plain', JSON.stringify(payload));
                      e.dataTransfer.effectAllowed = 'copy';
                      setDragPayload(payload);
                    }}
                    onDragEnd={() => {
                      setDragPayload(null);
                      setIsDragOverCanvas(false);
                    }}
                    className="flex items-center justify-between gap-2 px-2.5 py-2 rounded border border-dashed border-blue-500 bg-blue-50 text-blue-900 cursor-grab active:cursor-grabbing hover:bg-blue-100 transition-colors"
                    title="Kéo khối này thả vào cont 3D để tạo/tăng mã và đặt thùng"
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      <GripVertical className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                      <span className="font-mono font-semibold truncate">
                        {quickSkuForm.factorySku.trim() ||
                          `SKU-${project.skus.length + 1}`}
                      </span>
                    </div>
                    <span className="text-[10px] font-medium whitespace-nowrap shrink-0">
                      Kéo vào 3D (+1)
                    </span>
                  </div>
                </form>
              )}

              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {reconciliation.rows.filter((r) => matchSku(r.skuId)).map((r) => {
                  const sku = skuMap.get(r.skuId);
                  if (!sku) return null;
                  return (
                    <div
                      key={r.skuId}
                      draggable
                      onDragStart={(e) => {
                        const payload = {
                          kind: 'quick_add',
                          skuId: sku.id,
                        } as const;
                        e.dataTransfer.setData(
                          'text/plain',
                          JSON.stringify(payload)
                        );
                        e.dataTransfer.effectAllowed = 'copy';
                        setDragPayload(payload);
                        setDraggingSkuId(sku.id);
                      }}
                      onDragEnd={() => {
                        setDragPayload(null);
                        setDraggingSkuId(null);
                        setIsDragOverCanvas(false);
                      }}
                      className="border border-slate-200 rounded-md p-2 text-xs bg-slate-50/70 space-y-1.5 cursor-grab active:cursor-grabbing hover:border-blue-400 transition-colors"
                      title="Kéo vào cont 3D để đặt & tự +1"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <GripVertical className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span
                            className="w-2.5 h-2.5 rounded-xs shrink-0"
                            style={{ backgroundColor: r.color }}
                          />
                          <span className="font-mono font-semibold text-slate-900 truncate">
                            {r.factorySku}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <span className="text-[10px] font-medium text-blue-700">
                            Kéo +1
                          </span>
                          <span
                            className={`font-mono tabular-nums text-[11px] ${
                              r.remainingQty === 0
                                ? 'text-emerald-700'
                                : r.remainingQty < 0
                                  ? 'text-red-700'
                                  : 'text-amber-700'
                            }`}
                          >
                            Còn: {r.remainingQty}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[11px] text-slate-500 font-mono tabular-nums">
                          Đã xếp: {r.totalLoadedQty}
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() =>
                              handleQuickAdjustSkuQty(
                                sku.id,
                                Math.max(0, sku.requiredQty - 1)
                              )
                            }
                            className="w-6 h-6 border border-slate-300 rounded bg-white hover:bg-slate-100 font-mono font-semibold"
                          >
                            -
                          </button>
                          <input
                            type="number"
                            min={0}
                            aria-label={`Số yêu cầu của ${sku.factorySku}`}
                            value={sku.requiredQty}
                            onChange={(e) =>
                              handleQuickAdjustSkuQty(
                                sku.id,
                                Number(e.target.value)
                              )
                            }
                            className="w-12 h-6 text-center font-mono tabular-nums border border-slate-300 rounded bg-white"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              handleQuickAdjustSkuQty(
                                sku.id,
                                sku.requiredQty + 1
                              )
                            }
                            className="w-6 h-6 border border-slate-300 rounded bg-white hover:bg-slate-100 font-mono font-semibold"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <button
                onClick={handleIncrementalRecalcPreview}
                className="mt-auto w-full py-2 px-3 bg-slate-900 text-white rounded-md text-xs font-medium hover:bg-slate-800 flex items-center justify-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Tính lại theo số mới</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Data Panel: Loading Legend, Quantity Reconciliation, Validation & Layers */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-slate-50/60">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-md">
            {(
              [
                ['legend', 'Chú giải hàng'],
                ['reconciliation', 'Đối soát số lượng'],
                [
                  'validation',
                  `Kiểm tra ràng buộc (${allIssues.length})`,
                ],
                ['layers', `Theo lớp (${layerGroups.length})`],
              ] as const
            ).map(([tabKey, label]) => (
              <button
                key={tabKey}
                onClick={() => setBottomTab(tabKey)}
                className={`px-3 py-1 text-xs font-medium rounded whitespace-nowrap shrink-0 transition-colors ${
                  bottomTab === tabKey
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {(bottomTab === 'legend' || bottomTab === 'reconciliation') && searchBox('w-64')}
          <div className="flex items-center gap-3 text-xs font-mono tabular-nums">
            <span className="text-slate-600">
              Yêu cầu: <strong className="text-slate-900">{reconciliation.totalRequired}</strong>
            </span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-600">
              Đã xếp: <strong className="text-slate-900">{reconciliation.totalLoaded}</strong>
            </span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-600">
              Còn: <strong className="text-slate-900">{reconciliation.totalRemaining}</strong>
            </span>
            <span aria-hidden="true">·</span>
            <span
              className={`font-sans font-medium flex items-center gap-1 ${
                reconciliation.hasDiscrepancies
                  ? 'text-red-700'
                  : 'text-emerald-700'
              }`}
            >
              {reconciliation.hasDiscrepancies ? (
                <ShieldAlert className="w-3.5 h-3.5" />
              ) : (
                <ShieldCheck className="w-3.5 h-3.5" />
              )}
              {reconciliation.hasDiscrepancies
                ? 'Có sai lệch'
                : 'Khớp (Yêu cầu = Đã xếp + Còn lại)'}
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          {bottomTab === 'legend' && (
            <EditableGrid<CargoSku>
              columns={[
                ...skuColumns<CargoSku>((s) => s as unknown as Partial<Record<SkuField, CellValue>>),
                {
                  key: '_active',
                  header: 'Trong cont đang xem',
                  kind: 'int',
                  align: 'right',
                  readOnly: true,
                  get: (s) => (activeContainer ? reconMap.get(s.id)?.perContainerQty[activeContainer.id] ?? 0 : 0),
                  render: (s) => (
                    <span className="font-mono tabular-nums text-blue-700 font-medium">
                      {activeContainer ? reconMap.get(s.id)?.perContainerQty[activeContainer.id] ?? 0 : 0}
                    </span>
                  ),
                },
                {
                  key: '_loaded',
                  header: 'Tổng đã xếp',
                  kind: 'int',
                  align: 'right',
                  readOnly: true,
                  mono: true,
                  get: (s) => reconMap.get(s.id)?.totalLoadedQty ?? 0,
                },
                {
                  key: '_remaining',
                  header: 'Còn lại',
                  kind: 'int',
                  align: 'right',
                  readOnly: true,
                  get: (s) => reconMap.get(s.id)?.remainingQty ?? 0,
                  render: (s) => {
                    const rem = reconMap.get(s.id)?.remainingQty ?? 0;
                    return (
                      <span
                        className={`font-mono tabular-nums font-semibold ${
                          rem === 0 ? 'text-emerald-700' : rem < 0 ? 'text-red-700' : 'text-amber-700'
                        }`}
                      >
                        {rem}
                      </span>
                    );
                  },
                },
              ]}
              rows={project.skus.filter((s) => matchSku(s.id))}
              rowKey={(s) => s.id}
              compact
              onRowHover={(s) => setHoveredSkuId(s ? s.id : null)}
              leading={(s) => (
                <span className="inline-block w-3 h-3 rounded-xs border border-slate-300" style={{ backgroundColor: s.color }} />
              )}
              onCommit={(changes, rejects) => {
                let skus = [...project.skus];
                const shown = project.skus.filter((s) => matchSku(s.id));
                const notes: string[] = [];
                for (const ch of changes) {
                  const target = shown[ch.rowIndex];
                  const idx = target ? skus.findIndex((x) => x.id === target.id) : -1;
                  const cur = idx >= 0 ? skus[idx] : undefined;
                  if (!cur) continue;
                  if (ch.key === 'factorySku') {
                    const v = String(ch.value ?? '').trim();
                    if (!v || skus.some((x) => x.id !== cur.id && x.factorySku === v)) {
                      onNotify?.(`⚠ Mã nhà máy "${v}" trống hoặc đã có — không đổi.`, 6000);
                      continue;
                    }
                  }
                  skus[idx] = applySkuValue(cur, ch.key, ch.value);
                  notes.push(`${cur.factorySku}.${ch.key}=${String(ch.value)}`);
                }
                if (rejects.length) {
                  onNotify?.(
                    `⚠ Bỏ qua ${rejects.length} ô: ` +
                      rejects.slice(0, 3).map((r) => `${shown[r.rowIndex]?.factorySku ?? ''} ${r.header} ${r.reason}`).join('; '),
                    8000
                  );
                }
                if (notes.length) {
                  onUpdateProject(
                    { ...project, skus, updatedAt: new Date().toISOString() },
                    `Sửa bảng chú giải hàng: ${notes.slice(0, 5).join(', ')}${notes.length > 5 ? '…' : ''}`
                  );
                }
              }}
            />
          )}

          {bottomTab === 'reconciliation' && (
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                <tr>
                  <th className="py-2.5 px-4 font-medium">Mã nhà máy</th>
                  <th className="py-2.5 px-3 font-medium">Mã khách</th>
                  <th className="py-2.5 px-3 font-medium text-right">
                    Yêu cầu
                  </th>
                  {project.containers.map((c) => (
                    <th
                      key={c.id}
                      className="py-2.5 px-3 font-medium text-right"
                    >
                      C#{c.sequenceNumber}
                    </th>
                  ))}
                  <th className="py-2.5 px-3 font-medium text-right">
                    Đã xếp
                  </th>
                  <th className="py-2.5 px-3 font-medium text-right">
                    Còn lại
                  </th>
                  <th className="py-2.5 px-4 font-medium text-right">
                    Kiểm tra
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {reconciliation.rows.filter((r) => matchSku(r.skuId)).map((r) => (
                  <tr key={r.skuId} className="hover:bg-slate-50">
                    <td className="py-2 px-4 font-mono font-medium text-slate-900">
                      {r.factorySku}
                    </td>
                    <td className="py-2 px-3 font-mono text-slate-600">
                      {r.customerSku}
                    </td>
                    <td className="py-1 px-3 text-right">
                      <input
                        type="text"
                        inputMode="numeric"
                        defaultValue={r.requiredQty}
                        key={`${r.skuId}-${r.requiredQty}`}
                        title="Sửa số lượng yêu cầu (Enter để lưu)"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') (e.target as HTMLInputElement).blur();
                        }}
                        onBlur={(e) => {
                          const n = parseNumberLoose(e.target.value);
                          if (n === null || n < 0 || !Number.isInteger(n)) {
                            e.target.value = String(r.requiredQty);
                            onNotify?.('⚠ Số lượng phải là số nguyên ≥ 0', 5000);
                            return;
                          }
                          if (n === r.requiredQty) return;
                          onUpdateProject(
                            {
                              ...project,
                              skus: project.skus.map((s) => (s.id === r.skuId ? { ...s, requiredQty: n } : s)),
                              updatedAt: new Date().toISOString(),
                            },
                            `Sửa số yêu cầu ${r.factorySku}: ${r.requiredQty} → ${n}`
                          );
                        }}
                        className="w-16 text-right font-mono tabular-nums font-semibold border border-slate-200 rounded px-1.5 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </td>
                    {project.containers.map((c) => (
                      <td
                        key={c.id}
                        className="py-2 px-3 font-mono tabular-nums text-right text-slate-700"
                      >
                        {r.perContainerQty[c.id] ?? 0}
                      </td>
                    ))}
                    <td className="py-2 px-3 font-mono tabular-nums text-right font-medium text-blue-700">
                      {r.totalLoadedQty}
                    </td>
                    <td className="py-2 px-3 font-mono tabular-nums text-right font-medium">
                      {r.remainingQty}
                    </td>
                    <td
                      className={`py-2 px-4 text-right font-medium ${
                        r.reconciled ? 'text-emerald-700' : 'text-red-700'
                      }`}
                    >
                      {r.reconciled ? 'ĐẠT (khớp)' : 'ERROR'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {bottomTab === 'validation' && (
            <div className="p-4 space-y-3">
              <div
                className={`text-xs rounded-md border p-3 space-y-1.5 ${
                  !serverValidation
                    ? 'bg-slate-50 border-slate-200 text-slate-600'
                    : serverValidation.errors > 0
                      ? 'bg-red-50 border-red-200 text-red-900'
                      : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                }`}
              >
                <p className="font-semibold">
                  Kiểm tra độc lập (Python, không dùng chung code với engine):{' '}
                  {!serverValidation
                    ? 'đang chờ kết quả…'
                    : `${serverValidation.errors} lỗi · ${serverValidation.warnings} cảnh báo`}
                </p>
                {serverValidation?.checked && (
                  <p className="text-[11px] opacity-80">
                    Đã kiểm: {serverValidation.checked.join(', ')}
                    {serverValidation.skipped && serverValidation.skipped.length > 0 && (
                      <>
                        {' '}· Chưa kiểm:{' '}
                        {serverValidation.skipped
                          .map((x) => `${x.code} (${x.reason})`)
                          .join('; ')}
                      </>
                    )}
                  </p>
                )}
                {serverValidation?.issues.slice(0, 30).map((iss) => (
                  <div key={iss.id} className="flex items-center justify-between gap-3">
                    <span>
                      <span className="font-mono font-semibold mr-1">[{iss.code ?? iss.rule}]</span>
                      <span className="font-mono mr-1">{iss.containerLabel}:</span>
                      {iss.message}
                    </span>
                    {iss.cartonIds[0] && (
                      <button
                        onClick={() => {
                          const idx = project.containers.findIndex(
                            (c) => c.id === iss.containerId
                          );
                          if (idx >= 0) setActiveContainerIdx(idx);
                          setSelectedCartonId(iss.cartonIds[0]);
                        }}
                        className="px-2 py-0.5 bg-white border border-slate-300 rounded text-slate-800 font-medium shrink-0"
                      >
                        Chọn thùng
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <p className="text-[11px] text-slate-500">
                Kiểm tra nhanh trong trình duyệt (cập nhật tức thì khi kéo thả):
              </p>
              {allIssues.length === 0 ? (
                <div className="flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-md p-3">
                  <ShieldCheck className="w-4 h-4 shrink-0" />
                  <span>
                    Kiểm tra nhanh trên trình duyệt: không lỗi ở mọi cont (lòng cont, chồng lấn, xoay, chồng hàng, tải trọng, trọng tâm, độ đỡ đáy, lối tiếp cận).
                  </span>
                </div>
              ) : (
                <div className="space-y-2">
                  {allIssues.map((iss) => (
                    <div
                      key={iss.id}
                      className={`flex items-center justify-between gap-4 text-xs px-3 py-2 rounded border ${
                        iss.severity === 'error'
                          ? 'bg-red-50 border-red-200 text-red-900'
                          : 'bg-amber-50 border-amber-200 text-amber-900'
                      }`}
                    >
                      <div>
                        <span className="font-semibold uppercase mr-2">
                          [{iss.severity} · {iss.rule}]
                        </span>
                        <span className="font-mono mr-2">
                          {iss.containerLabel}:
                        </span>
                        <span>{iss.message}</span>
                      </div>
                      {iss.cartonIds[0] && (
                        <button
                          onClick={() => {
                            const idx = project.containers.findIndex(
                              (c) => c.id === iss.containerId
                            );
                            if (idx >= 0) setActiveContainerIdx(idx);
                            setSelectedCartonId(iss.cartonIds[0]);
                          }}
                          className="px-2 py-1 bg-white border border-slate-300 rounded text-slate-800 font-medium shrink-0"
                        >
                          Chọn thùng
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {bottomTab === 'layers' && (
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                <tr>
                  <th className="py-2.5 px-4 font-medium">Lớp xếp</th>
                  <th className="py-2.5 px-3 font-medium text-right">
                    Số thùng trong lớp
                  </th>
                  <th className="py-2.5 px-3 font-medium text-right">
                    Kg của lớp
                  </th>
                  <th className="py-2.5 px-4 font-medium">Các mã trong lớp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {layerGroups.map((g) => (
                  <tr key={g.layer} className="hover:bg-slate-50">
                    <td className="py-2 px-4 font-mono font-semibold text-slate-900">
                      Lớp {g.layer + 1}
                    </td>
                    <td className="py-2 px-3 font-mono tabular-nums text-right">
                      {g.count}
                    </td>
                    <td className="py-2 px-3 font-mono tabular-nums text-right">
                      {g.weightKg.toFixed(1)}
                    </td>
                    <td className="py-2 px-4 font-mono text-slate-700">
                      {Array.from(g.skus).join(', ')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {serverBusy && (
        <div className="fixed inset-0 z-50 bg-slate-900/30 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-lg px-5 py-4 shadow-xl flex items-center gap-3 text-sm text-slate-800">
            <RefreshCw className="w-4 h-4 animate-spin text-blue-700" />
            <span>{serverBusy}</span>
          </div>
        </div>
      )}

      {/* Incremental Recalculation Diff Review Modal */}
      {recalcPreview && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-lg max-w-xl w-full p-5 shadow-xl space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-base font-semibold text-slate-900">
                  {previewKind === 'full'
                    ? 'Duyệt phương án xếp toàn bộ (chưa ghi đè)'
                    : 'Duyệt kết quả tính lại một phần'}
                </h3>
                <p className="text-xs text-slate-600 mt-1">
                  {recalcPreview.summary}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 text-xs bg-slate-50 border border-slate-200 rounded-md p-3 font-mono tabular-nums">
              <div>
                <span className="text-slate-500 block font-sans">
                  Cont giữ nguyên
                </span>
                <span className="text-sm font-semibold text-emerald-700">
                  {recalcPreview.preservedContainerIds.length}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block font-sans">
                  Cont bị thay đổi
                </span>
                <span className="text-sm font-semibold text-amber-700">
                  {recalcPreview.affectedContainerIds.length}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block font-sans">
                  Độ đầy đề xuất
                </span>
                <span className="text-sm font-semibold text-slate-900">
                  {recalcPreview.proposedMetrics.volumeUtilizationPct.toFixed(1)}
                  %
                </span>
              </div>
            </div>

            <div className="text-xs bg-slate-50 border border-slate-200 rounded-md p-3 space-y-1">
              <p>
                <span className="font-semibold">
                  {recalcPreview.proposedMetrics.containersUsed} cont
                </span>{' '}
                · cận dưới {recalcPreview.proposedMetrics.lowerBoundContainers} · khoảng cách tối ưu{' '}
                {recalcPreview.proposedMetrics.optimalityGapPct.toFixed(1)}% ·{' '}
                <span className="font-semibold">
                  {statusVi(recalcPreview.proposedMetrics.statusLabel)}
                </span>{' '}
                · {(recalcPreview.proposedMetrics.computeTimeMs / 1000).toFixed(1)} giây
              </p>
              <p className="text-slate-600">
                {recalcPreview.proposedMetrics.explanation}
              </p>
            </div>

            {recalcPreview.validation && (
              <div
                className={`text-xs rounded-md border p-3 space-y-1 ${
                  recalcPreview.validation.errors > 0
                    ? 'bg-red-50 border-red-200 text-red-900'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                }`}
              >
                <p className="font-semibold">
                  Kiểm tra độc lập: {recalcPreview.validation.errors} lỗi ·{' '}
                  {recalcPreview.validation.warnings} cảnh báo
                </p>
                {recalcPreview.validation.issues.slice(0, 5).map((i) => (
                  <p key={i.id} className="font-mono">
                    · [{i.code ?? i.rule}] {i.containerLabel}: {i.message}
                  </p>
                ))}
              </div>
            )}

            {recalcPreview.invalidatedCartons.length > 0 && (
              <div className="max-h-40 overflow-y-auto border border-amber-200 bg-amber-50 rounded-md p-3 space-y-1.5 text-xs text-amber-900">
                <p className="font-semibold">
                  Thùng không còn hợp lệ:
                </p>
                {recalcPreview.invalidatedCartons.slice(0, 8).map((inv, i) => (
                  <p key={i} className="font-mono">
                    · {inv.containerLabel} / {inv.factorySku}: {inv.reason}
                  </p>
                ))}
                {recalcPreview.invalidatedCartons.length > 8 && (
                  <p>
                    …và {recalcPreview.invalidatedCartons.length - 8} thùng khác.
                  </p>
                )}
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                onClick={() => setRecalcPreview(null)}
                className="px-4 py-2 text-xs font-medium border border-slate-300 rounded-md text-slate-700 hover:bg-slate-50"
              >
                Huỷ (giữ nguyên)
              </button>
              <button
                onClick={handleApplyRecalcPreview}
                className="px-4 py-2 text-xs font-medium bg-blue-700 text-white rounded-md hover:bg-blue-800"
              >
                Duyệt & áp dụng
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
