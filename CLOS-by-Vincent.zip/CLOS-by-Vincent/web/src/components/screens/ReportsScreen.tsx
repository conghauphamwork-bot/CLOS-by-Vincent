import React, { useState } from 'react';
import {
  FileSpreadsheet,
  FileText,
  ListOrdered,
  Printer,
  ShieldCheck,
} from 'lucide-react';
import {
  exportProjectToExcel,
  exportStepByStepExcel,
} from '../../engine/excelService';
import {
  exportProjectToPdf,
  exportStepByStepPdf,
} from '../../engine/pdfService';
import {
  computeContainerStats,
  reconcileProjectQuantities,
} from '../../engine/reconciliation';
import { ContainerSpec, LoadingProject } from '../../types/clos';

interface ReportsScreenProps {
  project: LoadingProject;
  specs: ContainerSpec[];
  onGet3DSnapshot: () => string | null;
  onMarkExported: (note: string) => void;
}

export const ReportsScreen: React.FC<ReportsScreenProps> = ({
  project,
  specs,
  onGet3DSnapshot,
  onMarkExported,
}) => {
  const [selectedContainerId, setSelectedContainerId] = useState<string>('ALL');
  const specsById = new Map(specs.map((s) => [s.id, s]));
  const skuMap = new Map(project.skus.map((s) => [s.id, s]));
  const recon = reconcileProjectQuantities(project.skus, project.containers);

  const filterId =
    selectedContainerId === 'ALL' ? undefined : selectedContainerId;

  const handleExportExcel = () => {
    exportProjectToExcel(project, specsById, filterId);
    onMarkExported(
      `Đã xuất Excel kế hoạch xếp (${filterId ? '1 cont' : 'tất cả cont'})`
    );
  };

  const handleExportStepByStep = () => {
    exportStepByStepExcel(project, specsById, filterId);
    onMarkExported(
      `Đã xuất Excel hướng dẫn xếp từng bước (${filterId ? '1 cont' : 'tất cả cont'})`
    );
  };

  const handleExportPdf = () => {
    const snap = onGet3DSnapshot();
    exportProjectToPdf(project, specsById, {
      containerFilterId: filterId,
      snapshotDataUrl: snap,
    });
    onMarkExported(
      `Đã xuất PDF kế hoạch xếp (${filterId ? '1 cont' : 'tất cả cont'})`
    );
  };

  const handleExportStepByStepPdf = () => {
    exportStepByStepPdf(project, specsById, {
      containerFilterId: filterId,
    });
    onMarkExported(
      `Đã xuất PDF xếp từng bước 3D & kiểm tra (${filterId ? '1 cont' : 'tất cả cont'})`
    );
  };

  const visibleContainers = filterId
    ? project.containers.filter((c) => c.id === filterId)
    : project.containers;

  return (
    <div className="space-y-4">
      {/* Export Control Bar */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4 no-print">
        <div>
          <h1 className="text-lg font-bold text-slate-900">
            Báo cáo & xuất file
          </h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Xuất Excel, PDF kế hoạch xếp theo lớp, và báo cáo đối soát số lượng từng mã.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            aria-label="Phạm vi xuất"
            value={selectedContainerId}
            onChange={(e) => setSelectedContainerId(e.target.value)}
            className="text-xs border border-slate-300 rounded-md px-3 py-2 bg-white font-medium"
          >
            <option value="ALL">
              Tất cả cont ({project.containers.length})
            </option>
            {project.containers.map((c) => (
              <option key={c.id} value={c.id}>
                {c.label} Chỉ
              </option>
            ))}
          </select>

          <button
            onClick={handleExportExcel}
            className="px-3.5 py-2 text-xs font-medium border border-slate-300 rounded-md bg-white text-slate-800 hover:bg-slate-50 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
            <span>Xuất Excel (.xlsx)</span>
          </button>


          <button
            onClick={handleExportPdf}
            className="px-3.5 py-2 text-xs font-medium border border-slate-300 bg-white text-slate-800 rounded-md hover:bg-slate-50 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <FileText className="w-4 h-4 text-blue-700" />
            <span>PDF tổng hợp</span>
          </button>

          <button
            onClick={handleExportStepByStepPdf}
            className="px-3.5 py-2 text-xs font-medium bg-blue-700 text-white rounded-md hover:bg-blue-800 flex items-center gap-1.5 whitespace-nowrap shrink-0"
            title="Xuất PDF chi tiết kế hoạch + xếp từng bước 3D & kiểm tra"
          >
            <FileText className="w-4 h-4" />
            <span>PDF từng bước 3D</span>
          </button>

          <button
            onClick={() => window.print()}
            className="px-3 py-2 text-xs font-medium border border-slate-300 rounded-md bg-white text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Printer className="w-4 h-4" />
            <span>In</span>
          </button>
        </div>
      </div>

      {/* Live Preview: Reconciliation Report */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
          <h2 className="text-sm font-semibold text-slate-900">
            Tổng hợp số lượng & còn lại theo mã ({project.code})
          </h2>
          {(() => {
            // Tính thật mỗi lần mở: mọi mã phải Yêu cầu = Đã xếp + Còn lại, không âm, không vượt
            const bad = recon.rows.filter((r) => !r.reconciled || r.remainingQty < 0 || r.status === 'overallocated');
            const notDone = recon.rows.filter((r) => r.remainingQty > 0);
            const tone = bad.length ? 'text-red-700' : notDone.length ? 'text-amber-700' : 'text-emerald-700';
            const label = bad.length
              ? `Lệch số lượng ở ${bad.length} mã — kiểm tra trước khi xuất`
              : notDone.length
                ? `Khớp công thức · còn ${notDone.reduce((a, r) => a + r.remainingQty, 0)} thùng chưa xếp (${notDone.length} mã)`
                : `Khớp: ${recon.totalRequired} thùng yêu cầu = đã xếp, còn 0`;
            return (
          <span className={`text-xs font-medium ${tone} flex items-center gap-1`}>
            <ShieldCheck className="w-4 h-4" />
            <span>{label}</span>
          </span>
            );
          })()}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
              <tr>
                <th className="py-2.5 px-4 font-medium">Mã nhà máy</th>
                <th className="py-2.5 px-3 font-medium">Mã khách</th>
                <th className="py-2.5 px-3 font-medium text-right">
                  Kích thước (mm)
                </th>
                <th className="py-2.5 px-3 font-medium text-right">Yêu cầu</th>
                {project.containers.map((c) => (
                  <th key={c.id} className="py-2.5 px-3 font-medium text-right">
                    C#{c.sequenceNumber}
                  </th>
                ))}
                <th className="py-2.5 px-3 font-medium text-right">
                  Đã xếp
                </th>
                <th className="py-2.5 px-4 font-medium text-right">
                  Còn lại
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
              {recon.rows.map((r) => (
                <tr key={r.skuId} className="hover:bg-slate-50">
                  <td className="py-2 px-4 font-semibold text-slate-900">
                    {r.factorySku}
                  </td>
                  <td className="py-2 px-3 text-slate-600">{r.customerSku}</td>
                  <td className="py-2 px-3 text-right text-slate-600">
                    {r.dimensionsLabel}
                  </td>
                  <td className="py-2 px-3 text-right font-semibold">
                    {r.requiredQty}
                  </td>
                  {project.containers.map((c) => (
                    <td key={c.id} className="py-2 px-3 text-right">
                      {r.perContainerQty[c.id] ?? 0}
                    </td>
                  ))}
                  <td className="py-2 px-3 text-right text-blue-700 font-semibold">
                    {r.totalLoadedQty}
                  </td>
                  <td
                    className={`py-2 px-4 text-right font-semibold ${
                      r.remainingQty === 0
                        ? 'text-emerald-700'
                        : 'text-amber-700'
                    }`}
                  >
                    {r.remainingQty}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Layer-by-Layer Container Loading Plan Preview */}
      {visibleContainers.map((c) => {
        const spec = specsById.get(c.containerSpecId) ?? specs[0];
        const stats = computeContainerStats(c, spec, skuMap);
        const sorted = [...c.placements].sort(
          (a, b) => a.layerIndex - b.layerIndex || a.xMm - b.xMm || a.zMm - b.zMm
        );

        return (
          <div
            key={c.id}
            className="bg-white border border-slate-200 rounded-lg overflow-hidden"
          >
            <div className="px-4 py-3 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 bg-slate-50/50">
              <h3 className="text-sm font-semibold text-slate-900">
                {c.label} — Danh sách xếp theo lớp
              </h3>
              <div className="text-xs font-mono tabular-nums text-slate-600 flex items-center gap-3">
                <span>{stats.totalCartons} thùng</span>
                <span>·</span>
                <span>{stats.layerCount} lớp</span>
                <span>·</span>
                <span>{stats.volumeUtilizationPct.toFixed(1)}% thể tích</span>
                <span>·</span>
                <span>{stats.totalCargoWeightKg.toFixed(1)} kg</span>
              </div>
            </div>

            <div className="overflow-x-auto max-h-80 overflow-y-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 sticky top-0">
                  <tr>
                    <th className="py-2 px-4 font-medium">TT</th>
                    <th className="py-2 px-3 font-medium">Lớp</th>
                    <th className="py-2 px-3 font-medium">Mã nhà máy</th>
                    <th className="py-2 px-3 font-medium">Mã khách</th>
                    <th className="py-2 px-3 font-medium text-right">
                      Vị trí X / Y / Z (mm)
                    </th>
                    <th className="py-2 px-3 font-medium text-right">
                      Đặt D×C×R (mm)
                    </th>
                    <th className="py-2 px-4 font-medium">Hướng</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
                  {sorted.map((p, i) => {
                    const sku = skuMap.get(p.skuId);
                    return (
                      <tr key={p.instanceId} className="hover:bg-slate-50">
                        <td className="py-1.5 px-4 text-slate-500">{i + 1}</td>
                        <td className="py-1.5 px-3 font-semibold text-slate-900">
                          L{p.layerIndex + 1}
                        </td>
                        <td className="py-1.5 px-3 text-slate-900">
                          {sku?.factorySku ?? p.skuId}
                        </td>
                        <td className="py-1.5 px-3 text-slate-600">
                          {sku?.customerSku ?? ''}
                        </td>
                        <td className="py-1.5 px-3 text-right">
                          {Math.round(p.xMm)}, {Math.round(p.yMm)},{' '}
                          {Math.round(p.zMm)}
                        </td>
                        <td className="py-1.5 px-3 text-right">
                          {Math.round(p.dimXMm)}×{Math.round(p.dimYMm)}×
                          {Math.round(p.dimZMm)}
                        </td>
                        <td className="py-1.5 px-4 font-sans text-slate-700">
                          {p.rotationLabel}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        );
      })}
    </div>
  );
};
