import React, { useState } from 'react';
import { Container, Plus, Trash2 } from 'lucide-react';
import { ContainerSpec, LoadingProject } from '../../types/clos';
import { computeContainerStats } from '../../engine/reconciliation';
import { CellChange, CellReject, EditableGrid, GridColumn } from '../common/EditableGrid';

interface ContainersScreenProps {
  specs: ContainerSpec[];
  activeProject: LoadingProject;
  onUpdateSpecs: (specs: ContainerSpec[]) => void;
  onSetProjectDefaultSpec: (specId: string) => void;
}

const SPEC_COLUMNS: GridColumn<ContainerSpec>[] = [
  { key: 'code', header: 'Mã cont', kind: 'text', width: 'w-28', mono: true, get: (s) => s.code },
  { key: 'name', header: 'Tên / mô tả', kind: 'text', width: 'w-56', get: (s) => s.name },
  { key: 'internalLengthMm', header: 'Dài lòng (mm)', kind: 'int', width: 'w-20', align: 'right', min: 1000, get: (s) => s.internalLengthMm },
  { key: 'internalWidthMm', header: 'Rộng lòng (mm)', kind: 'int', width: 'w-20', align: 'right', min: 1000, get: (s) => s.internalWidthMm },
  { key: 'internalHeightMm', header: 'Cao lòng (mm)', kind: 'int', width: 'w-20', align: 'right', min: 1000, get: (s) => s.internalHeightMm },
  { key: 'maxPayloadKg', header: 'Tải tối đa (kg)', kind: 'int', width: 'w-20', align: 'right', min: 0, get: (s) => s.maxPayloadKg },
  { key: 'tareWeightKg', header: 'Vỏ cont (kg)', kind: 'int', width: 'w-20', align: 'right', min: 0, get: (s) => s.tareWeightKg },
  { key: 'doorWidthMm', header: 'Rộng cửa (mm)', kind: 'int', width: 'w-20', align: 'right', min: 0, get: (s) => s.doorWidthMm },
  { key: 'doorHeightMm', header: 'Cao cửa (mm)', kind: 'int', width: 'w-20', align: 'right', min: 0, get: (s) => s.doorHeightMm },
  {
    key: '_vol',
    header: 'Thể tích (m³)',
    kind: 'num',
    align: 'right',
    readOnly: true,
    mono: true,
    get: (s) => ((s.internalLengthMm * s.internalWidthMm * s.internalHeightMm) / 1e9).toFixed(2),
  },
];

export const ContainersScreen: React.FC<ContainersScreenProps> = ({
  specs,
  activeProject,
  onUpdateSpecs,
  onSetProjectDefaultSpec,
}) => {
  const [notice, setNotice] = useState<string | null>(null);
  const skuMap = new Map(activeProject.skus.map((s) => [s.id, s]));
  const specsById = new Map(specs.map((s) => [s.id, s]));
  const usedSpecIds = new Set(activeProject.containers.map((c) => c.containerSpecId));

  const commit = (changes: CellChange[], rejects: CellReject[]) => {
    const next = [...specs];
    const msgs: string[] = [];
    for (const ch of changes) {
      const cur = next[ch.rowIndex];
      if (!cur) continue;
      if (ch.key === 'code') {
        const v = String(ch.value ?? '').trim().toUpperCase();
        if (!v || next.some((s) => s.id !== cur.id && s.code === v)) {
          msgs.push(`Mã cont "${v}" trống hoặc đã có — không đổi.`);
          continue;
        }
        next[ch.rowIndex] = { ...cur, code: v };
        continue;
      }
      next[ch.rowIndex] = { ...cur, [ch.key]: ch.value } as ContainerSpec;
      if (usedSpecIds.has(cur.id) && ch.key.startsWith('internal')) {
        msgs.push(`Đã đổi kích thước ${cur.code} đang dùng trong dự án — vào màn xếp 3D bấm "Tính lại" để kiểm tra thùng vượt lòng cont.`);
      }
    }
    for (const rj of rejects) msgs.push(`${next[rj.rowIndex]?.code ?? ''} · ${rj.header}: ${rj.reason} — bỏ qua`);
    if (changes.length) onUpdateSpecs(next);
    setNotice(msgs.length ? Array.from(new Set(msgs)).join(' ') : null);
  };

  const addSpec = () => {
    const base = specsById.get(activeProject.defaultContainerSpecId) ?? specs[0];
    let n = 1;
    while (specs.some((s) => s.code === `CONT-MOI-${n}`)) n++;
    onUpdateSpecs([
      ...specs,
      {
        ...base,
        id: `spec-${Date.now().toString(36)}`,
        code: `CONT-MOI-${n}`,
        name: `Cont mới (chép từ ${base.code})`,
        isDefault: false,
      },
    ]);
  };

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-slate-900">Loại container</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Sửa thẳng trong bảng (gõ hoặc dán từ Excel). Kích thước là <b>lòng cont dùng được</b>, đơn vị mm.
          </p>
        </div>
        <button
          onClick={addSpec}
          className="px-4 py-2 text-xs font-medium bg-blue-700 text-white rounded-md hover:bg-blue-800 flex items-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Thêm loại cont</span>
        </button>
      </div>

      {notice && (
        <div className="border rounded-lg px-4 py-2.5 text-xs bg-amber-50 border-amber-300 text-amber-950 flex justify-between gap-3">
          <span>{notice}</span>
          <button onClick={() => setNotice(null)} className="underline shrink-0">
            Đóng
          </button>
        </div>
      )}

      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-200 bg-slate-50/50">
          <h2 className="text-sm font-semibold text-slate-900">Thư viện loại cont</h2>
        </div>
        <EditableGrid<ContainerSpec>
          columns={SPEC_COLUMNS}
          rows={specs}
          rowKey={(s) => s.id}
          onCommit={commit}
          rowClassName={(s) => (activeProject.defaultContainerSpecId === s.id ? 'bg-blue-50/40' : 'hover:bg-slate-50')}
          trailingHeader="Mặc định của dự án"
          trailing={(s) => {
            const isDefault = activeProject.defaultContainerSpecId === s.id;
            return (
              <span className="inline-flex items-center gap-2">
                <button
                  onClick={() => onSetProjectDefaultSpec(s.id)}
                  className={`px-2.5 py-1 rounded text-xs font-medium ${
                    isDefault ? 'bg-blue-700 text-white' : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {isDefault ? 'Đang dùng' : 'Đặt mặc định'}
                </button>
                {!isDefault && !usedSpecIds.has(s.id) && specs.length > 1 && (
                  <button
                    onClick={() => {
                      if (window.confirm(`Xoá loại cont ${s.code}?`)) onUpdateSpecs(specs.filter((sp) => sp.id !== s.id));
                    }}
                    className="p-1 text-red-600 hover:bg-red-50 rounded"
                    title="Xoá loại cont"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </span>
            );
          }}
        />
      </div>

      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-200 bg-slate-50/50 flex items-center gap-2">
          <Container className="w-4 h-4 text-slate-500" />
          <h2 className="text-sm font-semibold text-slate-900">
            Cont của dự án {activeProject.code} ({activeProject.containers.length}) — số liệu tự tính
          </h2>
        </div>
        <table className="w-full text-xs text-left">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
            <tr>
              <th className="py-2.5 px-4 font-medium">Cont</th>
              <th className="py-2.5 px-3 font-medium text-right">Số thùng</th>
              <th className="py-2.5 px-3 font-medium text-right">Số lớp</th>
              <th className="py-2.5 px-3 font-medium text-right">Độ đầy</th>
              <th className="py-2.5 px-3 font-medium text-right">Trọng lượng hàng</th>
              <th className="py-2.5 px-4 font-medium text-right">Trọng tâm</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {activeProject.containers.map((c) => {
              const spec = specsById.get(c.containerSpecId) ?? specs[0];
              const st = computeContainerStats(c, spec, skuMap);
              return (
                <tr key={c.id} className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-medium text-slate-900">{c.label}</td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-right">{st.totalCartons}</td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-right">{st.layerCount}</td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-right">{st.volumeUtilizationPct.toFixed(1)}%</td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-right">
                    {st.totalCargoWeightKg.toFixed(1)} kg ({st.payloadUtilizationPct.toFixed(1)}%)
                  </td>
                  <td className={`py-2.5 px-4 text-right font-medium ${st.cogBalanceOk ? 'text-emerald-700' : 'text-amber-700'}`}>
                    {st.cogBalanceOk ? 'Cân bằng' : 'Lệch — cần xem'}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
