import React, { useState } from 'react';
import { CheckCircle2, Layers, Play, Trash2, AlertCircle, Search } from 'lucide-react';
import {
  ContainerLoad,
  ContainerSpec,
  LoadingProject,
  LoadingTemplate,
  PlacedCarton,
} from '../../types/clos';
import { reconcileProjectQuantities } from '../../engine/reconciliation';

interface TemplatesScreenProps {
  templates: LoadingTemplate[];
  activeProject: LoadingProject;
  specs: ContainerSpec[];
  onApplyTemplate: (newContainer: ContainerLoad, templateName: string) => void;
  onDeleteTemplate: (templateId: string) => void;
}

export const TemplatesScreen: React.FC<TemplatesScreenProps> = ({
  templates,
  activeProject,
  specs,
  onApplyTemplate,
  onDeleteTemplate,
}) => {
  const recon = reconcileProjectQuantities(
    activeProject.skus,
    activeProject.containers
  );
  const remByFactorySku = new Map(
    recon.rows.map((r) => [r.factorySku, r.remainingQty])
  );
  const skuByFactory = new Map(
    activeProject.skus.map((s) => [s.factorySku, s])
  );

  const [query, setQuery] = useState('');
  const [onlyCompatible, setOnlyCompatible] = useState(false);
  const q = query.trim().toLowerCase();
  const matches = (tpl: LoadingTemplate) =>
    !q ||
    [tpl.name, tpl.description, tpl.containerSpecCode, ...tpl.skuSignatures.flatMap((x) => [x.factorySku, x.customerSku])]
      .some((v) => (v ?? '').toLowerCase().includes(q));

  const checkCompatibility = (tpl: LoadingTemplate) => {
    const targetSpec =
      specs.find((s) => s.code === tpl.containerSpecCode) ?? specs[0];
    const dimsFit =
      tpl.containerLengthMm <= targetSpec.internalLengthMm &&
      tpl.containerWidthMm <= targetSpec.internalWidthMm &&
      tpl.containerHeightMm <= targetSpec.internalHeightMm;

    let matchingSkus = 0;
    let applicablePlacements = 0;
    const notes: string[] = [];

    for (const sig of tpl.skuSignatures) {
      const projSku = skuByFactory.get(sig.factorySku);
      if (!projSku) {
        notes.push(`${sig.factorySku} không có trong dự án đang mở`);
        continue;
      }
      const sameDims =
        projSku.lengthMm === sig.lengthMm &&
        projSku.widthMm === sig.widthMm &&
        projSku.heightMm === sig.heightMm;
      if (!sameDims) {
        notes.push(`${sig.factorySku} đã đổi kích thước`);
        continue;
      }
      const rem = remByFactorySku.get(sig.factorySku) ?? 0;
      if (rem > 0) {
        matchingSkus++;
        applicablePlacements += Math.min(rem, sig.countInTemplate);
      } else {
        notes.push(`${sig.factorySku} không còn số lượng chờ xếp`);
      }
    }

    const compatible = dimsFit && applicablePlacements > 0;
    return {
      compatible,
      targetSpec,
      matchingSkus,
      applicablePlacements,
      notes,
    };
  };

  const handleApply = (tpl: LoadingTemplate) => {
    const compat = checkCompatibility(tpl);
    if (!compat.compatible) return;

    const remCounter = new Map(remByFactorySku);
    const nextNum = activeProject.containers.length + 1;
    const newContainerId = `cnt-tpl-${Date.now().toString(36)}`;
    const newPlacements: PlacedCarton[] = [];

    // Map template placements by matching SKU signature dimensions
    for (const p of tpl.placements) {
      const matchedSig = tpl.skuSignatures.find((sig) => {
        const projSku = skuByFactory.get(sig.factorySku);
        if (!projSku) return false;
        // Match either by original skuId or dimensions
        return (
          projSku.id === p.skuId ||
          (projSku.lengthMm === sig.lengthMm &&
            projSku.widthMm === sig.widthMm &&
            projSku.heightMm === sig.heightMm &&
            (p.dimXMm === sig.lengthMm || p.dimZMm === sig.lengthMm))
        );
      });

      const targetSku = matchedSig
        ? skuByFactory.get(matchedSig.factorySku)
        : activeProject.skus.find((s) => s.id === p.skuId);

      if (!targetSku) continue;
      const rem = remCounter.get(targetSku.id === targetSku.id ? targetSku.factorySku : '') ?? 0;
      if (rem <= 0) continue;

      remCounter.set(targetSku.factorySku, rem - 1);
      newPlacements.push({
        ...p,
        instanceId: `tpl-${Date.now().toString(36)}-${newPlacements.length}`,
        skuId: targetSku.id,
        containerId: newContainerId,
      });
    }

    if (newPlacements.length === 0) return;

    const newContainer: ContainerLoad = {
      id: newContainerId,
      containerSpecId: compat.targetSpec.id,
      label: `Cont #${nextNum} (${compat.targetSpec.code})`,
      sequenceNumber: nextNum,
      placements: newPlacements,
    };

    onApplyTemplate(newContainer, tpl.name);
  };

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded-lg p-4">
        <h1 className="text-lg font-bold text-slate-900">
          Thư viện mẫu xếp
        </h1>
        <p className="text-xs text-slate-600 mt-0.5">
          Mẫu xếp dùng lại theo tổ hợp mã hàng và loại cont. Hệ thống kiểm tra tương thích trước khi áp dụng, kể cả khi số lượng đơn thay đổi.
        </p>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[16rem] max-w-md">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Tìm tên mẫu, mã hàng, loại cont…"
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-md bg-white"
            />
          </div>
          <label className="flex items-center gap-1.5 text-xs text-slate-700">
            <input type="checkbox" checked={onlyCompatible} onChange={(e) => setOnlyCompatible(e.target.checked)} />
            Chỉ hiện mẫu dùng được cho dự án đang mở
          </label>
          <span className="text-xs text-slate-500">
            {templates.length} mẫu
          </span>
        </div>
      </div>

      {templates.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-lg p-8 text-center text-xs text-slate-500">
          Chưa có mẫu nào. Vào màn xếp 3D và bấm &ldquo;Lưu mẫu&rdquo; ở cont muốn lưu.
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {templates.filter(matches).map((tpl) => {
            const compat = checkCompatibility(tpl);
            if (onlyCompatible && !compat.compatible) return null;
            return (
              <div
                key={tpl.id}
                className="bg-white border border-slate-200 rounded-lg p-5 flex flex-col justify-between gap-4"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-xs font-mono text-slate-500">
                        {tpl.containerSpecCode} · {tpl.placements.length}{' '}
                        thùng · {tpl.utilizationPct.toFixed(1)}% thể tích
                      </p>
                      <h2 className="text-base font-semibold text-slate-900 mt-0.5">
                        {tpl.name}
                      </h2>
                    </div>
                    <button
                      onClick={() => onDeleteTemplate(tpl.id)}
                      className="p-1.5 text-slate-400 hover:text-red-600 rounded"
                      title="Xoá mẫu"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <p className="text-xs text-slate-600">{tpl.description}</p>

                  <div className="border border-slate-200 rounded-md overflow-hidden">
                    <table className="w-full text-[11px] text-left">
                      <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                        <tr>
                          <th className="py-1.5 px-2.5 font-medium">
                            Mã nhà máy
                          </th>
                          <th className="py-1.5 px-2.5 font-medium text-right">
                            Thùng (mm)
                          </th>
                          <th className="py-1.5 px-2.5 font-medium text-right">
                            SL trong mẫu
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
                        {tpl.skuSignatures.map((sig, i) => (
                          <tr key={i}>
                            <td className="py-1.5 px-2.5 text-slate-900">
                              {sig.factorySku}
                            </td>
                            <td className="py-1.5 px-2.5 text-right text-slate-600">
                              {sig.lengthMm}×{sig.widthMm}×{sig.heightMm}
                            </td>
                            <td className="py-1.5 px-2.5 text-right text-slate-900">
                              {sig.countInTemplate}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200 flex items-center justify-between gap-3">
                  <div className="text-xs flex items-center gap-1.5">
                    {compat.compatible ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span className="text-emerald-800">
                          Tương thích: xếp được tối đa{' '}
                          <strong className="font-mono">
                            {compat.applicablePlacements}
                          </strong>{' '}
                          thùng đang chờ
                        </span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                        <span className="text-amber-800">
                          {compat.notes[0] ??
                            'Không còn mã nào khớp đang chờ xếp'}
                        </span>
                      </>
                    )}
                  </div>

                  <button
                    disabled={!compat.compatible}
                    onClick={() => handleApply(tpl)}
                    className={`px-3 py-1.5 rounded text-xs font-medium flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                      compat.compatible
                        ? 'bg-blue-700 text-white hover:bg-blue-800'
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    }`}
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>Áp dụng vào dự án</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="bg-slate-100 border border-slate-200 rounded-lg p-4 text-xs text-slate-700 flex items-center gap-2">
        <Layers className="w-4 h-4 text-slate-500 shrink-0" />
        <span>
          Mẹo: sau khi áp dụng, vẫn chỉnh, xoay, hoặc lấp chỗ trống trong màn xếp 3D mà không phải làm lại từ đầu.
        </span>
      </div>
    </div>
  );
};
