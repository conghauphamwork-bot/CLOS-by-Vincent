import { statusVi } from '../../lib/status';
import React, { useState } from 'react';
import {
  BarChart3,
  CheckCircle2,
  Cpu,
  Play,
  Settings,
  XCircle,
} from 'lucide-react';
import { api } from '../../api/client';
import {
  runAcceptanceTestSuite,
  TestCaseResult,
} from '../../engine/testSuite';
import {
  BenchmarkTrialRow,
  ContainerSpec,
  LoadingProject,
  OptimizationConfig,
} from '../../types/clos';

interface SettingsBenchmarkScreenProps {
  project: LoadingProject;
  specs: ContainerSpec[];
  onUpdateConfig: (config: OptimizationConfig) => void;
  onSetCargowizContainers?: (n: number | undefined) => void;
}

const ALGORITHM_EVALUATION = [
  {
    name: 'FFD – xếp tham lam (First Fit Decreasing)',
    complexity: 'O(N log N + N·E)',
    strength: 'Rất nhanh, kết quả cố định — dùng làm mốc so sánh.',
    limitation: 'Nhét chỗ vừa đầu tiên nên để lại nhiều khe hở, trọng tâm dễ lệch.',
    suitability: 'Mốc so sánh',
  },
  {
    name: 'BFD – chọn chỗ vừa khít nhất',
    complexity: 'O(N log N + N·C·E)',
    strength: 'Dồn hàng chặt hơn khi lô có nhiều cont.',
    limitation: 'Kết quả phụ thuộc thứ tự sắp hàng ban đầu.',
    suitability: 'Một biến thể trong danh mục xếp khối',
  },
  {
    name: 'Điểm góc (Extreme Points)',
    complexity: 'O(N · |EP| · |R|)',
    strength: 'Đặt thùng tại các góc trống; dễ kiểm độ đỡ đáy và canh vách.',
    limitation: 'Xếp một lượt nên dễ bỏ lỡ cách sắp tốt hơn.',
    suitability: 'Tham khảo (bản TS cũ)',
  },
  {
    name: 'Hộc trống tối đa + xếp khối (Maximal Spaces)',
    complexity: 'O(N · |MS| · |R|)',
    strength: 'Rất hợp thùng nội thất đóng phẳng, xếp thành khối cùng mã.',
    limitation: 'Phải quản lý nhiều hộc trống chồng nhau.',
    suitability: 'Lõi của engine Python (10 biến thể)',
  },
  {
    name: 'Phá–sửa (kiểu ALNS)',
    complexity: 'O(I · N · |EP|)',
    strength: 'Dỡ các cont lỏng nhất rồi xếp lại theo thứ tự khác để giảm số cont.',
    limitation: 'Có yếu tố ngẫu nhiên (seed cố định nên chạy lại ra cùng kết quả); tốn ~30 giây.',
    suitability: 'Bước cải thiện của engine Python',
  },
  {
    name: 'Di truyền / mô phỏng tôi luyện / Tabu',
    complexity: 'O(G · P · N · |EP|)',
    strength: 'Thử rộng nhiều thứ tự và hướng xoay.',
    limitation: 'Hội tụ chậm hơn phá–sửa với hàng nội thất, khó chỉnh tham số.',
    suitability: 'Không dùng',
  },
  {
    name: 'Quy hoạch nguyên / CP-SAT',
    complexity: 'NP-khó (tăng theo cấp số mũ)',
    strength: 'Chứng minh được tối ưu và cận dưới chặt.',
    limitation: 'Quá chậm với lô hàng nghìn thùng nếu dùng trực tiếp.',
    suitability: 'Dự kiến giai đoạn sau (chứng minh tối ưu)',
  },
];

export const SettingsBenchmarkScreen: React.FC<SettingsBenchmarkScreenProps> = ({
  project,
  specs,
  onUpdateConfig,
  onSetCargowizContainers,
}) => {
  const [subTab, setSubTab] = useState<
    'rules' | 'benchmark' | 'tests' | 'architecture'
  >('rules');

  // Benchmark chạy trên máy chủ Python, chỉ khi bấm nút (không tự chạy khi mở tab)
  const [benchmarkRows, setBenchmarkRows] = useState<BenchmarkTrialRow[]>([]);
  const [benchBusy, setBenchBusy] = useState(false);
  const [benchError, setBenchError] = useState<string | null>(null);
  const [benchSeconds, setBenchSeconds] = useState(15);
  const [testResults, setTestResults] = useState<TestCaseResult[] | null>(null);

  const cfg = project.optimizationConfig;

  const handleRunBenchmark = async () => {
    setBenchBusy(true);
    setBenchError(null);
    try {
      setBenchmarkRows(await api.benchmark(project, specs, benchSeconds));
    } catch (e) {
      setBenchError((e as Error).message);
    } finally {
      setBenchBusy(false);
    }
  };

  // Dòng CargoWiz chỉ hiện khi người dùng nhập số cont THẬT từ file CargoWiz cùng lô
  const cargowizRow: BenchmarkTrialRow | null =
    project.cargowizContainers && project.cargowizContainers > 0
      ? {
          algorithmId: 'cargowiz_actual',
          algorithmName: 'CargoWiz (số thực tế nhập tay)',
          category: 'Hệ thống hiện tại',
          containersUsed: project.cargowizContainers,
          avgVolumePct: 0,
          bestVolumePct: 0,
          worstVolumePct: 0,
          payloadPct: 0,
          violations: 0,
          computeTimeMs: 0,
          feasible: true,
          optimalityGapPct: 0,
          statusLabel: 'Đối chứng',
          notes:
            'Lấy từ file CargoWiz thật của cùng lô hàng. Chỉ so số cont; độ đầy/lỗi không có dữ liệu nên để trống.',
        }
      : null;
  const displayRows = cargowizRow ? [cargowizRow, ...benchmarkRows] : benchmarkRows;

  const handleRunTests = () => {
    setTestResults(runAcceptanceTestSuite());
  };

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-slate-900">
            Luật xếp hàng
          </h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Các ràng buộc engine dùng khi xếp tự động và khi kiểm tra.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-md">
          {(
            [
              ['rules', 'Luật xếp hàng'],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setSubTab(key)}
              className={`px-3 py-1.5 text-xs font-medium rounded whitespace-nowrap shrink-0 ${
                subTab === key
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab 1: Optimization Benchmark Suite */}

      {/* Tab 2: Configurable Business Rules */}
      {subTab === 'rules' && (
        <div className="bg-white border border-slate-200 rounded-lg p-5 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
              <Settings className="w-4 h-4 text-slate-500" />
              <span>Ràng buộc vật lý & an toàn</span>
            </h2>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Tỷ lệ diện tích đỡ đáy tối thiểu:{' '}
                <span className="font-mono font-semibold">
                  {Math.round(cfg.minSupportRatio * 100)}%
                </span>
              </label>
              <input
                type="range"
                min={0.5}
                max={1.0}
                step={0.05}
                value={cfg.minSupportRatio}
                onChange={(e) =>
                  onUpdateConfig({
                    ...cfg,
                    minSupportRatio: Number(e.target.value),
                  })
                }
                className="w-full accent-blue-700"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Độ lệch trọng tâm cho phép:{' '}
                <span className="font-mono font-semibold">
                  ±{cfg.maxCogOffsetPct}%
                </span>
              </label>
              <input
                type="range"
                min={5}
                max={25}
                step={1}
                value={cfg.maxCogOffsetPct}
                onChange={(e) =>
                  onUpdateConfig({
                    ...cfg,
                    maxCogOffsetPct: Number(e.target.value),
                  })
                }
                className="w-full accent-blue-700"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Số lượt thử (chỉ bản TS cũ):{' '}
                <span className="font-mono font-semibold">
                  {cfg.alnsIterations} lượt
                </span>
              </label>
              <input
                type="range"
                min={3}
                max={12}
                step={1}
                value={cfg.alnsIterations}
                onChange={(e) =>
                  onUpdateConfig({
                    ...cfg,
                    alnsIterations: Number(e.target.value),
                  })
                }
                className="w-full accent-blue-700"
              />
            </div>
          </div>

          <div className="space-y-3">
            <h2 className="text-sm font-semibold text-slate-900">
              Bật/tắt kiểm tra
            </h2>
            {(
              [
                ['respectStacking', 'Áp dụng luật chồng hàng & số lớp tối đa'],
                ['respectRotation', 'Áp dụng mã xoay 1/2/4/6'],
                ['respectPayload', 'Kiểm tải trọng tối đa của cont (kg)'],
                [
                  'prioritizeHeavyBottom',
                  'Ưu tiên hàng nặng / không dễ vỡ ở lớp dưới',
                ],
                [
                  'autoAddContainers',
                  'Tự mở cont mới khi cont đầy',
                ],
              ] as const
            ).map(([field, label]) => (
              <label
                key={field}
                className="flex items-center gap-2.5 text-xs text-slate-800 border border-slate-200 rounded-md p-2.5 cursor-pointer hover:bg-slate-50"
              >
                <input
                  type="checkbox"
                  checked={cfg[field]}
                  onChange={(e) =>
                    onUpdateConfig({ ...cfg, [field]: e.target.checked })
                  }
                />
                <span>{label}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Live Executable Acceptance Test Suite (TC01 - TC12) */}

      {/* Tab 4: Architecture, Algorithm Evaluation & Mathematical Formulation */}
    </div>
  );
};
