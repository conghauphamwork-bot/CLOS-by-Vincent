import { statusVi } from '../../lib/status';
import React from 'react';
import {
  ArrowRight,
  Box,
  CheckCircle2,
  Container,
  FileSpreadsheet,
  Layers,
  ShieldCheck,
} from 'lucide-react';
import {
  AppScreen,
  ContainerSpec,
  LoadingProject,
} from '../../types/clos';
import { reconcileProjectQuantities } from '../../engine/reconciliation';
import { validateProject } from '../../engine/validator';

interface DashboardScreenProps {
  projects: LoadingProject[];
  activeProject: LoadingProject;
  specs: ContainerSpec[];
  onSelectProject: (id: string) => void;
  onNavigate: (screen: AppScreen) => void;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({
  projects,
  activeProject,
  specs,
  onSelectProject,
  onNavigate,
}) => {
  const specsById = new Map(specs.map((s) => [s.id, s]));
  const recon = reconcileProjectQuantities(
    activeProject.skus,
    activeProject.containers
  );
  const issues = validateProject(
    activeProject.containers,
    specsById,
    activeProject.skus,
    activeProject.optimizationConfig
  );
  const errorCount = issues.filter((i) => i.severity === 'error').length;

  const avgVol = activeProject.lastMetrics?.volumeUtilizationPct ?? 0;
  const totalCartonsAll = projects.reduce(
    (s, p) => s + p.skus.reduce((k, sku) => k + sku.requiredQty, 0),
    0
  );

  return (
    <div className="space-y-6">
      {/* Header Summary */}
      <div className="bg-white border border-slate-200 rounded-lg p-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Lô hàng đang mở · {activeProject.code}
          </p>
          <h1 className="text-2xl font-bold text-slate-900 mt-1">
            {activeProject.name}
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            {activeProject.customerName} · Cảng đến:{' '}
            {activeProject.destinationPort}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('cargo')}
            className="px-4 py-2 text-xs font-medium border border-slate-300 rounded-md text-slate-700 bg-white hover:bg-slate-50 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Quản lý dữ liệu hàng</span>
          </button>
          <button
            onClick={() => onNavigate('workspace')}
            className="px-4 py-2 text-xs font-medium bg-blue-700 text-white rounded-md hover:bg-blue-800 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <span>Mở màn xếp 3D</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 4-Column KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Số cont đã dùng</span>
            <Container className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-2">
            {activeProject.containers.length}
          </p>
          <p className="text-xs text-slate-600 mt-1">
            Cận dưới:{' '}
            <span className="font-mono tabular-nums">
              {activeProject.lastMetrics?.lowerBoundContainers ?? '-'}
            </span>{' '}
            cont
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Độ đầy trung bình</span>
            <Box className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-2">
            {avgVol.toFixed(1)}%
          </p>
          <p className="text-xs text-slate-600 mt-1">
            {activeProject.lastMetrics?.statusLabel ? statusVi(activeProject.lastMetrics.statusLabel) : 'Sẵn sàng tính'}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Đối soát số lượng</span>
            <Layers className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-2">
            {recon.totalLoaded} / {recon.totalRequired}
          </p>
          <p
            className={`text-xs mt-1 font-medium ${
              recon.hasDiscrepancies
                ? 'text-red-700'
                : recon.totalRemaining === 0
                  ? 'text-emerald-700'
                  : 'text-amber-700'
            }`}
          >
            {recon.totalRemaining} còn lại ·{' '}
            {recon.hasDiscrepancies ? 'Discrepancy' : 'Balanced'}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Kiểm tra ràng buộc</span>
            <ShieldCheck className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-2">
            {errorCount === 0 ? 'PASS' : `${errorCount} LỖI`}
          </p>
          <p className="text-xs text-slate-600 mt-1">
            {issues.length} lượt kiểm · {projects.length} dự án (
            {totalCartonsAll} thùng)
          </p>
        </div>
      </div>

      {/* Projects & Recent Audit Trail Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-lg overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-900">
              Dự án xếp hàng
            </h2>
            <button
              onClick={() => onNavigate('projects')}
              className="text-xs font-medium text-blue-700 hover:underline"
            >
              Xem tất cả dự án
            </button>
          </div>
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
              <tr>
                <th className="py-2.5 px-4 font-medium">Mã</th>
                <th className="py-2.5 px-3 font-medium">Dự án</th>
                <th className="py-2.5 px-3 font-medium text-right">Số mã</th>
                <th className="py-2.5 px-3 font-medium text-right">
                  Số cont
                </th>
                <th className="py-2.5 px-4 font-medium text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {projects.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-mono font-medium text-slate-900">
                    {p.code}
                  </td>
                  <td className="py-2.5 px-3">
                    <p className="font-medium text-slate-900">{p.name}</p>
                    <p className="text-slate-500">
                      {p.customerName} · {p.destinationPort}
                    </p>
                  </td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-right">
                    {p.skus.length}
                  </td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-right">
                    {p.containers.length}
                  </td>
                  <td className="py-2.5 px-4 text-right">
                    <button
                      onClick={() => {
                        onSelectProject(p.id);
                        onNavigate('workspace');
                      }}
                      className="px-2.5 py-1 text-xs font-medium bg-slate-900 text-white rounded hover:bg-slate-800 whitespace-nowrap"
                    >
                      {p.id === activeProject.id ? 'Đang mở · Mở' : 'Load'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-lg overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-900">
              Lịch sử thay đổi ({activeProject.code})
            </h2>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
            {activeProject.auditTrail
              .slice()
              .reverse()
              .slice(0, 8)
              .map((entry) => (
                <div key={entry.id} className="px-4 py-2.5 text-xs">
                  <div className="flex items-center justify-between text-slate-500">
                    <span className="font-mono font-medium text-slate-800">
                      {entry.action}
                    </span>
                    <span className="font-mono tabular-nums">
                      {new Date(entry.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-slate-700 mt-0.5">{entry.details}</p>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};
