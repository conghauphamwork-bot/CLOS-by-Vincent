import React, { useState } from 'react';
import {
  Copy,
  FolderOpen,
  History,
  Plus,
  Trash2,
} from 'lucide-react';
import { DEFAULT_OPTIMIZATION_CONFIG } from '../../data/seedProjects';
import { ContainerSpec, LoadingProject } from '../../types/clos';
import { EditableGrid, GridColumn } from '../common/EditableGrid';

interface ProjectsScreenProps {
  projects: LoadingProject[];
  activeProjectId: string;
  specs: ContainerSpec[];
  onSelectProject: (id: string) => void;
  onCreateProject: (project: LoadingProject) => void;
  onDuplicateProject: (id: string) => void;
  onDeleteProject: (id: string) => void;
  onOpenWorkspace: () => void;
  onUpdateProject: (project: LoadingProject, note: string) => void;
}

const STATUS_VI: Record<string, string> = {
  draft: 'Nháp',
  calculated: 'Đã tính',
  verified: 'Đã kiểm',
  exported: 'Đã xuất',
};

const PROJECT_COLUMNS: GridColumn<LoadingProject>[] = [
  { key: 'code', header: 'Mã dự án', kind: 'text', width: 'w-36', mono: true, get: (p) => p.code },
  { key: 'name', header: 'Tên dự án', kind: 'text', width: 'w-56', get: (p) => p.name },
  { key: 'customerName', header: 'Khách hàng', kind: 'text', width: 'w-40', optional: true, get: (p) => p.customerName },
  { key: 'destinationPort', header: 'Cảng đến', kind: 'text', width: 'w-32', optional: true, get: (p) => p.destinationPort },
  { key: '_skus', header: 'Số mã', kind: 'int', align: 'right', readOnly: true, mono: true, get: (p) => p.skus.length },
  { key: '_conts', header: 'Số cont', kind: 'int', align: 'right', readOnly: true, mono: true, get: (p) => p.containers.length },
  { key: '_status', header: 'Trạng thái', kind: 'text', align: 'right', readOnly: true, get: (p) => STATUS_VI[p.status] ?? p.status },
  { key: '_updated', header: 'Cập nhật', kind: 'text', align: 'right', readOnly: true, mono: true, get: (p) => new Date(p.updatedAt).toLocaleDateString('vi-VN') },
];

export const ProjectsScreen: React.FC<ProjectsScreenProps> = ({
  projects,
  activeProjectId,
  specs,
  onSelectProject,
  onCreateProject,
  onDuplicateProject,
  onDeleteProject,
  onOpenWorkspace,
  onUpdateProject,
}) => {
  const [showCreate, setShowCreate] = useState(false);
  const [code, setCode] = useState('EXP-2026-1050');
  const [name, setName] = useState('');
  const [customer, setCustomer] = useState('');
  const [port, setPort] = useState('');
  const [specId, setSpecId] = useState(specs[0]?.id ?? 'spec-40hc');
  const [historyProject, setHistoryProject] = useState<LoadingProject | null>(
    null
  );

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const newProj: LoadingProject = {
      id: `proj-${Date.now().toString(36)}`,
      code: code.trim() || `EXP-${Date.now().toString().slice(-4)}`,
      name: name.trim(),
      customerName: customer.trim() || 'Khách xuất khẩu',
      destinationPort: port.trim() || 'TBD',
      status: 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      skus: [],
      containers: [],
      defaultContainerSpecId: specId,
      optimizationConfig: { ...DEFAULT_OPTIMIZATION_CONFIG },
      auditTrail: [
        {
          id: `aud-${Date.now()}`,
          timestamp: new Date().toISOString(),
          actor: 'Người dùng',
          action: 'CREATE_PROJECT',
          target: code,
          details: `Tạo dự án xếp hàng mới "${name.trim()}".`,
        },
      ],
    };
    onCreateProject(newProj);
    setShowCreate(false);
    setName('');
    setCustomer('');
    setPort('');
  };

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-slate-900">Dự án xếp hàng</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Lưu, mở lại, nhân bản và xem lịch sử các dự án xếp cont. Sửa thẳng mã, tên, khách, cảng trong bảng.
          </p>
        </div>
        <button
          onClick={() => setShowCreate((v) => !v)}
          className="px-4 py-2 text-xs font-medium bg-blue-700 text-white rounded-md hover:bg-blue-800 flex items-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Dự án mới</span>
        </button>
      </div>

      {showCreate && (
        <form
          onSubmit={handleCreate}
          className="bg-white border border-slate-200 rounded-lg p-4 grid grid-cols-1 md:grid-cols-5 gap-3 items-end"
        >
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Mã dự án
            </label>
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full text-xs border border-slate-300 rounded px-2.5 py-2 font-mono"
              required
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Tên dự án
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="vd: Đơn hàng CRD 03/2027"
              className="w-full text-xs border border-slate-300 rounded px-2.5 py-2"
              required
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Khách hàng
            </label>
            <input
              type="text"
              value={customer}
              onChange={(e) => setCustomer(e.target.value)}
              placeholder="Tên khách hàng"
              className="w-full text-xs border border-slate-300 rounded px-2.5 py-2"
            />
          </div>
          <div className="flex items-center gap-2">
            <div className="flex-1">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Loại cont mặc định
              </label>
              <select
                value={specId}
                onChange={(e) => setSpecId(e.target.value)}
                className="w-full text-xs border border-slate-300 rounded px-2 py-2 bg-white"
              >
                {specs.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.code} — {s.name}
                  </option>
                ))}
              </select>
            </div>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-medium bg-slate-900 text-white rounded hover:bg-slate-800 shrink-0"
            >
              Tạo
            </button>
          </div>
        </form>
      )}

      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <EditableGrid<LoadingProject>
          columns={PROJECT_COLUMNS}
          rows={projects}
          rowKey={(p) => p.id}
          rowClassName={(p) => (p.id === activeProjectId ? 'bg-blue-50/40' : 'hover:bg-slate-50')}
          onCommit={(changes, rejects) => {
            for (const ch of changes) {
              const p = projects[ch.rowIndex];
              if (!p) continue;
              const v = String(ch.value ?? '').trim();
              if (ch.key === 'code' && (!v || projects.some((x) => x.id !== p.id && x.code === v))) {
                window.alert(`Mã dự án "${v}" trống hoặc đã có.`);
                continue;
              }
              onUpdateProject({ ...p, [ch.key]: v } as LoadingProject, `Đổi ${ch.key}: "${String((p as unknown as Record<string, unknown>)[ch.key] ?? '')}" → "${v}"`);
            }
            if (rejects.length) window.alert(rejects.map((r) => `${r.header}: ${r.reason}`).join('\n'));
          }}
          trailingHeader="Thao tác"
          trailing={(p) => {
            const isActive = p.id === activeProjectId;
            return (
              <div className="inline-flex items-center gap-1.5">
                <button
                  onClick={() => {
                    onSelectProject(p.id);
                    onOpenWorkspace();
                  }}
                  className="px-2.5 py-1 rounded bg-slate-900 text-white hover:bg-slate-800 inline-flex items-center gap-1"
                >
                  <FolderOpen className="w-3 h-3" />
                  <span>{isActive ? 'Đang mở' : 'Mở'}</span>
                </button>
                <button
                  onClick={() => setHistoryProject(p)}
                  className="p-1.5 border border-slate-200 rounded hover:bg-slate-100 text-slate-700"
                  title="Lịch sử thay đổi"
                >
                  <History className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => onDuplicateProject(p.id)}
                  className="p-1.5 border border-slate-200 rounded hover:bg-slate-100 text-slate-700"
                  title="Nhân bản dự án"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
                {projects.length > 1 && (
                  <button
                    onClick={() => onDeleteProject(p.id)}
                    className="p-1.5 border border-red-200 rounded hover:bg-red-50 text-red-700"
                    title="Xoá dự án"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            );
          }}
        />
      </div>

      {historyProject && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-lg max-w-2xl w-full p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="text-sm font-semibold text-slate-900">
                Lịch sử thay đổi — {historyProject.code}
              </h3>
              <button
                onClick={() => setHistoryProject(null)}
                className="text-xs text-slate-600 hover:text-slate-900"
              >
                Đóng
              </button>
            </div>
            <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
              {historyProject.auditTrail
                .slice()
                .reverse()
                .map((a) => (
                  <div key={a.id} className="py-2 text-xs">
                    <div className="flex justify-between font-mono text-slate-500">
                      <span className="font-semibold text-slate-800">
                        {a.action} · {a.actor}
                      </span>
                      <span>{new Date(a.timestamp).toLocaleString()}</span>
                    </div>
                    <p className="text-slate-700 mt-0.5">{a.details}</p>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
