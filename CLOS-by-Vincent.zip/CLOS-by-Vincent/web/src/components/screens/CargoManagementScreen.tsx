import React, { useMemo, useRef, useState } from 'react';
import { AlertTriangle, ClipboardCopy, Search, Trash2, Upload } from 'lucide-react';
import { parseCargoExcelFile } from '../../engine/excelService';
import { CargoSku, ExcelImportResult, LoadingProject } from '../../types/clos';
import {
  CellChange,
  CellReject,
  CellValue,
  EditableGrid,
  gridToTsv,
} from '../common/EditableGrid';
import { applySkuValue, REQUIRED_NEW, SKU_FIELDS, skuColumns, SkuField } from '../../lib/skuGrid';
import { ROTATION_CODES } from '../../lib/rotation';

interface CargoManagementScreenProps {
  project: LoadingProject;
  onUpdateSkus: (skus: CargoSku[], auditNote: string) => void;
  onGoToWorkspace: () => void;
  onDeleteSkus: (ids: string[]) => boolean;
}

const COLORS = ['#2563EB', '#0D9488', '#D97706', '#7C3AED', '#059669', '#DC2626', '#0284C7', '#DB2777', '#65A30D', '#9333EA'];
const BLANK_DRAFTS = 5;

// __bad: các ô dán/gõ sai của dòng nháp (dòng chưa được thêm khi còn ô sai)
type Draft = Partial<Record<SkuField, CellValue>> & { __bad?: Record<string, string> };
type Row = { kind: 'sku'; sku: CargoSku } | { kind: 'draft'; draft: Draft; index: number };

const isEmptyDraft = (d: Draft) =>
  Object.entries(d).every(([k, v]) => k === '__bad' || v === null || v === undefined || v === '') &&
  !Object.keys(d.__bad ?? {}).length;

function slug(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'sku';
}

export const CargoManagementScreen: React.FC<CargoManagementScreenProps> = ({
  project,
  onUpdateSkus,
  onGoToWorkspace,
  onDeleteSkus,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [search, setSearch] = useState('');
  const [drafts, setDrafts] = useState<Draft[]>([]);
  const [notice, setNotice] = useState<{ tone: 'ok' | 'warn'; lines: string[] } | null>(null);
  const [importReport, setImportReport] = useState<ExcelImportResult | null>(null);
  const [picked, setPicked] = useState<Set<string>>(new Set());

  const loadedBySku = useMemo(() => {
    const m = new Map<string, number>();
    for (const c of project.containers) for (const p of c.placements) m.set(p.skuId, (m.get(p.skuId) ?? 0) + 1);
    return m;
  }, [project.containers]);

  const filtered = project.skus.filter((s) => {
    const q = search.toLowerCase();
    return (
      !q ||
      s.factorySku.toLowerCase().includes(q) ||
      s.customerSku.toLowerCase().includes(q) ||
      s.description.toLowerCase().includes(q)
    );
  });

  // dòng mã hàng + dòng nháp (luôn chừa vài dòng trống để dán thêm)
  const draftRows = useMemo(() => {
    const list = [...drafts];
    let trailingBlank = 0;
    for (let i = list.length - 1; i >= 0 && isEmptyDraft(list[i]); i--) trailingBlank++;
    for (let i = trailingBlank; i < BLANK_DRAFTS; i++) list.push({});
    return list;
  }, [drafts]);

  const rows: Row[] = [
    ...filtered.map((sku) => ({ kind: 'sku' as const, sku })),
    ...draftRows.map((draft, index) => ({ kind: 'draft' as const, draft, index })),
  ];

  const columns = skuColumns<Row>((row) =>
    row.kind === 'sku' ? (row.sku as unknown as Partial<Record<SkuField, CellValue>>) : row.draft
  );

  const commit = (changes: CellChange[], rejects: CellReject[]) => {
    let skus = [...project.skus];
    const byId = new Map(skus.map((s, i) => [s.id, i]));
    const nextDrafts = [...draftRows];
    let edited = 0;
    const msgs: string[] = [];

    for (const ch of changes) {
      const row = rows[ch.rowIndex];
      if (row && row.kind === 'sku') {
        if (ch.key === 'factorySku') {
          const v = String(ch.value ?? '').trim();
          if (!v) {
            msgs.push(`Mã nhà máy không được để trống (${row.sku.factorySku}).`);
            continue;
          }
          if (skus.some((s) => s.id !== row.sku.id && s.factorySku === v)) {
            msgs.push(`Mã nhà máy "${v}" đã có — không đổi ${row.sku.factorySku}.`);
            continue;
          }
        }
        const i = byId.get(row.sku.id)!;
        skus[i] = applySkuValue(skus[i], ch.key, ch.value);
        edited++;
      } else {
        // dòng nháp (kể cả dán tràn xuống quá số dòng hiện có)
        const di = ch.rowIndex - filtered.length;
        while (nextDrafts.length <= di) nextDrafts.push({});
        const bad = { ...(nextDrafts[di].__bad ?? {}) };
        delete bad[ch.key];
        nextDrafts[di] = { ...nextDrafts[di], [ch.key]: ch.value, __bad: bad };
      }
    }
    // ô sai trên dòng nháp: ghi lại để dòng đó KHÔNG được thêm cho tới khi sửa
    for (const rj of rejects) {
      const row = rows[rj.rowIndex];
      if (row && row.kind === 'sku') continue;
      const di = rj.rowIndex - filtered.length;
      while (nextDrafts.length <= di) nextDrafts.push({});
      nextDrafts[di] = {
        ...nextDrafts[di],
        [rj.key]: rj.raw,
        __bad: { ...(nextDrafts[di].__bad ?? {}), [rj.key]: rj.reason },
      };
    }

    // dòng nháp đủ thông tin -> thành mã hàng (trùng mã nhà máy = cập nhật mã có sẵn)
    let added = 0;
    let merged = 0;
    const remaining: Draft[] = [];
    for (const d of nextDrafts) {
      if (isEmptyDraft(d)) continue;
      const complete =
        REQUIRED_NEW.every((k) => d[k] !== undefined && d[k] !== null && d[k] !== '') &&
        !Object.keys(d.__bad ?? {}).length;
      if (!complete) {
        remaining.push(d);
        continue;
      }
      const f = String(d.factorySku).trim();
      const existing = skus.findIndex((s) => s.factorySku === f);
      if (existing >= 0) {
        let s = skus[existing];
        for (const [k, v] of Object.entries(d)) if (k !== '__bad' && v !== undefined && v !== null && !(k !== 'factorySku' && v === '')) s = applySkuValue(s, k, v as CellValue);
        skus[existing] = s;
        merged++;
        continue;
      }
      const ids = new Set(skus.map((s) => s.id));
      let id = `sku-${slug(f)}`;
      for (let n = 2; ids.has(id); n++) id = `sku-${slug(f)}-${n}`;
      let created: CargoSku = {
        id,
        factorySku: f,
        customerSku: '',
        description: '',
        lengthMm: 0,
        widthMm: 0,
        heightMm: 0,
        weightKg: 0,
        requiredQty: 0,
        stackable: true,
        maxStackLayers: 99,
        maxStackWeightKg: 200,
        rotationPolicy: 'upright_only',
        fragile: false,
        palletized: false,
        color: COLORS[skus.length % COLORS.length],
      };
      for (const [k, v] of Object.entries(d)) if (k !== '__bad' && v !== undefined && v !== null) created = applySkuValue(created, k, v as CellValue);
      if (!created.description) created.description = created.factorySku;
      skus = [...skus, created];
      added++;
    }

    for (const rj of rejects) {
      const row = rows[rj.rowIndex];
      const name = row?.kind === 'sku' ? row.sku.factorySku : `dòng mới ${rj.rowIndex - filtered.length + 1}`;
      msgs.push(`${name} · ${rj.header}: ${rj.reason}${row?.kind === 'sku' ? ' — giữ giá trị cũ' : ' — dòng chưa được thêm'}`);
    }
    if (remaining.length) msgs.push(`${remaining.length} dòng mới còn thiếu hoặc sai (ô viền đỏ) — chưa thêm vào danh sách, sửa ô đó là tự thêm.`);

    setDrafts(remaining);
    if (edited || added || merged) {
      const parts = [
        edited ? `sửa ${edited} ô` : '',
        added ? `thêm ${added} mã` : '',
        merged ? `cập nhật ${merged} mã đã có` : '',
      ].filter(Boolean);
      onUpdateSkus(skus, `Bảng dữ liệu hàng: ${parts.join(', ')}`);
      msgs.unshift(`Đã ${parts.join(', ')}.`);
    }
    setNotice(msgs.length ? { tone: rejects.length || remaining.length ? 'warn' : 'ok', lines: msgs } : null);
  };

  const draftError = (row: Row, key: string) => {
    if (row.kind !== 'draft' || isEmptyDraft(row.draft)) return undefined;
    if (row.draft.__bad?.[key]) return row.draft.__bad[key];
    const v = row.draft[key as SkuField];
    return REQUIRED_NEW.includes(key as SkuField) && (v === undefined || v === null || v === '')
      ? 'Thiếu — cần có để thêm mã'
      : undefined;
  };

  const confirmAndDelete = (ids: string[]) => {
    if (!ids.length) return;
    const set = new Set(ids);
    const list = project.skus.filter((s) => set.has(s.id));
    const cartons = list.reduce((a, s) => a + (loadedBySku.get(s.id) ?? 0), 0);
    const msg =
      (list.length === project.skus.length
        ? `XOÁ TẤT CẢ ${list.length} mã hàng của dự án ${project.code}?`
        : `Xoá ${list.length} mã: ${list.slice(0, 8).map((s) => s.factorySku).join(', ')}${list.length > 8 ? '…' : ''}?`) +
      (cartons ? `\n\n${cartons} thùng của các mã này đang nằm trong cont sẽ bị gỡ ra (cont trống sẽ bị bỏ).` : '') +
      '\n\nXoá nhầm thì bấm ↶ (Ctrl+Z) để lấy lại.';
    if (!window.confirm(msg)) return;
    if (onDeleteSkus(ids)) setPicked(new Set());
  };

  const handleDeleteSku = (sku: CargoSku) => confirmAndDelete([sku.id]);

  const handleCopyAll = async () => {
    const tsv = gridToTsv(columns.filter((c) => SKU_FIELDS.some((f) => f.key === c.key)), rows.filter((r) => r.kind === 'sku'));
    try {
      await navigator.clipboard.writeText(tsv);
      setNotice({ tone: 'ok', lines: [`Đã chép ${filtered.length} dòng — dán thẳng vào Excel.`] });
    } catch {
      setNotice({ tone: 'warn', lines: ['Trình duyệt chặn quyền chép. Hãy bôi đen bảng rồi Ctrl/Cmd+C.'] });
    }
  };

  const handleExcelUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const result = await parseCargoExcelFile(file);
    setImportReport(result);
    if (result.validSkus.length > 0 && result.errors.length === 0) applyImport(result, file.name);
    e.target.value = '';
  };

  const applyImport = (result: ExcelImportResult, source: string) => {
    const existingMap = new Map(project.skus.map((s) => [s.factorySku, s]));
    for (const imp of result.validSkus) {
      const prev = existingMap.get(imp.factorySku);
      existingMap.set(imp.factorySku, prev ? { ...imp, id: prev.id, color: prev.color } : imp);
    }
    onUpdateSkus(Array.from(existingMap.values()), `Nhập ${result.validSkus.length} mã từ file ${source}`);
    if (result.errors.length === 0) setImportReport(null);
  };

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-slate-900">Dữ liệu hàng</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Dự án: <span className="font-mono font-medium">{project.code}</span> · Copy vùng ô trong Excel rồi dán (Ctrl/Cmd+V)
            vào bảng. Dán vào <b>dòng trống phía dưới</b> để thêm mã; trùng Mã nhà máy thì cập nhật mã đó.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <input ref={fileInputRef} type="file" accept=".xlsx,.xls,.csv" onChange={handleExcelUpload} className="hidden" />
          <button
            onClick={handleCopyAll}
            className="px-3 py-2 text-xs font-medium border border-slate-300 rounded-md bg-white text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 whitespace-nowrap"
          >
            <ClipboardCopy className="w-3.5 h-3.5" />
            <span>Chép bảng ra Excel</span>
          </button>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-3 py-2 text-xs font-medium border border-slate-300 rounded-md bg-white text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 whitespace-nowrap"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Nhập từ file Excel</span>
          </button>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg px-4 py-2.5 text-[11px] text-blue-950 space-y-1">
        <p>
          <b>Thứ tự cột khi dán:</b> {SKU_FIELDS.map((f) => f.header).join(' → ')}. Có thể dán bắt đầu từ bất kỳ cột nào
          (vd chỉ dán cột Số lượng). Số kiểu 44,5 hoặc 1.860 đều đọc được.
        </p>
        <p>
          <b>Mã xoay (như CargoWiz):</b>{' '}
          {ROTATION_CODES.map((r) => (
            <span key={r.code} className="mr-3">
              <b>{r.code}</b> = {r.hint.split('–')[1]?.trim() ?? r.hint}
            </span>
          ))}
        </p>
      </div>

      {notice && (
        <div
          className={`border rounded-lg px-4 py-2.5 text-xs space-y-0.5 ${
            notice.tone === 'warn' ? 'bg-amber-50 border-amber-300 text-amber-950' : 'bg-emerald-50 border-emerald-300 text-emerald-950'
          }`}
        >
          <div className="flex justify-between gap-3">
            <div className="space-y-0.5 max-h-40 overflow-y-auto">
              {notice.lines.slice(0, 30).map((l, i) => (
                <p key={i}>{l}</p>
              ))}
              {notice.lines.length > 30 && <p>… và {notice.lines.length - 30} dòng khác</p>}
            </div>
            <button onClick={() => setNotice(null)} className="underline shrink-0 self-start">
              Đóng
            </button>
          </div>
        </div>
      )}

      {importReport && importReport.errors.length > 0 && (
        <div className="border rounded-lg p-4 space-y-2 text-xs bg-amber-50 border-amber-300 text-amber-950">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-semibold">
              <AlertTriangle className="w-4 h-4" />
              <span>
                File Excel: {importReport.validSkus.length} dòng hợp lệ, {importReport.errors.length} lỗi / {importReport.totalRowsRead} dòng
              </span>
            </div>
            <button onClick={() => setImportReport(null)} className="underline">
              Đóng
            </button>
          </div>
          <div className="max-h-40 overflow-y-auto bg-white/80 border border-amber-200 rounded p-2.5 space-y-1 font-mono">
            {importReport.errors.map((err, idx) => (
              <p key={idx} className="text-red-800">
                Dòng {err.rowNumber} [{err.factorySku}] · {err.field}: {err.message}
              </p>
            ))}
          </div>
          {importReport.validSkus.length > 0 && (
            <button onClick={() => applyImport(importReport, 'Excel (bỏ dòng lỗi)')} className="px-3 py-1.5 bg-slate-900 text-white rounded font-medium">
              Chỉ nhập {importReport.validSkus.length} dòng hợp lệ
            </button>
          )}
        </div>
      )}

      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-200 flex items-center justify-between gap-4 bg-slate-50/50">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Tìm mã nhà máy, mã khách, mô tả…"
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-md bg-white"
            />
          </div>
          <span className="text-xs text-slate-500">
            {project.skus.length} mã · {project.skus.reduce((a, s) => a + s.requiredQty, 0)} thùng
          </span>
          <div className="flex items-center gap-2">
            <button
              disabled={!picked.size}
              onClick={() => confirmAndDelete(Array.from(picked))}
              className="px-2.5 py-1.5 text-xs font-medium rounded-md border border-red-300 text-red-700 bg-white hover:bg-red-50 disabled:opacity-40 flex items-center gap-1 whitespace-nowrap"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Xoá {picked.size || ''} mã đã chọn
            </button>
            <button
              disabled={!project.skus.length}
              onClick={() => confirmAndDelete(project.skus.map((s) => s.id))}
              className="px-2.5 py-1.5 text-xs font-medium rounded-md bg-red-600 text-white hover:bg-red-700 disabled:opacity-40 whitespace-nowrap"
            >
              Xoá tất cả
            </button>
          </div>
          <button onClick={onGoToWorkspace} className="text-xs font-medium text-blue-700 hover:underline whitespace-nowrap">
            Xem trên màn xếp 3D →
          </button>
        </div>

        <EditableGrid<Row>
          columns={columns}
          rows={rows}
          rowKey={(r, i) => (r.kind === 'sku' ? r.sku.id : `draft-${i}`)}
          onCommit={commit}
          allowOverflowRows
          cellError={(row, key) => draftError(row, key)}
          rowClassName={(r) => (r.kind === 'draft' ? 'bg-slate-50/70' : 'hover:bg-slate-50')}
          leadingHeader={
            <input
              type="checkbox"
              title="Chọn tất cả mã đang hiện (theo ô tìm kiếm)"
              checked={filtered.length > 0 && filtered.every((s) => picked.has(s.id))}
              onChange={(e) =>
                setPicked((prev) => {
                  const next = new Set(prev);
                  for (const s of filtered) e.target.checked ? next.add(s.id) : next.delete(s.id);
                  return next;
                })
              }
            />
          }
          leading={(r) =>
            r.kind === 'sku' ? (
              <span className="inline-flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={picked.has(r.sku.id)}
                  onChange={() =>
                    setPicked((prev) => {
                      const next = new Set(prev);
                      next.has(r.sku.id) ? next.delete(r.sku.id) : next.add(r.sku.id);
                      return next;
                    })
                  }
                />
                <span className="inline-block w-2.5 h-2.5 rounded-xs" style={{ backgroundColor: r.sku.color }} />
              </span>
            ) : (
              <span className="text-[10px] text-slate-400 pl-5">mới</span>
            )
          }
          trailingHeader="Đã xếp"
          trailing={(r) =>
            r.kind === 'sku' ? (
              <span className="inline-flex items-center gap-2">
                <span className="font-mono tabular-nums text-slate-600">{loadedBySku.get(r.sku.id) ?? 0}</span>
                <button onClick={() => handleDeleteSku(r.sku)} className="p-1 text-red-600 hover:bg-red-50 rounded" title="Xoá mã">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </span>
            ) : null
          }
        />
      </div>
    </div>
  );
};
