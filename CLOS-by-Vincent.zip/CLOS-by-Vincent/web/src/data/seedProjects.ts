import { runOptimization } from '../engine/optimizer';
import {
  CargoSku,
  ContainerSpec,
  LoadingProject,
  LoadingTemplate,
  OptimizationConfig,
} from '../types/clos';

export const DEFAULT_CONTAINERS: ContainerSpec[] = [
  {
    id: 'spec-40hc',
    code: '40HC',
    name: "40' High Cube Dry Container",
    internalLengthMm: 12032,
    internalWidthMm: 2352,
    internalHeightMm: 2698,
    maxPayloadKg: 26480,
    tareWeightKg: 3940,
    doorWidthMm: 2340,
    doorHeightMm: 2585,
    isDefault: true,
  },
  {
    id: 'spec-40gp',
    code: '40GP',
    name: "40' Standard Dry Container",
    internalLengthMm: 12032,
    internalWidthMm: 2352,
    internalHeightMm: 2393,
    maxPayloadKg: 26680,
    tareWeightKg: 3750,
    doorWidthMm: 2340,
    doorHeightMm: 2280,
  },
  {
    id: 'spec-20gp',
    code: '20GP',
    name: "20' Standard Dry Container",
    internalLengthMm: 5898,
    internalWidthMm: 2352,
    internalHeightMm: 2393,
    maxPayloadKg: 28200,
    tareWeightKg: 2230,
    doorWidthMm: 2340,
    doorHeightMm: 2280,
  },
  {
    id: 'spec-45hc',
    code: '45HC',
    name: "45' High Cube Pallet-Wide",
    internalLengthMm: 13556,
    internalWidthMm: 2438,
    internalHeightMm: 2698,
    maxPayloadKg: 27700,
    tareWeightKg: 4800,
    doorWidthMm: 2416,
    doorHeightMm: 2585,
  },
];

export const DEFAULT_OPTIMIZATION_CONFIG: OptimizationConfig = {
  algorithm: 'hybrid_alns_ep',
  anchorMode: 'left',
  minSupportRatio: 0.75,
  maxCogOffsetPct: 15,
  respectStacking: true,
  respectRotation: true,
  respectPayload: true,
  prioritizeHeavyBottom: true,
  autoAddContainers: true,
  alnsIterations: 6,
};

const DEMO_A_SKUS: CargoSku[] = [
  {
    id: 'sku-oak-tbl',
    factorySku: 'FAC-OAK-TBL-180',
    customerSku: 'CUSA-DT-180-OAK',
    description: 'Solid Oak Dining Table 180cm (KD Flat-Pack)',
    lengthMm: 1860,
    widthMm: 960,
    heightMm: 220,
    weightKg: 44.5,
    requiredQty: 36,
    stackable: true,
    maxStackLayers: 8,
    maxStackWeightKg: 380,
    rotationPolicy: 'upright_only',
    fragile: false,
    palletized: false,
    color: '#2563EB',
  },
  {
    id: 'sku-wal-sbd',
    factorySku: 'FAC-WAL-SBD-160',
    customerSku: 'CUSA-SB-160-WAL',
    description: '3-Drawer Walnut Veneer Sideboard Console',
    lengthMm: 1650,
    widthMm: 520,
    heightMm: 780,
    weightKg: 52.0,
    requiredQty: 24,
    stackable: true,
    maxStackLayers: 3,
    maxStackWeightKg: 180,
    rotationPolicy: 'upright_only',
    fragile: false,
    palletized: false,
    color: '#0D9488',
  },
  {
    id: 'sku-lng-chr',
    factorySku: 'FAC-CHR-UPH-04',
    customerSku: 'CUSA-LC-04-BOU',
    description: 'Boucle Upholstered Lounge Chair (2 pcs/carton)',
    lengthMm: 820,
    widthMm: 760,
    heightMm: 840,
    weightKg: 21.4,
    requiredQty: 42,
    stackable: true,
    maxStackLayers: 3,
    maxStackWeightKg: 85,
    rotationPolicy: 'upright_only',
    fragile: false,
    palletized: false,
    color: '#D97706',
  },
  {
    id: 'sku-wdb-tall',
    factorySku: 'FAC-WDB-210-MAT',
    customerSku: 'CUSA-WR-210-WHT',
    description: '2-Door Matte Lacquer Wardrobe System (Box A/B)',
    lengthMm: 2140,
    widthMm: 640,
    heightMm: 260,
    weightKg: 49.0,
    requiredQty: 28,
    stackable: true,
    maxStackLayers: 6,
    maxStackWeightKg: 320,
    rotationPolicy: 'length_width_only',
    fragile: false,
    palletized: false,
    color: '#7C3AED',
  },
  {
    id: 'sku-gls-vit',
    factorySku: 'FAC-VIT-GLS-09',
    customerSku: 'CUSA-VT-09-CLR',
    description: 'Tempered Glass Display Vitrine Cabinet',
    lengthMm: 1180,
    widthMm: 480,
    heightMm: 1220,
    weightKg: 56.0,
    requiredQty: 10,
    stackable: false,
    maxStackLayers: 1,
    maxStackWeightKg: 0,
    rotationPolicy: 'upright_only',
    fragile: true,
    palletized: false,
    color: '#DC2626',
  },
  {
    id: 'sku-rat-stl',
    factorySku: 'FAC-RAT-STL-02',
    customerSku: 'CUSA-ST-02-NAT',
    description: 'Woven Rattan Counter Stool (Nested 2-Pack)',
    lengthMm: 560,
    widthMm: 540,
    heightMm: 720,
    weightKg: 11.8,
    requiredQty: 32,
    stackable: true,
    maxStackLayers: 3,
    maxStackWeightKg: 45,
    rotationPolicy: 'all',
    fragile: false,
    palletized: false,
    color: '#059669',
  },
];

const DEMO_B_SKUS: CargoSku[] = [
  {
    id: 'sku-htl-bed',
    factorySku: 'FAC-HTL-KING-HB',
    customerSku: 'CUSB-HB-200-ASH',
    description: 'Commercial King Headboard Upholstered Panel',
    lengthMm: 2080,
    widthMm: 1450,
    heightMm: 210,
    weightKg: 48.0,
    requiredQty: 30,
    stackable: true,
    maxStackLayers: 6,
    maxStackWeightKg: 300,
    rotationPolicy: 'length_width_only',
    fragile: false,
    palletized: false,
    color: '#0284C7',
  },
  {
    id: 'sku-htl-dsk',
    factorySku: 'FAC-HTL-DSK-140',
    customerSku: 'CUSB-DK-140-ASH',
    description: 'Hospitality Writing Desk Ash Veneer',
    lengthMm: 1460,
    widthMm: 680,
    heightMm: 780,
    weightKg: 36.5,
    requiredQty: 30,
    stackable: true,
    maxStackLayers: 3,
    maxStackWeightKg: 140,
    rotationPolicy: 'upright_only',
    fragile: false,
    palletized: false,
    color: '#D97706',
  },
  {
    id: 'sku-htl-nst',
    factorySku: 'FAC-HTL-NST-02',
    customerSku: 'CUSB-NS-02-ASH',
    description: '2-Drawer Bedside Nightstand Assembled',
    lengthMm: 620,
    widthMm: 520,
    heightMm: 580,
    weightKg: 19.0,
    requiredQty: 60,
    stackable: true,
    maxStackLayers: 4,
    maxStackWeightKg: 95,
    rotationPolicy: 'upright_only',
    fragile: false,
    palletized: false,
    color: '#0D9488',
  },
];

function createSeedProjects(): {
  projects: LoadingProject[];
  templates: LoadingTemplate[];
} {
  const demoAOpt = runOptimization(
    DEMO_A_SKUS,
    [],
    DEFAULT_CONTAINERS,
    'spec-40hc',
    DEFAULT_OPTIMIZATION_CONFIG
  );

  const demoBOpt = runOptimization(
    DEMO_B_SKUS,
    [],
    DEFAULT_CONTAINERS,
    'spec-40hc',
    { ...DEFAULT_OPTIMIZATION_CONFIG, anchorMode: 'center' }
  );

  const projects: LoadingProject[] = [
    {
      id: 'proj-demo-a',
      code: 'EXP-2026-1042',
      name: 'Demo Export Q4 — Rotterdam',
      customerName: 'Khách demo A',
      destinationPort: 'Rotterdam (NLRTM)',
      status: 'calculated',
      createdAt: '2026-11-12T08:30:00Z',
      updatedAt: '2026-11-16T01:45:00Z',
      skus: DEMO_A_SKUS,
      containers: demoAOpt.containers,
      defaultContainerSpecId: 'spec-40hc',
      optimizationConfig: { ...DEFAULT_OPTIMIZATION_CONFIG },
      lastMetrics: demoAOpt.metrics,
      auditTrail: [
        {
          id: 'aud-1',
          timestamp: '2026-11-12T08:35:00Z',
          actor: 'QA Planning Lead',
          action: 'EXCEL_IMPORT',
          target: 'EXP-2026-1042',
          details: 'Imported 6 furniture SKUs (172 total cartons) from CS Packing List.',
        },
        {
          id: 'aud-2',
          timestamp: '2026-11-16T01:45:00Z',
          actor: 'Optimization Engine',
          action: 'AUTO_OPTIMIZE',
          target: '40HC Fleet',
          details: `Calculated ${demoAOpt.containers.length} container loading plan (${demoAOpt.metrics.volumeUtilizationPct.toFixed(1)}% avg volume util, 0 constraint errors).`,
        },
      ],
    },
    {
      id: 'proj-demo-b',
      code: 'EXP-2026-1038',
      name: 'Demo Hospitality — Melbourne',
      customerName: 'Khách demo B',
      destinationPort: 'Melbourne (AUMEL)',
      status: 'verified',
      createdAt: '2026-11-08T10:15:00Z',
      updatedAt: '2026-11-14T16:20:00Z',
      skus: DEMO_B_SKUS,
      containers: demoBOpt.containers,
      defaultContainerSpecId: 'spec-40hc',
      optimizationConfig: {
        ...DEFAULT_OPTIMIZATION_CONFIG,
        anchorMode: 'center',
      },
      lastMetrics: demoBOpt.metrics,
      auditTrail: [
        {
          id: 'aud-3',
          timestamp: '2026-11-14T16:20:00Z',
          actor: 'Export QA Supervisor',
          action: 'VERIFIED_PLAN',
          target: 'EXP-2026-1038',
          details: 'Verified center-anchored CoG weight distribution across containers.',
        },
      ],
    },
  ];

  const firstDemoACont = demoAOpt.containers[0];
  const firstDemoBCont = demoBOpt.containers[0];

  const templates: LoadingTemplate[] = [
    {
      id: 'tpl-demo-a',
      name: '40HC Mixed Oak Dining & Sideboard Tier',
      description:
        'Reusable 40ft High Cube floor-to-ceiling base layout pairing flat-pack dining tables with walnut sideboards and lounge chairs.',
      containerSpecCode: '40HC',
      containerLengthMm: 12032,
      containerWidthMm: 2352,
      containerHeightMm: 2698,
      skuSignatures: Array.from(
        firstDemoACont.placements.reduce((m, p) => {
          m.set(p.skuId, (m.get(p.skuId) ?? 0) + 1);
          return m;
        }, new Map<string, number>())
      ).map(([skuId, cnt]) => {
        const sku = DEMO_A_SKUS.find((s) => s.id === skuId)!;
        return {
          factorySku: sku.factorySku,
          customerSku: sku.customerSku,
          lengthMm: sku.lengthMm,
          widthMm: sku.widthMm,
          heightMm: sku.heightMm,
          countInTemplate: cnt,
        };
      }),
      placements: firstDemoACont.placements.map(
        ({ instanceId: _i, containerId: _c, ...rest }) => rest
      ),
      createdAt: '2026-11-12T09:10:00Z',
      utilizationPct: demoAOpt.metrics.volumeUtilizationPct,
    },
    {
      id: 'tpl-demo-b-center',
      name: '40HC Hospitality Center-Anchored Suite Pack',
      description:
        'Center-balanced headboard, writing desk, and nightstand layout designed for minimal lateral CoG deviation.',
      containerSpecCode: '40HC',
      containerLengthMm: 12032,
      containerWidthMm: 2352,
      containerHeightMm: 2698,
      skuSignatures: Array.from(
        firstDemoBCont.placements.reduce((m, p) => {
          m.set(p.skuId, (m.get(p.skuId) ?? 0) + 1);
          return m;
        }, new Map<string, number>())
      ).map(([skuId, cnt]) => {
        const sku = DEMO_B_SKUS.find((s) => s.id === skuId)!;
        return {
          factorySku: sku.factorySku,
          customerSku: sku.customerSku,
          lengthMm: sku.lengthMm,
          widthMm: sku.widthMm,
          heightMm: sku.heightMm,
          countInTemplate: cnt,
        };
      }),
      placements: firstDemoBCont.placements.map(
        ({ instanceId: _i, containerId: _c, ...rest }) => rest
      ),
      createdAt: '2026-11-14T16:25:00Z',
      utilizationPct: demoBOpt.metrics.volumeUtilizationPct,
    },
  ];

  return { projects, templates };
}

const seeded = createSeedProjects();
export const SEED_PROJECTS = seeded.projects;
export const SEED_TEMPLATES = seeded.templates;
