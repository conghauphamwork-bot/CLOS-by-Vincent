"""Chạy CLOS:  python run.py          -> chỉ máy này dùng (http://localhost:8000)
              python run.py --lan    -> cả mạng nội bộ (văn phòng) cùng dùng

Biến môi trường tuỳ chọn:
  CLOS_PORT=8000        đổi cổng
  CLOS_PASSWORD=...     bắt nhập mật khẩu (nên đặt khi dùng --lan)
  CLOS_NO_BROWSER=1     không tự mở trình duyệt
Bản .exe (PyInstaller) cũng chạy file này; dữ liệu lưu ở thư mục data/ cạnh file .exe.
"""
import os
import socket
import sys
import threading
import webbrowser


def _app_dir() -> str:
    if getattr(sys, "frozen", False):  # đang chạy từ CLOS.exe
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def _lan_ips() -> list[str]:
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))  # không gửi gói nào, chỉ để biết card mạng đang dùng
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    return sorted(ip for ip in ips if not ip.startswith("127."))


def _free_port(host: str, start: int) -> int:
    """Cổng đang bị phần mềm khác chiếm thì tự thử cổng kế tiếp (tối đa 20 cổng)."""
    for port in range(start, start + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind((host, port))
                return port
            except OSError:
                print(f" Cổng {port} đang bị phần mềm khác dùng, thử cổng {port + 1}...")
    raise RuntimeError(f"Không tìm được cổng trống từ {start} đến {start + 19}.")


def main() -> None:
    for st in (sys.stdout, sys.stderr):  # cửa sổ Windows cũ không in được tiếng Việt thì thay ký tự, không lỗi
        try:
            st.reconfigure(errors="replace")
        except Exception:
            pass
    base = _app_dir()
    data = os.path.join(base, "data")
    os.environ.setdefault("CLOS_WEB_DB", os.path.join(data, "clos_web.db"))
    os.environ.setdefault("CLOS_DB", os.path.join(data, "clos.db"))

    lan = "--lan" in sys.argv[1:] or os.environ.get("CLOS_LAN") == "1"
    host = "0.0.0.0" if lan else "127.0.0.1"
    port = _free_port(host, int(os.environ.get("CLOS_PORT", "8000")))

    import uvicorn
    from clos.api import app  # import sau khi đã đặt đường dẫn dữ liệu

    print("=" * 60)
    print(" CLOS by Vincent")
    print(f" Mở trên máy này:   http://localhost:{port}")
    if lan:
        for ip in _lan_ips():
            print(f" Máy khác cùng mạng: http://{ip}:{port}")
        if not os.environ.get("CLOS_PASSWORD"):
            print(" ⚠ Chưa đặt mật khẩu: ai cùng mạng cũng mở được CLOS.")
    print(f" Dữ liệu lưu tại:   {os.path.dirname(os.environ['CLOS_WEB_DB'])}")
    print(" Đóng cửa sổ này để tắt CLOS.")
    print("=" * 60)

    if os.environ.get("CLOS_NO_BROWSER") != "1":
        threading.Timer(1.5, lambda: webbrowser.open(f"http://localhost:{port}")).start()
    uvicorn.run(app, host=host, port=port, log_level="warning")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    except Exception:
        import traceback
        print("\n" + "=" * 60)
        print(" CLOS GẶP LỖI, KHÔNG CHẠY ĐƯỢC. Chụp màn hình này gửi người hỗ trợ:")
        print("=" * 60)
        traceback.print_exc()
        log = os.path.join(_app_dir(), "clos-loi.txt")
        try:
            with open(log, "w", encoding="utf-8") as f:
                traceback.print_exc(file=f)
            print(f"\n Đã lưu chi tiết lỗi vào: {log}")
        except OSError:
            pass
        if os.name == "nt" or getattr(sys, "frozen", False):
            input("\n Bấm Enter để đóng cửa sổ...")
        sys.exit(1)
